<?php
include("lib/gg_lib.php");
$detecta = new Acesso();
$detecta->__detecta_inicio();
?>