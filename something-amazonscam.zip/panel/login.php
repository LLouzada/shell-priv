<?php
ob_start();
session_start();
ob_end_clean();
if(isset($_SESSION['username'])){
header("location:index.php");
exit;
}
?>
<html>
<head>
<title>SOMETHING PANEL V1</title>
	<link href="//brobin.github.io/hacker-bootstrap/css/hacker.css" rel="stylesheet">
  <link href="img/something-ico.png" rel="icon" type="image/x-icon" />
</head>
<body>

    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
                            <div class="navbar-header">
                <a class="navbar-brand" href="#"><img src="img/something-logo.png" width="180"></a>
                </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="https://www.facebook.com/founder.agility" target="_blank">Contact Provider</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <marquee behavior="alternate" onmouseover="this.stop()" onmouseout="this.start()"><h4 style="font-family:verdana;">
<script type='text/javascript'>
//<![CDATA[

var text="Welcome To SOMETHING PANEL V1" //Ganti dengan teks anda
var speed=80 //Kecepatan ganti warna

if (document.all||document.getElementById){
document.write('<span id="highlight">' + text + '</span>')
var storetext=document.getElementById? document.getElementById("highlight") : document.all.highlight
}
else
document.write(text)
var hex=new Array("00","14","28","3C","50","64","78","8C","A0","B4","C8","DC","F0")
var r=1
var g=1
var b=1
var seq=1
function changetext(){
rainbow="#"+hex[r]+hex[g]+hex[b]
storetext.style.color=rainbow
}
function change(){
if (seq==6){
b--
if (b==0)
seq=1
}
if (seq==5){
r++
if (r==12)
seq=6
}
if (seq==4){
g--
if (g==0)
seq=5
}
if (seq==3){
b++
if (b==12)
seq=4
}
if (seq==2){
r--
if (r==0)
seq=3
}
if (seq==1){
g++
if (g==12)
seq=2
}
changetext()
}
function starteffect(){
if (document.all||document.getElementById)
flash=setInterval("change()",speed)
}
starteffect()

//]]>
</script></h4></marquee>
<div class="container">
        <div class="row">
            <div class="well">
<center><legend>Panel Login</legend>
<form action="./loginProcess.php" method="post">
<div class="field">
<div class="input-group">
  <input class="form-control" name="Password" type="Password" placeholder="Password" required>
<span class="input-group-btn">
<button class="btn btn-default" id="submit">Login</button>
</span>
</div>
</form></center>
  <div class="row tall-row">
  <div class="col-md-12">
  <br>
  <p>Created by <a href="https://www.facebook.com/founder.agility">Febriyanto Hamonangan</a>. © 2018</p>
  </div>
  </div>
</body>
</html>