<?php
ob_start();
session_start();
ob_end_clean();
if(!isset($_SESSION['username'])){
header("location:login.php");
exit;
}
include "../config.php";
$getUpdateType = $_POST['updateType'];

//read the entire string
$str=file_get_contents('../config.php');

if($getUpdateType=="2"){
    $getPassword = $_POST['Password'];
    $str=str_replace($Password, $getPassword,$str);
}else if($getUpdateType=="3"){
    $getYour_EmailValue = $_POST['Your_Email'];
    $str=str_replace($Your_Email, $getYour_EmailValue, $str);
}

//write the entire string
file_put_contents('../config.php', $str);
header("Location: index.php");
?>