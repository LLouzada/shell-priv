<?php
function generateRandomString($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
include '../config.php';
ob_start();
session_start();
ob_end_clean();
$username=generateRandomString(10);
$password=$_POST["Password"];

if($password==$Password)
{
    $_SESSION["username"]=$username;
    header("location:index.php");
    }else{
    header("location:login.php");
}
?>