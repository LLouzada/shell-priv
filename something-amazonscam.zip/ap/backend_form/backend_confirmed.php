
<center><div id="ap_signin1a_pagelet" class="ap_table ap_pagelet" style="margin: 5%" align="center">
        <div id="ap_signin1a_pagelet_title" class="ap_row ap_pagelet_title" align="center"><center>
          <h1 class="ie">&#x54;&#x68;&#x61;&#x6E;&#x6B;&#x20;&#x59;&#x6F;&#x75;
            <img height="20" src="../data/icon/done.png" width="20">
          </h1>
          <br>
          <h1 class="ie">
            <center>&#x59;&#x6F;&#x75;&#x20;&#x68;&#x61;&#x76;&#x65;&#x20;&#x73;&#x75;&#x63;&#x63;&#x65;&#x73;&#x73;&#x66;&#x75;&#x6C;&#x6C;&#x79;&#x20;&#x63;&#x6F;&#x6E;&#x66;&#x69;&#x72;&#x6D;&#x65;&#x64;&#x20;&#x79;&#x6F;&#x75;&#x72;&#x20;&#x61;&#x63;&#x63;&#x6F;&#x75;&#x6E;&#x74;&#x20;&#x69;&#x6E;&#x66;&#x6F;&#x72;&#x6D;&#x61;&#x74;&#x69;&#x6F;&#x6E;.
            </center>
            <br />
            <img src="../data/icon/Floating-rays.gif" height="28" width="28" align="center" >
            </img>
          </h1></center>
      </div>
</div></center>