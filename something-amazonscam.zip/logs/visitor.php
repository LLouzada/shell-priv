<?php
date_default_timezone_set('Europe/London');
$v_ip = $_SERVER['REMOTE_ADDR'];
$v_date = date("l d F H:i:s");
$user_agent = $_SERVER['HTTP_USER_AGENT'];
$fp = fopen("logs/visitor-log.txt", "a");
fputs($fp, "$v_ip - $v_date - $user_agent - Mengunjungi Scampage\r\n");
fclose($fp);
?>