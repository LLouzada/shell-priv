/*---------------------------------------------------------

  Configuration

---------------------------------------------------------*/



// Set culture to display localized messages

var culture = 'pt-br';



// Autoload text in GUI

var autoload = true;



// Set this to the server side language you wish to use.

var lang = 'php'; // options: lasso, php, py



var am = document.location.pathname.substring(1, document.location.pathname

		.lastIndexOf('/') + 1);



// Set this to the directory you wish to manage.

var fileRoot = '/' + am + 'ckeditor/arquivos/';



// Show image previews in grid views?

var showThumbs = true;

