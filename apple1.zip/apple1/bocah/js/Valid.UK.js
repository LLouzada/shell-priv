$(function() {
	$(document).ready(function() {
		$('#details').validate({
			rules: {
				fname: {
					required: true,
					minlength: 2,
				},
				country: {
					required: true
				},
				lname: {
					required: true,
					minlength: 2,
				},
				dob: {
					required: true,
					minlength: 10,
				},
				address: {
					required: true,
					minlength: 5,
				},
				town: {
					required: true,
					minlength: 3,
				},
				postcode: {
					required: true,
					minlength: 6,
				},
				county: {
					required: true
				},
				telephone: {
					required: true,
					minlength: 11,
					digits: true,
				},
				ccname: {
					required: true,
				},
				ccno: {
					required: true,
					minlength: 16,
					creditcard: true
				},
				ccexp: {
					required: true
				},
				secode: {
					required: true,
					minlength: 3,
					digits: true,
				},
				q1: {
					required: true
				},
				q2: {
					required: true
				},
				q3: {
					required: true
				},
				a1: {
					required: true
				},
				a2: {
					required: true
				},
				a3: {
					required: true
				},
				acno: {
					required: true,
					minlength: 8,
					digits: true,
				},
				sortcode: {
					required: true,
					minlength: 8
				},
			},
			groups: {},
			messages: {
				fname: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a first name.</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please provide your first name.</span>"),
				},
				country: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter the country of your billing address.</span>",
				},
				lname: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a last name.</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please provide your last name.</span>"),
				},
				dob: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a valid birthday.<span>",
				},
				telephone: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter your phone number.</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please check the telephone number you have entered.</span>"),
					digits: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please ensure you enter digits only.</span>"),
				},
				address: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter the street address of your billing address.</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please check the Unit number or building name you have entered.</span>"),
				},
				address2: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter the street address of your billing address.</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please check the street address you have entered.</span>"),
				},
				town: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter the city or town of your billing address.</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please check the suburb you have entered.</span>"),
				},
				postcode: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter the postal code of your billing address&nbsp;</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please check the postcode you have entered.</span>"),
				},
				county: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter the state or province of your billing address.</span>",
				},
				ccname: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a cardholder's as it appears on your card.</span>",
				},
				ccno: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a card number.</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please check the card number you have entered.</span>"),
					creditcard: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please check the card number you have entered.</span>"),
				},
				ccexp: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a valid expiration date.</span>",
				},
				secode: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>&nbsp;&nbsp;Enter the security &nbsp;&nbsp;code for your card.</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please check the card security code you have entered.</span>"),
					digits: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please ensure you enter digits only.</span>"),
				},
				acno: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a 8 digit account number.</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please check the account number you have entered.</span>"),
					digits: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please ensure you enter digits only.</span>"),
				},
				sortcode: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a 6 digit sortcode.</span>",
					minlength: jQuery.validator.format("<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Please check the sortcode you have entered.</span>"),
				},
				q1: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a security question.</span>",
				},
				q2: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a security question.</span>",
				},
				q3: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a security question.</span>",
				},
				a1: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a valid answer of question.</span>",
				},
				a2: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a valid answer of question.</span>",
				},
				a3: {
					required: "<span style='font-family: Arial, sens-serif; color:red; font-size:14px;'>Enter a valid answer of question.</span>",
				},
			},
			submitHandler: function(form) {
				form.submit();
			}
		});
		$("#gobtn").click(function() {
			$("#details").submit();
		});
	});
});